package com.darkflame.client;

import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;

public class LoadGamesText {
	
	
	//all the games strings here!;
	
	//all the strings used in MyApplication (aka, the main game loop)
	public static String MainGame_Submit = "";
	public static String MainGame_SaveOrLoadYourGame= "";
	public static String MainGame_Inventory= "";
	public static String MainGame_Charecter_Profiles= "";
	public static String MainGame_Secrets_Found= "";
	public static String MainGame_CloseAlWindows= "";
	public static String MainGame_Loading= "";
	public static String MainGame_WindowTitle_Loading= "";
	public static String MainGame_StoryText_Loading = "";
	public static String MainGame_Sending = "";	
	public static String MainGame_is_on_chapter = "";
	public static String MainGame_submit = "";
	public static String MainGame_YouAlreadyHaveThisItem = "";
	public static String MainGame_Welcome_Back = "";	
	public static String MainGame_LoadingNewGame = "";
	
	//maths
	public static String MainGame_Mathsbeforeans = "mm..thats..";
	public static String MainGame_Mathsafterans = "..I think";
	//score
	public static String MainGame_Score_Awarded = "ScoreAwarded";
	
	//--------
	
	//all the strings used in the controll panel
	public static String ControllPanel_AnimationEffects = "";
	public static String ControllPanel_Big= "";
	public static String ControllPanel_ChangePassword= "";
	public static String ControllPanel_ClickHereToLogOut= "";
	public static String ControllPanel_ClickHereToSaveYourProgress= "";
	public static String ControllPanel_ControllPanel= "";
	public static String ControllPanel_DataSaved= "";
	public static String ControllPanel_Default= "";
	public static String ControllPanel_InterfaceSize = "";
	public static String ControllPanel_LoadFromText = "";	
	public static String ControllPanel_LoggedOut = "";
	public static String ControllPanel_loggingout = "";
	public static String ControllPanel_loggingout2 = "";
	public static String ControllPanel_Medium = "";	
	public static String ControllPanel_off = "";
	public static String ControllPanel_on = "";
	public static String ControllPanel_Small = "";
	public static String ControllPanel_SoundEffects = "";
	//in Gamereset box
	public static String GameReset_Title = "Reset Game";
	public static String GameReset_Button = "Start Game From Scratch";
	public static String GameReset_Warning = "";
	//--------
	//for magnifying item
	public static String Magnify_Magnify = "";	
	//LoginScreen text
	public static String Login_PleaseLogin = "PleaseLogin";
	public static String Login_Username = "";
	public static String Login_Password = "Password:";
	public static String Login_Rememberme = "Remember me next time?";
	public static String Login_SignUp = "SignUp";
	public static String Login_GuestLogin = "Login As Guest";
	public static String Login_ForgotPassword = "Forgot Password?";
	public static String Login_ClearCookies= "";
	
	//For CluePanel
	
	public static String CluePanel_loading = "Loading...";
	public static String CluePanel_instructions = "";
	public static String CluePanel_instructions2 = "";
	public static String CluePanel_chapterheader = "";
	public static String CluePanel_buy = "buy";
	public static String CluePanel_cancel = "cancel";
	public static String CluePanel_purchasedclue = "";
	
	
	
	//array for loading text;
	AssArray FileTemp = new AssArray();
	
	public LoadGamesText() {
	}
	
	public void LoadText(String messages){
		int newlinepos = 0;
    	int curpos = 0;
    	String currentline="";
    	MyApplication.DebugWindow.addText("\n loading text-"+messages);
		
    	while (curpos+3<messages.length()){
    		newlinepos = messages.indexOf("\n", curpos+1);
    		if (newlinepos == -1)
    		{
    			newlinepos = messages.length();
    		}
    		//current line
    		currentline=messages.substring(curpos, newlinepos);
    		
    		String currentmess = currentline.split("=")[0];
    		String currentstring = currentline.split("=")[1];
    		
    		//put into ass
    		FileTemp.AddItem(currentstring.trim(), currentmess.trim());
    		
    		MyApplication.DebugWindow.addText("   \n"+currentstring.trim()+" "+currentmess.trim());
    		
    		curpos= newlinepos;
    		
    	}
    		//now we use the array to assign the strings
    	MyApplication.DebugWindow.addText("\n assigning text");
		
    	assignStrings();
	}
	public void LoadTextFromFile(String URL){
		
		//first we grab the file and copy it into an assosative array;
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.GET,
				URL);
				
				try {
				      requestBuilder.sendRequest("", new RequestCallback() { //$NON-NLS-1$
				        public void onError(Request request, Throwable exception) {
				        	System.out.println("http get failed"); //$NON-NLS-1$
				        }

				        public void onResponseReceived(Request request, Response response) {
				        	MyApplication.DebugWindow.addText("text file recieved"+response.getText());
				        	
				        	LoadText(response.getText());
				        	
				        	
				        	
				        }
				      });
				    } catch (RequestException ex) {
				    	System.out.println("can not connect to games text file"); //$NON-NLS-1$
				    }

		
		
	}

	private void assignStrings() {
		
		MyApplication.DebugWindow.addText("\n assigning stings");
		
		//MyApplication Strings
		MainGame_Submit = FileTemp.GetItem("MainGame_Submit");
		MainGame_SaveOrLoadYourGame = FileTemp.GetItem("MainGame_SaveOrLoadYourGame");
		MainGame_Inventory = FileTemp.GetItem("MainGame_Inventory");
		MainGame_Charecter_Profiles = FileTemp.GetItem("MainGame_Charecter_Profiles");
		MainGame_Secrets_Found = FileTemp.GetItem("MainGame_Secrets_Found");
		MainGame_CloseAlWindows = FileTemp.GetItem("MainGame_CloseAlWindows");
		MainGame_Loading = FileTemp.GetItem("MainGame_Loading");
		MainGame_WindowTitle_Loading = FileTemp.GetItem("MainGame_WindowTitle_Loading");
		MainGame_StoryText_Loading = FileTemp.GetItem("MainGame_StoryText_Loading");
		MainGame_Sending = FileTemp.GetItem("MainGame_Sending");
		MainGame_is_on_chapter = FileTemp.GetItem("MainGame_is_on_chapter");
		MainGame_submit = FileTemp.GetItem("MainGame_submit");
		MainGame_YouAlreadyHaveThisItem = FileTemp.GetItem("MainGame_YouAlreadyHaveThisItem");

		MainGame_Welcome_Back = FileTemp.GetItem("MainGame_Welcome_Back");
		MainGame_LoadingNewGame = FileTemp.GetItem("MainGame_LoadingNewGame");
	//maths
		MainGame_Mathsbeforeans  = FileTemp.GetItem("MainGame_Maths_Before_Ans");
		MainGame_Mathsafterans  = FileTemp.GetItem("MainGame_Maths_After_Ans");
		//score
		MainGame_Score_Awarded = FileTemp.GetItem("MainGame_ScoreAwarded");
		
		//Controll Panel strings
	    ControllPanel_AnimationEffects = FileTemp.GetItem("ControllPanel_AnimationEffects");
		ControllPanel_Big= FileTemp.GetItem("ControllPanel_Big");
		ControllPanel_ChangePassword= FileTemp.GetItem("ControllPanel_ChangePassword");
		ControllPanel_ClickHereToLogOut= FileTemp.GetItem("ControllPanel_ClickHereToLogOut");
		ControllPanel_ClickHereToSaveYourProgress= FileTemp.GetItem("ControllPanel_ClickHereToSaveYourProgress");
		ControllPanel_ControllPanel= FileTemp.GetItem("ControllPanel_ControllPanel");
		ControllPanel_DataSaved= FileTemp.GetItem("ControllPanel_DataSaved");
		ControllPanel_Default= FileTemp.GetItem("ControllPanel_Default");
		ControllPanel_InterfaceSize = FileTemp.GetItem("ControllPanel_InterfaceSize");
		ControllPanel_LoadFromText = FileTemp.GetItem("ControllPanel_LoadFromText");
		ControllPanel_LoggedOut = FileTemp.GetItem("ControllPanel_LoggedOut");
		ControllPanel_loggingout = FileTemp.GetItem("ControllPanel_loggingout");
		ControllPanel_loggingout2 = FileTemp.GetItem("ControllPanel_loggingout2");
		ControllPanel_Medium = FileTemp.GetItem("ControllPanel_Medium");
		ControllPanel_off = FileTemp.GetItem("ControllPanel_off");
		ControllPanel_on = FileTemp.GetItem("ControllPanel_on");
		ControllPanel_Small = FileTemp.GetItem("ControllPanel_Small");
		ControllPanel_SoundEffects = FileTemp.GetItem("ControllPanel_SoundEffects");
		
		//reset game box
		GameReset_Title = FileTemp.GetItem("ResetGame_Title");
		GameReset_Button =  FileTemp.GetItem("ResetGame_Button");
		 GameReset_Warning =  FileTemp.GetItem("ResetGame_Warning");
		 
		//---for magnifying glass item		
		Magnify_Magnify = FileTemp.GetItem("Magnify_Magnify");
		//LoginScreen text
		Login_PleaseLogin = FileTemp.GetItem("Login_PleaseLogin");
		 Login_Username =FileTemp.GetItem("Login_Username");
		Login_Password = FileTemp.GetItem("Login_Password");
		 Login_Rememberme = FileTemp.GetItem("Login_Rememberme");
		 Login_SignUp = FileTemp.GetItem("Login_SignUp");
		 Login_GuestLogin = FileTemp.GetItem("Login_GuestLogin");
		 Login_ForgotPassword = FileTemp.GetItem("Login_ForgotPassword");
		Login_ClearCookies= FileTemp.GetItem("Login_ClearCookies");
		
		MyApplication.DebugWindow.addText("\n assigning stings1");
		
		
		//Login Window CluePanel_instructions1

		CluePanel_loading = FileTemp.GetItem("CluePanel_loading");
		CluePanel_instructions =FileTemp.GetItem("CluePanel_instructions"); 
		CluePanel_instructions2 = FileTemp.GetItem("CluePanel_instructions2");
		CluePanel_chapterheader = FileTemp.GetItem("CluePanel_chapterheader");
		CluePanel_buy = FileTemp.GetItem("CluePanel_buy");
		CluePanel_cancel = FileTemp.GetItem("CluePanel_cancel");
		CluePanel_purchasedclue = FileTemp.GetItem("CluePanel_purchasedclue");
		
		}
	
}
