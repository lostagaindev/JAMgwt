package com.darkflame.client;

import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.Label;

public class TypedLabel extends Label {

	final Timer timer;
	String targetText = "";
	String currentText = "";
	int Speed = 35;
	int i = 0;
	int Delay = 5;
	
	boolean showcursor = true;

	public TypedLabel(String StartingText) {
		this.setText(StartingText);
		targetText = StartingText;
		i = 0;
		timer = new Timer() {
			public void run() {
				// if the current target text is set, we remove the timer.
				if (currentText.compareTo(targetText) == 0) {
					getElement().setInnerHTML(currentText+"<blink>█</blink>");
					this.cancel();
				} else {
					// is not we add another letter.

					char nextletter = targetText.charAt(i);
					currentText = currentText + nextletter;
					getElement().setInnerHTML(currentText+"█");
					
					i = i + 1;
					// sound if not disabled
					if (MyApplication.SoundEffectOn) {
						if (nextletter == ' ') {
							MyApplication
									.processInstructions("- PlaySound = CC2spacebeep.mp3","");
						} else {
							MyApplication
									.processInstructions("- PlaySound = CC2keybeep.mp3","");

						}

					}
				}
			}

		};

	}

	public void setSpeed(int newSpeed) {
		Speed = newSpeed;
	}

	public void setDelay(int newDelay) {
		if (newDelay == 0) {
			Delay = 50;
		} else {
			Delay = newDelay * 1000;
		}
	}

	public void setTextNow(String text) {
		getElement().setInnerText(text);
	}

	@Override
	public void setText(String text) {
		if (text.length() > 0) {
			i = 0;
			currentText = "";
			targetText = text;
			Timer delaybeforetype = new Timer() {
				public void run() {
					timer.scheduleRepeating(Speed);
				}
			};

			delaybeforetype.schedule(Delay);
		}
	}

}
