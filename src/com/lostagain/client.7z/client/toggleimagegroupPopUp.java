package com.darkflame.client;

import java.util.ArrayList;
import java.util.Iterator;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.MouseOutEvent;
import com.google.gwt.event.dom.client.MouseOutHandler;
import com.google.gwt.event.dom.client.MouseOverEvent;
import com.google.gwt.event.dom.client.MouseOverHandler;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.LoadListener;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class toggleimagegroupPopUp extends VerticalPanel implements hasCloseDefault,
 hasOpenDefault, isPopUpType,isItem  {

	// screen size
	int ScreenSizeX = Window.getClientWidth();
	int ScreenSizeY = Window.getClientHeight();
	int Original_picY = 0;
	int Original_picX = 0;
	// pic size
	int picX = 0;
	int picY = 0;
	int posX = 0;
	int posY = 0;
//feedback
	final TypedLabel TiGFeedback = new TypedLabel(""); //$NON-NLS-1$

	//solution flag
	Boolean solutionpresent = true;
	
	//Tig message present flag
	Boolean messageboxpresent = false;
	
	String solution_script = "";
	// Discription
	HTML ImageDiscription = new HTML("");

	//button
	final Button submitans = new Button("~ Check ~");
	
	final Timer timer;
	//image	
	Image Background = new Image("");	
	AbsolutePanel imagegroupframe = new AbsolutePanel();
	toggleimagegroupPopUp thisframe =this;
	
	String CoreName = "";
	
	//Item array

	final ArrayList<InterfaceIcon> TIGitems = new ArrayList<InterfaceIcon>();
	
	 boolean Magnifable = false;
		
	 String sourceurl="";
	 String sourcesizeX="";
	 String sourcesizeY="";
	
	public toggleimagegroupPopUp(final String ItemName, final String nDiscription, String sizeX, String sizeY){

		CoreName=ItemName;
		
		sourcesizeX= sizeX;
		sourcesizeY= sizeY;
		
		//make sure this is clear;
		TIGitems.clear();
		
		//First we load the backdrop
		String BackURL = "InventoryItems/"+ItemName+"/"+ItemName+".jpg";
		
		sourceurl = BackURL;
		
		
		Background.setUrl(BackURL);
		
		
		thisframe.setBorderWidth(0);
		thisframe.setSpacing(0);
		thisframe.add(imagegroupframe);
		imagegroupframe.add(Background,0,0);
		thisframe.add(TiGFeedback);

		TiGFeedback.setWidth("100%"); //$NON-NLS-1$	
		TiGFeedback.setStyleName("Feedback");
		TiGFeedback.setHeight("50px");
		TiGFeedback.setVisible(false);
		 
		//discription
		MyApplication.DebugWindow.addText("tig loading");
		
		
		//MyApplication.DebugWindow.addText("loading image.."+BackURL);
		
		timer = new Timer() {
			@Override
			public void run() {
				// We check the size here, and fix if not correct. (for IE, as
				// IE dosnt work with LoadListener due to the cache)

				if (Background.getOffsetWidth() > 35) {
					Original_picY = Background.getHeight();
					Original_picX = Background.getWidth();

					imagegroupframe.setSize(Original_picX+"px", Original_picY+"px");
										
					if (solutionpresent == true){
						imagegroupframe.add(submitans,(imagegroupframe.getOffsetWidth()/2)-50,imagegroupframe.getOffsetHeight()-30);
						}
					
				   if (messageboxpresent){
					   TiGFeedback.setVisible(true);
				   }
					
					
				    MyApplication.DebugWindow.addText("image load b"+Original_picY+" "+Original_picX);
				    
				  //add discriptions
					if (nDiscription != "") {
						 MyApplication.DebugWindow.addText("discription set"+nDiscription);
						 
						ImageDiscription.setText(nDiscription);
						ImageDiscription.setWidth("100%");
						//imagegroupframe.add(ImageDiscription,5,Original_picY);
					//	imagegroupframe.setSize(Original_picX+"px", Original_picY+30+"px");
						
						thisframe.insert(ImageDiscription,0);
						ImageDiscription.setStyleName("notepadback");
						ImageDiscription.getElement().getParentElement().setClassName(
								"picturePopUp");
						
						
						
					}
					
					reSizePopUp();
					this.cancel();
				}

			}

		};
		
		Background.addLoadListener(new LoadListener() {

			public void onError(Widget sender) {
				System.out
						.print("\n /n <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<image failed "
								+ Original_picX + "-" + Original_picY);

			}

			public void onLoad(Widget sender) {
				// TODO Auto-generated method stub
				Original_picY = ((Image) sender).getHeight();
				Original_picX = ((Image) sender).getWidth();
				
				//Original_picX = sourcesizeX;
				//Original_picY = sourcesizeY;
				
				//imagegroupframe.setSize(Original_picX+"px", Original_picY+"px");
				imagegroupframe.setSize(sourcesizeX, sourcesizeY);
				
				
				//we finaly add the tester button
				if (solutionpresent == true){
				imagegroupframe.add(submitans,(imagegroupframe.getOffsetWidth()/2)-50,imagegroupframe.getOffsetHeight()-30);
				}
				 if (messageboxpresent){
					   TiGFeedback.setVisible(true);
				   }
					
				
				MyApplication.DebugWindow.setText("image load a");
				
				//add discriptions
				if (nDiscription != "") {
					 MyApplication.DebugWindow.addText("discription set"+nDiscription);
					ImageDiscription.setText(nDiscription);
					ImageDiscription.setWidth("100%");
					//imagegroupframe.add(ImageDiscription,5,Original_picY);
					//imagegroupframe.setSize(Original_picX+"px", Original_picY+30+"px");
					ImageDiscription.getElement().getParentElement().setClassName(
							"picturePopUp");
					ImageDiscription.setStyleName("notepadback");

					thisframe.insert(ImageDiscription,0);
				}
				
				
					reSizePopUp();
				timer.cancel();
				
				
			}
		});
		// -----------------------
		
		
		timer.scheduleRepeating(1000);
		
		
		
		
		//Then we get the TIS's item ini
		String ControllIni = GWT.getHostPageBaseURL() +"InventoryItems/"+ItemName+"/"+ItemName+"_items.ini";
		
		
		RequestBuilder requestBuilder2 = new RequestBuilder(RequestBuilder.GET,ControllIni);
		try {
		      requestBuilder2.sendRequest("", new RequestCallback() {
		        public void onError(Request request, Throwable exception) {
		        	System.out.println("error in user logged in test");
		        }

				public void onResponseReceived(Request request,
						Response response) {
					
					
					System.out.println("\n\n"+response.getText());
					
					String item_list = response.getText();
					
					MyApplication.DebugWindow.addText("Item Data:"+item_list);
					
					
					// then we loop over adding the items
					
					int starthere = 0;
					int loc = item_list.indexOf("-Item:",starthere)+6;
					String itemset = "";
					if ((item_list.indexOf("-Item:",loc+6))>-1){
					 itemset = item_list.substring(loc, item_list.indexOf("-Item:",loc));
					} else {
					  itemset = item_list.substring(loc, item_list.length());
					}
					System.out.println("set:"+itemset);
					
					while (loc>-1){
					
						System.out.println("\n\n adding next item to TIG");
						
						//get the pictures filename
						String name = itemset.substring( itemset.indexOf("Name =",0)+7,itemset.indexOf("\n",itemset.indexOf("Name =",0)+7) );
						//get the pictures title
						String title = itemset.substring( itemset.indexOf("Title =",0)+9,itemset.indexOf("'",itemset.indexOf("Title =",0)+9));
						
						//get the id name, if there is one
						String IconIDName = itemset.substring( itemset.indexOf("IconID =",0)+9,itemset.indexOf("\n",itemset.indexOf("IconID =",0)+9) );
						
						//get the states number
						int States = Integer.parseInt((itemset.substring (itemset.indexOf("States =",0)+8,itemset.indexOf("\n",itemset.indexOf("States =",0)+8))).trim());
						//get the location to put it
						int ItemLocX = Integer.parseInt((itemset.substring( itemset.indexOf("Located =",0)+9,itemset.indexOf(",",itemset.indexOf("Located =",0)+9))).trim());
						int ItemLocY = Integer.parseInt((itemset.substring( itemset.indexOf(",",itemset.indexOf("Located =",0)+9)+1,itemset.indexOf("\n",itemset.indexOf("Located =",0)+9))).trim());
						
						
						//NOTE: Currently it can only have actions or rollover actions, not both
						final boolean isActions = itemset.contains("Actions:");
						
						final String Actions =  itemset.substring( itemset.indexOf("Actions:",0)+8,((itemset.indexOf("Mouse",0))>0?(itemset.indexOf("Mouse",0)):(itemset.length())));
						
						final boolean isMouseoverActions = itemset.contains("MouseoverActions:");
												
						final String mouseoverActions =  itemset.substring( itemset.indexOf("MouseoverActions:",0)+17,((itemset.indexOf("Mouse",itemset.indexOf("MouseoverActions:",0)+17))>0?(itemset.indexOf("Mouse",itemset.indexOf("MouseoverActions:",0)+17)):(itemset.length())));
						
						final boolean isMouseoutActions = itemset.contains("MouseoutActions:");
						
						final String mouseoutActions =  itemset.substring( itemset.indexOf("MouseoutActions:",0)+16,((itemset.indexOf("Mouse",itemset.indexOf("MouseoutActions:",0)+16))>0?(itemset.indexOf("Mouse",itemset.indexOf("MouseoutActions:",0)+16)):(itemset.length())));

						//MyApplication.DebugWindow.setText("Icon:"+IconIDName+" Adding actions: "+IconActions+" :");
						
						//=========
						
						System.out.println("\n name="+name);
						System.out.println("\n title="+title);
						System.out.println("\n States="+States);						
						System.out.println("\n ItemLocX="+ItemLocX);
						System.out.println("\n ItemLocY="+ItemLocY);
						
						System.out.println("\n RunWhenClicked="+Actions);
						
						
						starthere = starthere+itemset.length()+6;	
						loc = item_list.indexOf("-Item:",starthere);	
						//new item set
						if ((item_list.indexOf("-Item:",loc+6))>-1){
							 itemset = item_list.substring(loc+6, item_list.indexOf("-Item:",loc+6));
							} else {
							  itemset = item_list.substring(loc+6, item_list.length());
							}
							
						MyApplication.DebugWindow.addText(" start here ="+starthere+";");
						MyApplication.DebugWindow.addText(" loc ="+loc+";");
						MyApplication.DebugWindow.addText(" itemset ="+itemset+";--------------------\n ");
						
						// Now we create a new icon object						
						final InterfaceIcon newItem = new InterfaceIcon("InventoryItems/"+ItemName+"/items/"+name,States);
						newItem.setTitle(title);
						newItem.uniqueName = IconIDName.trim();
						MyApplication.DebugWindow.addText(newItem.uniqueName+" set:");
						
						//and add it where specified						
						imagegroupframe.add(newItem,ItemLocX,ItemLocY);
						//add to item set
						TIGitems.add(newItem);
						
						//Add the interaction.
						//Note; In future it would be nice to add a required section here too,
						//allowing specific requirements to be forfilled before an action is accepted
						
						//if it has mouseovers, add them
						if (isMouseoverActions){
						newItem.addMouseOverHandler(new MouseOverHandler(){

							public void onMouseOver(MouseOverEvent event) {
								
								
								
								Widget sender = (Widget)event.getSource();
								 //run actions
								//update last clicked variables so that popups can be positioned correctly if used
								 MyApplication.lastclicked_x = imagegroupframe.getWidgetLeft(sender)+(sender.getOffsetWidth()/2);								 
								 MyApplication.lastclicked_y = imagegroupframe.getWidgetTop(sender)+(sender.getOffsetHeight()/2);
								 MyApplication.lastclicked_item = thisframe;
								 
								 //process the instructions
								 MyApplication.DebugWindow.addText(" processing from image click ");
									
							 MyApplication.processInstructions(mouseoverActions,"TIG:"+CoreName+","+newItem.basefilename);
							 
							}
							
						});
						}
						//if it has mouseout, add them
						if (isMouseoutActions){
						newItem.addMouseOutHandler(new MouseOutHandler(){

							public void onMouseOut(MouseOutEvent event) {
								Widget sender = (Widget)event.getSource();
								 //run actions
								//update last clicked variables so that popups can be positioned correctly if used
								 MyApplication.lastclicked_x = imagegroupframe.getWidgetLeft(sender)+(sender.getOffsetWidth()/2);								 
								 MyApplication.lastclicked_y = imagegroupframe.getWidgetTop(sender)+(sender.getOffsetHeight()/2);
								 MyApplication.lastclicked_item = thisframe;
								 
								 //process the instructions
								 MyApplication.DebugWindow.addText(" processing from image click ");
									
							 MyApplication.processInstructions(mouseoutActions,"TIG:"+CoreName+","+newItem.basefilename);
							 
							}
							
						});
						}
						//add its click-and-switch-ability
												
						newItem.addClickHandler(new ClickHandler(){
							public void onClick(ClickEvent event) {
								
								Widget sender = (Widget)event.getSource();
								
								
								 //default actions only if theres no other commands for itself.
								 if (((Actions.indexOf(((InterfaceIcon)sender).uniqueName))>0) && (isActions)) {
										 
									 MyApplication.DebugWindow.addText("actions detected:"+(((InterfaceIcon)sender).uniqueName)+" : "+isActions);
										 
									 } else {
										 
										 MyApplication.DebugWindow.addText(isActions+"no actions:"+Actions);
											
										 ((InterfaceIcon)sender).nextFrameLoop();
									 }
									 
								 //run actions
								 if ( (!(Actions.compareTo("none")==1))&&(Actions.length()>4) ){
									 
									 String justActions=Actions;
									//check for condictionals
									//	if (Actions.startsWith("(")){
									//		String Conditionals = mouseoverActions.split("\\(.*\\)", 2)[0];
									//		justActions = mouseoverActions.split("\\(.*\\)", 2)[1];
											
									//		Log.info("conditionals="+Conditionals);									
									//		Log.info("actions="+Actions);
											
												
									//	}
									 //
									 
									 //update last clicked variables so that popups can be positioned correctly if used
									 MyApplication.lastclicked_x = imagegroupframe.getWidgetLeft(sender)+(sender.getOffsetWidth()/2);								 
									 MyApplication.lastclicked_y = imagegroupframe.getWidgetTop(sender)+(sender.getOffsetHeight()/2);
									 MyApplication.lastclicked_item = thisframe;
									 
									 //process the instructions
									 MyApplication.DebugWindow.addText(" processing from image click ");
										
								 MyApplication.processInstructions(justActions,"TIG:"+CoreName+","+newItem.basefilename);
								 
								 
								 }	
								 
								 
							}
							
						});
						
						
						
						
					}
					
					//check for solution
					if(item_list.indexOf("- CheckTIG")>-1) {
						solutionpresent = false;
						submitans.removeFromParent();
					}
					
					if (item_list.indexOf("- TIGMessage")>-1){
						 messageboxpresent=true;
						 TiGFeedback.setVisible(true);
					} 
						
				
				}

		      });
				
		}catch (RequestException ex) {
			System.out.println(" cant item ini");
		}
		
	
		//Then we get the TIS's item ini
		String SolutionsIni = GWT.getHostPageBaseURL()+"InventoryItems/"+ItemName+"/"+ItemName+"_solutions.ini";
		
		
		RequestBuilder requestSolutions = new RequestBuilder(RequestBuilder.GET,SolutionsIni);
		try {
			requestSolutions.sendRequest("", new RequestCallback() {
		        public void onError(Request request, Throwable exception) {
		        	MyApplication.DebugWindow.addText("error in user logged in test");
		        	solutionpresent = false;
		        	submitans.removeFromParent();
		        }

				public void onResponseReceived(Request request,
						Response response) {
					
					solution_script = response.getText();

					MyApplication.DebugWindow.addText("solutions found"+solution_script);
					
					if (solution_script.toLowerCase().startsWith("none")){
						solutionpresent = false;
						submitans.removeFromParent();
					} else {
					
						 	
						
				    submitans.addClickHandler(new ClickHandler(){

						public void onClick(ClickEvent event) {
							
							testCombination();
							
							
							
						}
				    	
				    });
				    
				    
				    if (solution_script.indexOf("- TIGMessage")>-1){
						 messageboxpresent=true;
						 TiGFeedback.setVisible(true);
					} 
				    
					}
				}

		      });
				
		}catch (RequestException ex) {
			MyApplication.DebugWindow.addText(" cant item ini");
			solutionpresent = false;
			submitans.removeFromParent();
		}
		
		
		
		
		
		
	}

	protected void reSizePopUp() {
		
		Background.setWidth(Original_picX + "px");
		Background.setHeight(Original_picY + "px");
		
		Background.getParent().setWidth(Original_picX + "px");
		Background.getParent().setHeight(Original_picY + "px");
		
		/*
		// screen size
		ScreenSizeX = Window.getClientWidth();
		ScreenSizeY = Window.getClientHeight();

		// image loaded
		picY = Original_picY;
		picX = Original_picX;
		System.out.print("\n /n <<<<<<<<<<<<<<<<<<<<<<<image loaded []" + picX
				+ "-" + picY);

		// cancel timer
		if (Original_picX > 5) {
			timer.cancel();
		}

		// Resize the picture if its over 80% of the screen size

		if (picX > (ScreenSizeX * 0.8)) {

			Background.setHeight(picY * ((ScreenSizeX * 0.8) / picX) + "px");

			System.out.println("ratio=" + picX + ">" + (ScreenSizeX * 0.8));
			picX = (int) Math.round(ScreenSizeX * 0.8);
			Background.setWidth(picX + "px");

		} else if (Original_picX > 5) {

			Background.setWidth(Original_picX + "px");
			Background.setHeight(Original_picY + "px");
		}
		// then match the frame to fit

		ImageDiscription.setHeight("100%");
		int NewFrameWidth = (Background.getOffsetWidth() + 0);
		Background.getParent().setWidth(NewFrameWidth + "px");
		
		int NewFrameHeight = getOffsetHeight();

		// and the shadow container
		// bigPicture.getParent().getParent().setWidth(20+NewFrameWidth+"px");

		// re center

		// test it isnt bigger then the screen.
		if (NewFrameHeight > ScreenSizeY) {
			posY = ((ScreenSizeY / 2) - (NewFrameHeight / 2))
					+ ((NewFrameHeight - ScreenSizeY) / 2);

		} else {
			posY = (ScreenSizeY / 2) - (NewFrameHeight / 2);
		}

		// --
		((hasCloseDefault) (Background.getParent())).CloseDefault();
		((hasOpenDefault) (Background.getParent())).OpenDefault();

		// RootPanel.get().remove(bigPicture.getParent().getParent());
		// RootPanel.get().add(bigPicture.getParent().getParent(),
		// (ScreenSizeX/2)-(NewFrameWidth/2),posY );

		// adjust parents topbar size
		// ((PopUpWithShadow)(this.getParent())).TopBar.setWidth((this.getOffsetWidth()-80)+"px");

		// adjust fader size
		// MyApplication.fadeback.setSize("100%",900+"px");
		System.out.println("Screen Height="
				+ RootPanel.getBodyElement().getOffsetHeight());
				*/
	}

	public void RecheckSize() {

	
	//	reSizePopUp();

	}
	
	public void setItemState(String itemnamesearch, String state) {

		//if item name is a png;
		
		if (itemnamesearch.toLowerCase().endsWith("png"))
		{
		//search for this
		String itemname = itemnamesearch.substring(0,itemnamesearch.length()-5);
		MyApplication.DebugWindow.addText("\n setting item-"+itemname);
		MyApplication.DebugWindow.addText("\n checking-"+TIGitems.size()+"-");
		
		//search for item matching itemname
		Iterator <InterfaceIcon>itemit = TIGitems.iterator();
		
		while(itemit.hasNext()){			
			InterfaceIcon testhis = itemit.next();
			MyApplication.DebugWindow.addText("\n compare to-"+testhis.basefilename);
			
			if (testhis.basefilename.endsWith(itemname.trim())){				
				//MyApplication.DebugWindow.addText("\n setting -"+testhis.basefilename);
				setItems(testhis,state);
				
				//break;
			}
			
		}
		} else {
			//we assume its an ID name.
			String itemname = itemnamesearch;
			MyApplication.DebugWindow.addText("\n setting item-"+itemname);
			MyApplication.DebugWindow.addText("\n checking-"+TIGitems.size()+"-");
			
			Iterator <InterfaceIcon>itemit = TIGitems.iterator();
			
			while(itemit.hasNext()){			
				InterfaceIcon testhis = itemit.next();
				MyApplication.DebugWindow.addText("\n compare to-"+testhis.basefilename);
				
				if (testhis.uniqueName.equalsIgnoreCase(itemname.trim())){				
					//MyApplication.DebugWindow.addText("\n setting -"+testhis.basefilename);
					setItems(testhis,state);
					
					//break;
				}
				
			}
			
		}
		
		
		
		

	}

	public void setItems(InterfaceIcon icontochange, String state) {
				
		//set Items based on state
		MyApplication.DebugWindow.addText("\n setting :"+icontochange.basefilename+" to "+state);
		
		if (state.compareTo("PlayForward")==0){
		icontochange.setAnimateOpen();
		} else if(state.compareTo("PlayBounce")==0){
		icontochange.setAnimateOpenThenClose();
		} else if(state.compareTo("PlayBack")==0){
		icontochange.setAnimateClose();	
		} else if(state.compareTo("NextFrameLoop")==0){
		icontochange.nextFrameLoop();
		
		} else if(state.compareTo("PrevFrameLoop")==0){
		icontochange.prevFrameLoop();
		} else if(state.compareTo("PlayForwardXframes")==0){
			//5 needs to be changed to variable number
		icontochange.playForwardXframes(4);
		}
	}
	public void CloseDefault() {
		// TODO Auto-generated method stub
		
	}
	public void OpenDefault() {
		// TODO Auto-generated method stub
		
	}
	public String POPUPTYPE() {
		// TODO Auto-generated method stub
		return "TIG";
	}
	public boolean POPUPONCLICK() {
		return true;
	}
	public void testCombination() {
		
		//First we get the states of all current items in the absolute panel.
		String allcurrenttstates = "";
		
		Iterator<InterfaceIcon> TIGitems_it = TIGitems.iterator();
		while (TIGitems_it.hasNext()){
			
			String currentstate = TIGitems_it.next().getUrl();
			
			//we just want the filename
			currentstate=currentstate.substring( currentstate.lastIndexOf("/")+1 ).trim();
			
			allcurrenttstates = allcurrenttstates + "~~"+currentstate+"~~";								
			
			
		}
		System.out.print(allcurrenttstates);
		
		
		//Now we test them against the reponse's
		
		
		
			
		//loop for each ans line;
		int starthere=0;
		int cpos =0;
		int nextansstart =0;
		int linestarthere=0;
		String currentline = ""; 
		String state =  "";
		boolean correct_ans =false;
		
		checkansloop:
		while (solution_script.indexOf("ans:", starthere)>-1  ){
			
			currentline="";
			
			//loop for each ans in line;
			cpos = solution_script.indexOf("ans:", starthere)+4 ;
			currentline = solution_script.substring(cpos, solution_script.indexOf("\n", cpos)).trim();
			//System.out.print("\n-"+currentline);
			
			//now with this line, I do loop to see if all answers lie...
			linestarthere=0;
			correct_ans =true;
			linecheck:
			do {
				
								
				// get image state
				nextansstart =  currentline.indexOf("+",linestarthere);
				if (nextansstart==-1){
					nextansstart =  currentline.length();
				}		
				state =   currentline.substring(linestarthere,nextansstart).trim();
				
				// check for an =, which indicates a specific icon is specified
				if (state.contains("=")){
				
					//split around =
					String requiredNameID = state.split("=")[0].trim();
					String requiredState = state.split("=")[1].trim();					
						
					MyApplication.DebugWindow.addText("searching for "+requiredNameID+" set to "+requiredState);
					
					//look up item that corisponds to left side
					//search for item matching itemname
					Iterator <InterfaceIcon>itemit = TIGitems.iterator();	
					String currentItemsState = "";
					while(itemit.hasNext()){	
						InterfaceIcon currentItem = itemit.next();	
						MyApplication.DebugWindow.addText("<br> testing: "+currentItem.uniqueName+": ");
						
						if (currentItem.uniqueName.equalsIgnoreCase(requiredNameID)){
							currentItemsState = currentItem.getUrl();

							//we just want the filename
							currentItemsState=currentItemsState.substring( currentItemsState.lastIndexOf("/")+1 ).trim();
							
							MyApplication.DebugWindow.addText(" found: "+currentItemsState+":");	
							break;
						}
					}					
					
					//see if its currently set to the right state
					if (!(currentItemsState.trim().equals(requiredState))){
						//if its not then we skip this loop
						correct_ans = false;
						System.out.print("wrong");
						break linecheck;
						
					}
					
					
				} else { 
				
				// else we default to just checking something is at that state
				//we check if the state is in the allcurrenttstates
				System.out.print("\n checking :"+state+"  in  "+allcurrenttstates+"\n");
				if (allcurrenttstates.indexOf("~"+state+"~")==-1){
					//if its not then we skip this loop
					correct_ans = false;
					System.out.print("wrong");
					break linecheck;
				}
				
				}
				linestarthere = nextansstart+1;
				
			} while ( currentline.indexOf("+",linestarthere-1)>-1);
			
			
			if (correct_ans==true){
				
				System.out.print("CORRRRECTTT!!!");
				
				//we then get the ans strings and process them...just like other answers!
				int endans = solution_script.indexOf("ans", cpos);
				if (endans == -1){
					endans = solution_script.length();
				}
				String instructionset = solution_script.substring(solution_script.indexOf("\n", cpos)+1,endans).trim(); 
				
				System.out.print("\n Processing:"+instructionset);
				
				MyApplication.processInstructions(instructionset,"TIG:"+CoreName+",CorrectAns");
				
				break checkansloop;
				
			}
			
			starthere=cpos+1;
			
			
			
		}
		
		
		
		//if no correct
		
		
	}

	public boolean DRAGABLE() {
		return true;
	}

	public boolean MAGNIFYABLE() {
		return Magnifable ;
	}

	public String SourceURL() {
		return sourceurl;
	}

	public String sourcesizeX() {
		return ""+sourcesizeX;
	}

	public String sourcesizeY() {
		return ""+sourcesizeY;
	}
	
}
