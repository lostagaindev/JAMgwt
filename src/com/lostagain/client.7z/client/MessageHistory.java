package com.darkflame.client;

import java.util.ArrayList;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class MessageHistory  extends VerticalPanel {
	
	//message array
	final static ArrayList<String> messagehistory = new ArrayList<String>();
	private static int currentmessage;
    //container scroller
	ScrollPanel MessageHistoryScroller = new ScrollPanel();
	//internal HTML
	HTML messageslist = new HTML("Message Log;");
	
	final static Image printicon = new Image("GameIcons/Printer.png");
	
	public MessageHistory(){
		
		MessageHistoryScroller.add(messageslist);
		this.add(printicon);
		this.setCellHorizontalAlignment(printicon,HasHorizontalAlignment.ALIGN_RIGHT);
		this.add(MessageHistoryScroller);
		MessageHistoryScroller.setSize("100%", "281px");
		
		
		//add print function
		printicon.addClickHandler(new ClickHandler(){

			public void onClick(ClickEvent event) {
				
				
				
				
				//openWindow("scripts/printthis.php"+"?text="+messageslist.getText());
				MyApplication.DebugWindow.setText("blah");
				//popupWindowWithString(" test string  123 ");

				// TODO Auto-generated method stub
				RequestBuilder printthis = new RequestBuilder(RequestBuilder.POST,"Login_System/UpdateHistoryTemp.php");
				try {
				      printthis.sendRequest("MessageHistory=" + MyApplication.messagehistory.getHTML(), new RequestCallback() {
				        public void onError(Request request, Throwable exception) {
				        	MyApplication.messagehistory.AddNewMessage("Failed to Open new Print Window");
				        }

						public void onResponseReceived(Request request,
								Response response) {
							
							
							Window.open("scripts/displayhistory.php", "_blank", "");
						
						}

				      });
				
				}catch (RequestException ex) {
					System.out.println(" cant check login, assume new user");
				}
			}
			
		});
		
	}
	native void openWindow(String param) /*-{ 
    $wnd.open('scripts/printthis.php' + '?text=' +param, '_blank', null); 
    popup.getElementById('idShowText').innerHTML();
    return true;
}-*/;
	
	public String getText(){
		return messageslist.getText();
	}
	public String getHTML(){
		return messageslist.getHTML();
	}
	public void AddNewMessage(String newMessage){
		
		messagehistory.add(newMessage);
		messageslist.setHTML( messageslist.getHTML()+"<br>"+newMessage );
		currentmessage=messagehistory.size();
		
	}
	public  void AddNewMessage_notrecorded(String newMessage){
		
		//for adding a message to the box, but not the history array		
		messageslist.setHTML( messageslist.getHTML()+"<br>"+newMessage );
		
	}
	public void scrolltobottom(){
		MyApplication.DebugWindow.addText("scrolldown");
		MessageHistoryScroller.scrollToBottom();
		
	}
	
	public static String getlastmessage(int Steps){
		return messagehistory.get(messagehistory.size()-(Steps+1));
	}
	public static String getprevmessage(){
		currentmessage=currentmessage-1;
		if (currentmessage<=0){
			currentmessage=0;
		}
		return messagehistory.get(currentmessage-1);
	}
	public static String getnextmessage(){
		currentmessage=currentmessage+1;
		if (currentmessage>messagehistory.size()){
			currentmessage=messagehistory.size();
		}
		return messagehistory.get(currentmessage-1);
		
	}
	  public final native void popupWindowWithString(String name) /*-{
	    var popup = $wnd.open('scripts/printthis.php', '_blank', null);
		popup.document.getElementById('idShowText').innerHTML="someText";
		
	    return;
	  }-*/;
}
