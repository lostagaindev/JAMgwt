package com.darkflame.client;

import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.Image;

public class InterfaceIcon extends Image {

	int frametotal = 1;
	int currentframe = 0;

	// you can assign a unique name to this icon, to help finding it later in a
	// list of icons
	String uniqueName = "";

	String animation_direction = "open";
	String basefilename = "";
	String originalfilename = "";

	String currentfilename = "";
	String filenameext = "png";
	boolean close_after_open = false;
	final Timer timer;
	// image array
	int playuntill = 100 + frametotal;

	private boolean loop = false;
	private boolean currentlyAnimating = false;

	// This is a special image that supports animations to be trigged when its
	// rolled over.
	public InterfaceIcon(String FileZeroLocation, int NumOfFrames) {

		this.setUrl(FileZeroLocation);
		currentfilename = FileZeroLocation;
		// this.setWidth("100%");

		this.setUrl(FileZeroLocation);
		frametotal = NumOfFrames - 1;
		basefilename = FileZeroLocation.substring(0, (FileZeroLocation
				.indexOf(".") - 1));

		originalfilename = FileZeroLocation.substring(FileZeroLocation
				.lastIndexOf("/") + 1, (FileZeroLocation.indexOf(".")));

		filenameext = FileZeroLocation
				.substring(FileZeroLocation.indexOf(".") + 1);

		// preload all images

		for (int cp = 0; cp < frametotal; cp = cp + 1) {

			Image.prefetch((basefilename + "" + cp + "." + filenameext));

		}

		final InterfaceIcon ThisIcon = this;

		timer = new Timer() {

			@Override
			public void run() {
				
				currentlyAnimating = true;
				// first we check if the previous icon is loaded, if not, we
				// wait.

				currentfilename = basefilename + "" + currentframe + "."
						+ filenameext;
				ThisIcon.setUrl(currentfilename);

				MyApplication.DebugWindow.addText("setting icon url="
						+ basefilename + "" + currentframe + "." + filenameext);

				if (animation_direction.compareTo("open") == 0) {
					currentframe = currentframe + 1;

				} else if (animation_direction.compareTo("close") == 0) {
					currentframe = currentframe - 1;

				}

				// if out of range then stop, unless loop is set

				if (currentframe < 0) {

					if (loop) {
						currentframe = frametotal;
					} else {
						currentframe = 0;
						// MyApplication.DebugWindow.addText("animation stoped
						// due to frame less then zero");
						this.cancel();
						currentlyAnimating = false;
					}

				}
				if (currentframe == playuntill + 1) {
					currentframe = playuntill;
					playuntill = 100 + frametotal;
					this.cancel();
					currentlyAnimating = false;
					// MyApplication.DebugWindow.addText("animation stoped due
					// to frame more then play untill");
				}
				if (currentframe > frametotal) {
					currentframe = frametotal;

					if (close_after_open == true) {
						animation_direction = "close";
						close_after_open = false;
					} else if (loop == true) {
						currentframe = 0;
					} else if (loop == false) {
						this.cancel();
						currentlyAnimating = false;
						MyApplication.DebugWindow
								.addText("animation stoped due to frame at end and no loop set");

					}

				}
				// Image.prefetch(basefilename+""+currentframe+"."+filenameext);
			}
		};
	}

	public void setURL(String FileZeroLocation, int NumOfFrames) {

		this.setUrl(FileZeroLocation);
		frametotal = NumOfFrames - 1;
		basefilename = FileZeroLocation.substring(0, (FileZeroLocation
				.indexOf(".") - 1));
		filenameext = FileZeroLocation
				.substring(FileZeroLocation.indexOf(".") + 1);
		originalfilename = FileZeroLocation.substring(FileZeroLocation
				.lastIndexOf("/") + 1, (FileZeroLocation.indexOf(".")));

		// preload all images

		for (int cp = 0; cp < frametotal; cp = cp + 1) {

			Image.prefetch((basefilename + "" + cp + "." + filenameext));

		}

	}

	@Override
	public String getUrl() {
		return currentfilename;
	}

	public void setAnimateOpen() {
		loop = false;
		animation_direction = "open";
		timer.scheduleRepeating(50);

	}

	public void setAnimateLoop() {

		animation_direction = "open";
		loop = true;
		timer.scheduleRepeating(50);

	}

	public void setAnimateClose() {

		animation_direction = "close";
		loop = false;
		timer.scheduleRepeating(50);
	}

	public void setAnimateOpenThenClose() {
		loop = false;
		animation_direction = "open";
		close_after_open = true;
		timer.scheduleRepeating(100);
		playuntill = 100 + frametotal;

	}

	public void playUntill(int frame) {

		loop = false;
		playuntill = frame;
		animation_direction = "open";
		timer.scheduleRepeating(50);
	}

	public void playForwardXframes(int frames) {

		if (currentlyAnimating == false) {
			loop = true;
			playuntill = currentframe + frames;
			if (playuntill > frametotal) {
				playuntill = playuntill - (frametotal + 1);
			}
			close_after_open = false;
			animation_direction = "open";

			timer.scheduleRepeating(100);
		}

	}

	public void nextFrameLoop() {

		currentframe = currentframe + 1;

		if (currentframe > frametotal) {
			currentframe = 0;
		}
		currentfilename = basefilename + "" + currentframe + "." + filenameext;
		this.setUrl(currentfilename);
		// MyApplication.DebugWindow.addText("set frame to:"+currentfilename);
		System.out.print(basefilename + "" + currentframe + "." + filenameext);
	}

	public void prevFrameLoop() {

		currentframe = currentframe - 1;
		if (currentframe < 0) {
			currentframe = frametotal;
		}
		currentfilename = basefilename + "" + currentframe + "." + filenameext;
		this.setUrl(currentfilename);
		System.out.print(basefilename + "" + currentframe + "." + filenameext);
	}

	public void nextFrame() {

		currentframe = currentframe + 1;
		if (currentframe > frametotal) {
			currentframe = frametotal;
		}
		currentfilename = basefilename + "" + currentframe + "." + filenameext;
		this.setUrl(currentfilename);
		System.out.print(basefilename + "" + currentframe + "." + filenameext);
	}

	public void firstFrame() {

		currentframe = 0;
		currentfilename = basefilename + "" + currentframe + "." + filenameext;
		this.setUrl(currentfilename);
		System.out.print(basefilename + "" + currentframe + "." + filenameext);
	}
}
