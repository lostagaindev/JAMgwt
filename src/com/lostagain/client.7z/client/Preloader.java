package com.darkflame.client;

import java.util.ArrayList;
import java.util.Iterator;

import com.google.gwt.event.dom.client.LoadEvent;
import com.google.gwt.event.dom.client.LoadHandler;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.RootPanel;

public class Preloader {
	final static ArrayList<String> HtmlItems = new ArrayList<String>();
	final static ArrayList<String> HtmlFileNames = new ArrayList<String>();
	
	
	final static ArrayList<String> LoadingList = new ArrayList<String>();
	
	
	public Preloader(String LoadingString){
		/*
		//split up to array
		List<String> LoadingList = Arrays.asList(  LoadingString.split("\n")  );
		

		System.out.print("preloading..."+LoadingList.size());
		
		ArrayList<String> LoadingArrayList =new ArrayList<String>(LoadingList); 

		System.out.print("preloading..."+LoadingArrayList.size());
				
		Iterator<String> it = (LoadingList.iterator());
		
		//loop over
		while (it.hasNext()) {

			
			//for each image, we preload			
		String preloadthis = it.next().trim();
	
		if (preloadthis.toLowerCase().endsWith("jpg")){
			PreloadImage(preloadthis);	
		}
		
		if (preloadthis.toLowerCase().endsWith("png")){
			PreloadImage(preloadthis);
		}
		if (preloadthis.toLowerCase().endsWith("gif")){
			PreloadImage(preloadthis);
		}
		}
		
		*/
	}
	
	static public void addToLoading(String URL){
		LoadingList.add(URL);
	MyApplication.DebugWindow.addText("<br>-=-add image to preload"+URL );
		//Window.alert("<br>-=-add image to preload"+URL );
	}
	
	
	public static void preloadList(){
		
		//This loops over the preload list
		//When each entry is loaded, its removed from the list
		//and the next item loaded.
		MyApplication.DebugWindow.addText("<br>-=-loading images:" );
		
	//	Window.alert("<br>preloading list");
		
		final Image LoadThis = new Image();
		RootPanel.get().add(LoadThis,-12000,-12000);
		
		LoadThis.setStylePrimaryName("hiddenImagePanel");
		LoadThis.setUrl(LoadingList.get(0));
		
		LoadThis.addLoadHandler(new LoadHandler(){
			public void onLoad(LoadEvent event) {
				MyApplication.DebugWindow.addText("<br>-=-Loaded:"+LoadThis.getUrl() );
				// remove from list
				LoadingList.remove(0);
				
				if (LoadingList.size()==0){
					return;
				}
				//load the next;
				LoadThis.setUrl(LoadingList.get(0));
				
			}
			
		});
		
		
		
		

	}
	
	
	
	
	
	
	
	
	public void PreloadImage(String URL){
		//base image
		
		Image.prefetch(URL);
		//get route name
		
		//String filename = URL.substring(URL.lastIndexOf("/")+1);
		//String loc = URL.substring(0, URL.lastIndexOf("/")+1);

		MyApplication.DebugWindow.addText("preloaded..."+URL);		

		
	}
	
	
	public void AddItem(String newitem, String newname){
		HtmlItems.add(newitem);
		HtmlFileNames.add(newname);
	}
	public void RemoveItem(String removethisitem){
		//find location
		int i=0;
		int indextoremove = -1;
		for (Iterator<String>it = HtmlFileNames.iterator(); it.hasNext(); ) {
			  String currentItem = it.next(); 
			  if (currentItem.compareTo(removethisitem)==0){
				  indextoremove=i;
			  };
			  i=i+1;
			
		}
		//if present
		if (indextoremove>-1){
		HtmlItems.remove(indextoremove);
		HtmlFileNames.remove(indextoremove);
		}
	}
	public String GetItem(String ItemName){
		String Item = "";
		//find location
		int i=0;
		int itemindex = -1;
		for (Iterator<String>it = HtmlFileNames.iterator(); it.hasNext(); ) {
			  String currentItem = it.next(); 
			  if (currentItem.compareTo(ItemName)==0){
				  itemindex=i;
			  };
			  i=i+1;
			
		}
		//if present
		if (itemindex>-1){
			Item = HtmlItems.get(itemindex);
		} else {
			Item = "";
		}
			
		
		return Item;
	}
	
}
