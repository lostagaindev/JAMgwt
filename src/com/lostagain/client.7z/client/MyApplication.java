package com.darkflame.client;

import com.allen_sauer.gwt.voices.client.SoundController;




import com.allen_sauer.gwt.log.client.Log;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.allen_sauer.gwt.voices.client.Sound;
import com.darkflame.client.InventoryPanel;
import com.google.gwt.dom.client.Document;
import com.google.gwt.dom.client.Style;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.event.dom.client.MouseOutEvent;
import com.google.gwt.event.dom.client.MouseOutHandler;
import com.google.gwt.event.dom.client.MouseOverEvent;
import com.google.gwt.event.dom.client.MouseOverHandler;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.http.client.URL;
import com.google.gwt.i18n.client.HasDirection.Direction;


import com.google.gwt.user.client.ui.DecoratedTabPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DisclosurePanel;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.SimplePanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.Window;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class MyApplication implements EntryPoint, ValueChangeHandler<String>  {

	//home directory
	static String homeurl = GWT.getHostPageBaseURL();
	//static String homeurl = "http://www.lostagain.nl/Jarg Demo/AMemorableDay/";
	
	
	//global games running flag
	static boolean GamesRunning = false;
	// This is only false at the start while loading.
	
	
	// debug window
	final static debugWindow DebugWindow = new debugWindow();

	// images
	static JargImages JargStaticImages = (JargImages) GWT
			.create(JargImages.class);

	static String controllscript = ""; //$NON-NLS-1$
	static GamesAnswerStore gamesAnswerStore;
	
	
	static String itemmixscript = ""; //$NON-NLS-1$	
	static String location = ""; //$NON-NLS-1$

	static// player data
	String Username = "The Player"; //$NON-NLS-1$
	static String Organisation = ""; //$NON-NLS-1$
	static String Client = ""; //$NON-NLS-1$
	static String InterfaceSize = "Default"; //$NON-NLS-1$

	static HTML MainStoryText = new HTML();

	static //array of widget names to be added to story text when new text loads;
	ArrayList<String> widgets_to_add_ids = new ArrayList<String>();
	
	// users variables array
	static AssArray GameVariables = new AssArray();

	// storytext array
	static AssArray StoryTextStore = new AssArray();

	final static TextBox AnswerBox = new TextBox();
	static final TypedLabel Feedback = new TypedLabel(""); //$NON-NLS-1$
	static final VerticalPanel FeedbackContainer = new VerticalPanel();
	
	static final LoginBox user_login = new LoginBox();

	// Chapter list
	static VerticalTabs ChapterList = new VerticalTabs();

	// Preloader
	static Preloader GamePreloader;

	final Label LocationLabel = new Label("Locations;"); //$NON-NLS-1$
	// private static boolean StartFromURL = false;
	// private static boolean newplayer = false;

	// story current locations
	static DecoratedTabPanel StoryTabs = new DecoratedTabPanel();

	// list of opened pages in active chapter
	final static ArrayList<String> openPages = new ArrayList<String>();
	final static ArrayList<String> locationpuzzlesActive = new ArrayList<String>();

	// list of opened chapters
	final static ArrayList<LocationTabSet> AllLocationTabSets = new ArrayList<LocationTabSet>();

	// current chapters locations
	static LocationTabSet CurrentLocationTabs = new LocationTabSet();
	static int CurrentLocationTabsIndex = 0;

	// multimessage place array
	static AssArray MultiMessagePlace = new AssArray();

	// fader
	final static public fader fadeback = new fader();

	// fader
	final static public SpiffyImage loginbackground = new SpiffyImage();

	// Get size string from css
	public static String iconsizestring = ""; //$NON-NLS-1$

	//decoration images
	static AbstractImagePrototype[] LadyClockSmall =  {AbstractImagePrototype.create(JargStaticImages.StatueHeadSmall())};
	static AbstractImagePrototype[] LadyClockMid = {AbstractImagePrototype.create(JargStaticImages.StatueHeadMid())};
	static AbstractImagePrototype[] LadyClockBig = {AbstractImagePrototype.create(JargStaticImages.StatueHeadBig())};
		
	static AbstractImagePrototype[] LadyFeatSmall = {AbstractImagePrototype.create(JargStaticImages.StatueFeatSmall())};
	static AbstractImagePrototype[]  LadyFeatMid = {AbstractImagePrototype.create(JargStaticImages.StatueFeatMid())};
	static AbstractImagePrototype[]  LadyFeatBig = {AbstractImagePrototype.create(JargStaticImages.StatueFeatBig())};
	
	static AbstractImagePrototype[]  SoldierSmall = {AbstractImagePrototype.create(JargStaticImages.SoldierSmall())};
	static AbstractImagePrototype[]  SoldierMid = {AbstractImagePrototype.create(JargStaticImages.SoldierMid())};
	static AbstractImagePrototype[]  SoldierBig = {AbstractImagePrototype.create(JargStaticImages.SoldierBig())};
	
	// decoration Icons
	final static public SpiffyIcon StatueFeat = new SpiffyIcon(
			LadyFeatBig); 
	final static public SpiffyIcon StatueHead = new SpiffyIcon(
			LadyClockBig); 
	final static public SpiffyIcon solider = new SpiffyIcon(SoldierBig); 
	
	//Top Strip, containing the title, score, but etc (left to right)
	
	//Leftmost Bit
	final static AbstractImagePrototype BigLeftBit = AbstractImagePrototype.create(JargStaticImages.BIGTitleStripleftbit());
	final static AbstractImagePrototype MediumLeftBit = AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStripleftbit());
	final static AbstractImagePrototype SmallLeftBit = AbstractImagePrototype.create(JargStaticImages.SMALLTitleStripleftbit());	
	final static Image LeftBit = BigLeftBit.createImage();
	
	//OpenClueBox
	final static AbstractImagePrototype  BigOpenClueBox = AbstractImagePrototype.create(JargStaticImages.BIGTitleStripleftOpen());
	final static AbstractImagePrototype  MediumOpenClueBox= AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStripleftOpen());
	final static AbstractImagePrototype  SmallOpenClueBox = AbstractImagePrototype.create(JargStaticImages.SMALLTitleStripleftOpen());	
	static AbstractImagePrototype  OpenClueBoxButton = BigOpenClueBox;
	static Image OpenClueBox = OpenClueBoxButton.createImage();
	
	//CloseClueBox
	final static AbstractImagePrototype BigCloseClueBox =AbstractImagePrototype.create(JargStaticImages.BIGTitleStripleftClose());
	final static AbstractImagePrototype MediumCloseClueBox= AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStripleftClose());
	final static AbstractImagePrototype SmallCloseClueBox =AbstractImagePrototype.create( JargStaticImages.SMALLTitleStripleftClose());
	static AbstractImagePrototype CloseClueBoxButton = BigOpenClueBox;
	static AbstractImagePrototype CloseClueBox = CloseClueBoxButton;
	
	//Buy bit
	final static AbstractImagePrototype BigBuyOpenButton = AbstractImagePrototype.create(JargStaticImages.BIGTitleStrip_buy());
	final static AbstractImagePrototype MediumBuyOpenButton = AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStrip_buy());
	final static AbstractImagePrototype SmallBuyOpenButton = AbstractImagePrototype.create(JargStaticImages.SMALLTitleStrip_buy());	
	//final static Image LeftBuyButtonOpen = BigOpenButton.createImage();
	static AbstractImagePrototype  BuyOpenButton = BigBuyOpenButton;
	static Image BuyBack = BuyOpenButton.createImage();
	
	//Buy bit closed
	final static AbstractImagePrototype BigBuyCloseButton =  AbstractImagePrototype.create(JargStaticImages.BIGTitleStrip_buyclose());	
	final static AbstractImagePrototype MediumBuyCloseButton =  AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStrip_buyclose());
	final static AbstractImagePrototype SmallBuyCloseButton =  AbstractImagePrototype.create(JargStaticImages.SMALLTitleStrip_buyclose());	
	//final static Image LeftBuyButtonOpen = BigOpenButton.createImage();
	static AbstractImagePrototype BuyCloseButton = BigBuyCloseButton;
	
	static Image BuyBackClosed = BuyCloseButton.createImage();
	
	
	
	//ScoreBack bit
	final static AbstractImagePrototype BigScoreBack =  AbstractImagePrototype.create(JargStaticImages.BIGTitleStrip_Scoreback());
	final static AbstractImagePrototype MediumScoreBack =  AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStrip_Scoreback());
	final static AbstractImagePrototype SmallScoreBack =  AbstractImagePrototype.create(JargStaticImages.SMALLTitleStrip_Scoreback());	
	static Image ScoreBack = BigScoreBack.createImage();
	
	//Backtexture
	static Image spacer =new Image("./GameIcons/BIG/TitleStrip.jpg");
	static Image TopStripBigGap = new Image("./GameIcons/BIG/TitleStrip.jpg");
	
	//Logo
	static AbstractImagePrototype[] BigCuypers2LogoImages = { 
		AbstractImagePrototype.create(JargStaticImages.BIGTitleStripRight0()),
		AbstractImagePrototype.create(JargStaticImages.BIGTitleStripRight1()),
		AbstractImagePrototype.create(JargStaticImages.BIGTitleStripRight2())};
	
	static AbstractImagePrototype[] MediumCuypers2LogoImages = { 
		AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStripRight0()),
		AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStripRight1()),
		AbstractImagePrototype.create(JargStaticImages.MEDIUMTitleStripRight2())};
	
	static AbstractImagePrototype[] SmallCuypers2LogoImages = { 
		AbstractImagePrototype.create(JargStaticImages.SMALLTitleStripRight0()),
		AbstractImagePrototype.create(JargStaticImages.SMALLTitleStripRight1()),
		AbstractImagePrototype.create(JargStaticImages.SMALLTitleStripRight2())};
	//--------------
	
	
	
	
	
	
	
	
	
	
	static SpiffyIcon Cuyperstitle = new SpiffyIcon(BigCuypers2LogoImages);
	
	final static SpiffyClock gwt_clock = new SpiffyClock(50, 50);
	
	
	// timers to animate icons above;
	static Timer Blinking;
	static Timer Cyclonish;

	// interface buttons
	

	// Inventory Images (Piere)
	static AbstractImagePrototype[] BigDefaultInventoryImages = {
		AbstractImagePrototype.create(JargStaticImages.BIGcc2rugzakje0()),
				AbstractImagePrototype.create(JargStaticImages.BIGcc2rugzakje1()),
						AbstractImagePrototype.create(JargStaticImages.BIGcc2rugzakje2()),
								AbstractImagePrototype.create(JargStaticImages.BIGcc2rugzakje3()),
										AbstractImagePrototype.create(JargStaticImages.BIGcc2rugzakje4()),
												AbstractImagePrototype.create(JargStaticImages.BIGcc2rugzakje5())};

	static AbstractImagePrototype[] MediumDefaultInventoryImages = {
			AbstractImagePrototype.create(JargStaticImages.MEDcc2rugzakje0()),
			AbstractImagePrototype.create(JargStaticImages.MEDcc2rugzakje1()),
			AbstractImagePrototype.create(JargStaticImages.MEDcc2rugzakje2()),
			AbstractImagePrototype.create(JargStaticImages.MEDcc2rugzakje3()),
			AbstractImagePrototype.create(JargStaticImages.MEDcc2rugzakje4()),
			AbstractImagePrototype.create(JargStaticImages.MEDcc2rugzakje5())};

	static AbstractImagePrototype[] SmallDefaultInventoryImages = {
			AbstractImagePrototype.create(JargStaticImages.SMALLcc2rugzakje0()),
			AbstractImagePrototype.create(JargStaticImages.SMALLcc2rugzakje1()),
			AbstractImagePrototype.create(JargStaticImages.SMALLcc2rugzakje2()),
			AbstractImagePrototype.create(JargStaticImages.SMALLcc2rugzakje3()),
			AbstractImagePrototype.create(JargStaticImages.SMALLcc2rugzakje4()),
			AbstractImagePrototype.create(JargStaticImages.SMALLcc2rugzakje5()) };
	
	// Inventory Images (Margr)
	static AbstractImagePrototype[] BigMarInventoryImages = {
			AbstractImagePrototype.create(JargStaticImages.BIGmagrietbag0()),
			AbstractImagePrototype.create(JargStaticImages.BIGmagrietbag1()),
			AbstractImagePrototype.create(JargStaticImages.BIGmagrietbag2()),
			AbstractImagePrototype.create(JargStaticImages.BIGmagrietbag3()),
			AbstractImagePrototype.create(JargStaticImages.BIGmagrietbag4()),
			AbstractImagePrototype.create(JargStaticImages.BIGmagrietbag5())};

	static AbstractImagePrototype[] MediumMarInventoryImages = {
			AbstractImagePrototype.create(JargStaticImages.MEDmagrietbag0()),
			AbstractImagePrototype.create(JargStaticImages.MEDmagrietbag1()),
			AbstractImagePrototype.create(JargStaticImages.MEDmagrietbag2()),
			AbstractImagePrototype.create(JargStaticImages.MEDmagrietbag3()),
			AbstractImagePrototype.create(JargStaticImages.MEDmagrietbag4()),
			AbstractImagePrototype.create(JargStaticImages.MEDmagrietbag5())};

	static AbstractImagePrototype[] SmallMarInventoryImages = {
			AbstractImagePrototype.create(JargStaticImages.SMALLmagrietbag0()),
			AbstractImagePrototype.create(JargStaticImages.SMALLmagrietbag1()),
			AbstractImagePrototype.create(JargStaticImages.SMALLmagrietbag2()),
			AbstractImagePrototype.create(JargStaticImages.SMALLmagrietbag3()),
			AbstractImagePrototype.create(JargStaticImages.SMALLmagrietbag4()),
			AbstractImagePrototype.create(JargStaticImages.SMALLmagrietbag5())};

	// final static public SpiffyIcon InventoryButton = new SpiffyIcon(
	// "GameIcons/BIG/cc2rugzakje0.png", 6); //$NON-NLS-1$
	
	//set to defaults
	static AbstractImagePrototype[] BigInventoryImages  = BigDefaultInventoryImages;;
	static AbstractImagePrototype[] MediumInventoryImages  = MediumDefaultInventoryImages;; 
	static AbstractImagePrototype[] SmallInventoryImages  = SmallDefaultInventoryImages;; 
	
	

	static public SpiffyIcon InventoryButton = new SpiffyIcon(
			BigDefaultInventoryImages); 
	
	//Notepad images
	static AbstractImagePrototype[] BigNotepadImages = {
		AbstractImagePrototype.create(JargStaticImages.BIGcc2notebook0()),
		AbstractImagePrototype.create(JargStaticImages.BIGcc2notebook1()),
		AbstractImagePrototype.create(JargStaticImages.BIGcc2notebook2()),
		AbstractImagePrototype.create(JargStaticImages.BIGcc2notebook3())
		};

static AbstractImagePrototype[] MediumNotepadImages = {
		AbstractImagePrototype.create(JargStaticImages.MEDIUMcc2notebook0()),
		AbstractImagePrototype.create(JargStaticImages.MEDIUMcc2notebook1()),
		AbstractImagePrototype.create(JargStaticImages.MEDIUMcc2notebook2()),
		AbstractImagePrototype.create(JargStaticImages.MEDIUMcc2notebook3())
		};

static AbstractImagePrototype[] SmallNotepadImages = {
		AbstractImagePrototype.create(JargStaticImages.SMALLcc2notebook0()),
		AbstractImagePrototype.create(JargStaticImages.SMALLcc2notebook1()),
		AbstractImagePrototype.create(JargStaticImages.SMALLcc2notebook2()),
		AbstractImagePrototype.create(JargStaticImages.SMALLcc2notebook3())
		};

	final static public SpiffyIcon NotepadButton = new SpiffyIcon(BigNotepadImages); 
	
	//ControllPanel images
static AbstractImagePrototype[] BigControllPanelImages = {
		AbstractImagePrototype.create(JargStaticImages.BIGCCtype0()),
		AbstractImagePrototype.create(JargStaticImages.BIGCCtype1()),
		AbstractImagePrototype.create(JargStaticImages.BIGCCtype2()),
		AbstractImagePrototype.create(JargStaticImages.BIGCCtype3()) 
		};

static AbstractImagePrototype[] MediumControllPanelImages = {
		AbstractImagePrototype.create(JargStaticImages.MEDIUMCCtype0()),
		AbstractImagePrototype.create(JargStaticImages.MEDIUMCCtype1()),
		AbstractImagePrototype.create(JargStaticImages.MEDIUMCCtype2()),
		AbstractImagePrototype.create(JargStaticImages.MEDIUMCCtype3())
		};

static AbstractImagePrototype[] SmallControllPanelImages = {
		AbstractImagePrototype.create(JargStaticImages.SMALLCCtype0()),
		AbstractImagePrototype.create(JargStaticImages.SMALLCCtype1()),
		AbstractImagePrototype.create(JargStaticImages.SMALLCCtype2()),
		AbstractImagePrototype.create(JargStaticImages.SMALLCCtype3())
		};

	final static public SpiffyIcon ControllPanelButton = new SpiffyIcon(BigControllPanelImages); 
	//Forum images
	static AbstractImagePrototype[] BigForumImages = {
			AbstractImagePrototype.create(JargStaticImages.BIGCC2forum0()),
			AbstractImagePrototype.create(JargStaticImages.BIGCC2forum1()),
			AbstractImagePrototype.create(JargStaticImages.BIGCC2forum2()),
			AbstractImagePrototype.create(JargStaticImages.BIGCC2forum3()) 
			};

	static AbstractImagePrototype[] MediumForumImages = {
			AbstractImagePrototype.create(JargStaticImages.MEDIUMCC2forum0()),
			AbstractImagePrototype.create(JargStaticImages.MEDIUMCC2forum1()),
			AbstractImagePrototype.create(JargStaticImages.MEDIUMCC2forum2()),
			AbstractImagePrototype.create(JargStaticImages.MEDIUMCC2forum3())
			};

	static AbstractImagePrototype[] SmallForumImages = {
			AbstractImagePrototype.create(JargStaticImages.SMALLCC2forum0()),
			AbstractImagePrototype.create(JargStaticImages.SMALLCC2forum1()),
			AbstractImagePrototype.create(JargStaticImages.SMALLCC2forum2()),
			AbstractImagePrototype.create(JargStaticImages.SMALLCC2forum3())
			};
	final static public SpiffyIcon ForumLinkButton = new SpiffyIcon(BigForumImages); 

	static AbstractImagePrototype[] LogBoekImages = {
		AbstractImagePrototype.create(JargStaticImages.logboek0()),
		AbstractImagePrototype.create(JargStaticImages.logboek1())};
	final static public SpiffyIcon MessageHistoryButton = new SpiffyIcon(LogBoekImages); 

	static AbstractImagePrototype[]  MessPrevImages = {
		AbstractImagePrototype.create(JargStaticImages.previous0()),
		AbstractImagePrototype.create(JargStaticImages.previous1())};
	final static public SpiffyIcon MessageBackButton = new SpiffyIcon(MessPrevImages); 
	
	static AbstractImagePrototype[]  MessNextImages = {
		AbstractImagePrototype.create(JargStaticImages.next0()),
		AbstractImagePrototype.create(JargStaticImages.next1())
		};
	
	final static public SpiffyIcon MessageForwardButton = new SpiffyIcon(MessNextImages); 
	
//Secrets
	static AbstractImagePrototype[] BigSecretsImages = {
			AbstractImagePrototype.create(JargStaticImages.BIGeasteregg0()),
			AbstractImagePrototype.create(JargStaticImages.BIGeasteregg1()),
			AbstractImagePrototype.create(JargStaticImages.BIGeasteregg2()),
			AbstractImagePrototype.create(JargStaticImages.BIGeasteregg3()),
			AbstractImagePrototype.create(JargStaticImages.BIGeasteregg4())
			};

	static AbstractImagePrototype[] MediumSecretsImages = {
			AbstractImagePrototype.create(JargStaticImages.MEDIUMeasteregg0()),
			AbstractImagePrototype.create(JargStaticImages.MEDIUMeasteregg1()),
			AbstractImagePrototype.create(JargStaticImages.MEDIUMeasteregg2()),
			AbstractImagePrototype.create(JargStaticImages.MEDIUMeasteregg3()),
			AbstractImagePrototype.create(JargStaticImages.MEDIUMeasteregg4())
			};

	static AbstractImagePrototype[] SmallSecretsImages = {
			AbstractImagePrototype.create(JargStaticImages.SMALLeasteregg0()),
			AbstractImagePrototype.create(JargStaticImages.SMALLeasteregg1()),
			AbstractImagePrototype.create(JargStaticImages.SMALLeasteregg2()),
			AbstractImagePrototype.create(JargStaticImages.SMALLeasteregg3()),
			AbstractImagePrototype.create(JargStaticImages.SMALLeasteregg4())
			};
	
	
	final static public SpiffyIcon SecretsPopupPanelButton = new SpiffyIcon(BigSecretsImages); 

	// interface icons
	// final static public InterfaceIcon LoadingBar = new
	// InterfaceIcon("GameIcons/loading0.png",7);

	// close all windows button
	static AbstractImagePrototype[] CloseAll = {
		AbstractImagePrototype.create(JargStaticImages.closeall0()),
		AbstractImagePrototype.create(JargStaticImages.closeall1()),
		AbstractImagePrototype.create(JargStaticImages.closeall2())
		};
	
	final static public SpiffyIcon closeallwindows = new SpiffyIcon(CloseAll);

	// inventory popups
	final static ControllPanel ControlPanel = new ControllPanel();
	final static PopUpWithShadow ControllPanelShadows = new PopUpWithShadow(
			null,
			"50%", "25%", LoadGamesText.MainGame_SaveOrLoadYourGame, ControlPanel); //$NON-NLS-1$ //$NON-NLS-2$ 

	final static InventoryPanel PlayersInventory = new InventoryPanel();
	final static PopUpWithShadow PlayersInventoryFrame = new PopUpWithShadow(
			null,
			"50%", "25%", LoadGamesText.MainGame_Inventory, PlayersInventory); //$NON-NLS-1$ 

	final static Notebook PlayersNotepad = new Notebook();
	final static PopUpWithShadow PlayersNotepadFrame = new PopUpWithShadow(
			null,
			"50%", "25%", LoadGamesText.MainGame_Charecter_Profiles, PlayersNotepad); //$NON-NLS-1$ 

	final static secretsPanel SecretPanel = new secretsPanel();
	final static PopUpWithShadow SecretPanelFrame = new PopUpWithShadow(null,
			"50%", "25%", LoadGamesText.MainGame_Secrets_Found, SecretPanel); //$NON-NLS-1$ 

	//clue(aka Joker Panel) panel
	final static CluePanel CluePopUp = new CluePanel();
	final static PopUpWithShadow CluePanelFrame = new PopUpWithShadow(null,
			"50%", "25%", "Clue Panel", CluePopUp); //$NON-NLS-1$ 

	
	
	// Message History
	final static MessageHistory messagehistory = new MessageHistory();

	final static Button EnterAns = new Button(LoadGamesText.MainGame_Submit);
	final static HorizontalPanel AnsBar = new HorizontalPanel();

	// interface open/close flag
	public static boolean InventoryOpen = false;
	public static boolean NotepadOpen = false;
	public static boolean ControllPanelOpen = false;

	public static boolean MessageHistoryOpen = false;
	public static boolean SecretsPanelOpen = false;

	// overlay popup list ;
	final static ArrayList<PopUpWithShadow> overlayPopUpsOpen = new ArrayList<PopUpWithShadow>();

	// locations
	public static final String textfetcher_url = homeurl+"text%20fetcher.php"; //$NON-NLS-1$
	public static final String emailer_url = homeurl+"Login_System/Emailer.php"; //$NON-NLS-1$

	// audio location
	public static final String audioLocation_url = homeurl+"audio/"; //$NON-NLS-1$

	// item locations
	static final String inventory_url = homeurl+"InventoryItems/"; //$NON-NLS-1$

	// item locations
	static final String notebookpages_url = homeurl+"NotebookPages/"; //$NON-NLS-1$

	// sound controller (for effects);
	static final SoundController soundController = new SoundController();

	// music box (for music)
	static final MusicBox musicPlayer = new MusicBox();
	static final SimpleEffectOverlay EffectOverlay = new SimpleEffectOverlay();

	static ArrayList<Sound> CurrentPlayingSounds = new ArrayList<Sound>();
	
	// max popup zdepth
	static int z_depth_max = 1050;

	// last clicked on X/Y/item
	static int lastclicked_x = 0;
	static int lastclicked_y = 0;
	static toggleimagegroupPopUp lastclicked_item;
	static Widget lastpopupmessage;
	static SpiffyArrow messageArrow;

	// player options

	static boolean SoundEffectOn = true;
	static boolean AnimationEffectsOn = true;
	static boolean autosaveon = false;
	
	static boolean loggedIn = false;
	
	// screen settings
	static int Story_Text_Height = 0;
	static int Story_Text_Width = 0;

	Timer ResizeOnLoad;


	private static boolean ScoreBoxVisible = true;
	private static int Game_Window_Width;
//	private static int Game_Window_Height;
	private static int testafter;

	// zoom fix toggle (this determains if +1 is added on the zoom image width,
	// to fix a loading bug)
	public static boolean zoomfixboolean = true;

	// All the games strings stored here;
	static LoadGamesText GamesText = new LoadGamesText();

	// Score/Joker and Clue dropdown
	public static final VerticalPanel ScoreAndClueBox = new VerticalPanel();

	// Clue disclosure
	public static final DisclosurePanel ClueReveal = new DisclosurePanel(
			"Clues:");

	// Clue box
	public static final ClueBox playersClues = new ClueBox();

	// Score and Jocker Container
	public static final HorizontalPanel ScoreAndJokerContainer = new HorizontalPanel();

	// Joker Button
	public static final Image Joker = new Image(JargStaticImages.questionmark());

	// Scoreboard
	public static final SpiffyScoreBoard PlayersScore = new SpiffyScoreBoard(
			"GameIcons/ScoreBox.jpg");
	// text store for scores awarded (to stop duplication
	public static String ScoresAwarded = "";
	
	//static //scorebox
	//Image ScoreBack = new Image("./GameTextures/TitleStrip_score.jpg");
//Image BuyBack = new Image("./GameTextures/TitleStrip_buy.jpg");
//Image ScoreBack = JargStaticImages.BIGTitleStrip_Scoreback().createImage();
	
	private static int NumberOfChaptersLeftToLoad;

	private static boolean triggerSelectCheck;

	private static String pageToSelect;
	
	static AssArray PageCommandStore = new AssArray();
	

	private static String CurrentBackground;


	// calculator
	public static final Calculator calc = new Calculator();

	// clock silly bit
	public static final Image clockpopup = new Image(JargStaticImages.stopthat());

	//Title Bar
	//TitleBar Left
	public static final HorizontalPanel TitleBarLeft = new HorizontalPanel();
	public static final HorizontalPanel TitleBarRight = new HorizontalPanel();
	
	public void onModuleLoad() {
		
		Log.info("game loading...");
		
		Log.info("t6       "+homeurl);
		
		// preload the images nesscery for login
		Image.prefetch("GameTextures/loginbox_back.jpg");
		
		
		//test asign inventory images to default		
		BigInventoryImages = BigDefaultInventoryImages;
		MediumInventoryImages = MediumDefaultInventoryImages;
		SmallInventoryImages = SmallDefaultInventoryImages;		
	
		// then we load the interface text (disabled temp)
		loadGamesText();

		//set client
		Client = SpiffyFunctions.getUserAgent();
		
		// Set loading text
		MainStoryText.setText(LoadGamesText.MainGame_Loading);
		Window.setTitle(LoadGamesText.MainGame_WindowTitle_Loading);

		// Store screen settings
		Story_Text_Height = RootPanel.get("bigtextbox").getOffsetHeight() - 2; //$NON-NLS-1$
		Story_Text_Width = RootPanel.get("bigtextbox").getOffsetWidth() - 2; //$NON-NLS-1$

		Game_Window_Width = Window.getClientWidth();
	//	Game_Window_Height = Window.getClientWidth();


		InventoryButton.setStyleName("IconPositionsInventory"); //$NON-NLS-1$
		NotepadButton.setStyleName("IconPositionsNotebook"); //$NON-NLS-1$
		ControllPanelButton.setStyleName("IconPositionsControllPanel"); //$NON-NLS-1$

		// test login
		test_for_logged_in_user();

		// disable button
		AnswerBox.setEnabled(false);

		// First we load the main control script

		startgamefromcontrollfile("Game Controll Script/Main_Game_Controll.txt"); //$NON-NLS-1$
	
		// Load item mix script
		LoadItemMixScript();

		// add history listener
		// History.addHistoryListener(this);
		// add history
		
		History.addValueChangeHandler(MyApplication.this);
		
		//History.fireCurrentHistoryState();
		
		if (History.getToken().length() > 2) {
			String decoded = URL.decodeComponent(History.getToken());
			// StartFromURL = true;
		
			updateStatus(decoded);
		}
		History.newItem("", false);
		

		// Set Label style

		StoryTabs.setStylePrimaryName("standard_message_back"); //$NON-NLS-1$
		//disable animation by default
		StoryTabs.setAnimationEnabled(false);
		
		Element bottompanel = (Element)StoryTabs.getElement().getFirstChild().getChildNodes().getItem(1).getFirstChild().getFirstChild();
		Log.info("adding overflow to bottom panel"+bottompanel.getInnerHTML());
		bottompanel.getStyle().setProperty("overflow", "auto");
		
		
		//.overflow-x:auto;
		
		AnswerBox.setEnabled(true);

		// while waiting for that we load the text boxs into the interface;

		// set chapter list

		ChapterList.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$

		ChapterList.addStyleName("standard_message_back"); //$NON-NLS-1$

	//	Feedback.setWidth("100%"); //$NON-NLS-1$
		// Feedback.setHeight("18px");
		
		Feedback.setStyleName("FeedbackText"); //$NON-NLS-1$

		// MainStoryText.setReadOnly(true);
		// MainStoryText.setStyleName("standard_message");
		System.out.print("________height=" + StoryTabs.getOffsetHeight()); //$NON-NLS-1$

		// Story tabs
		StoryTabs.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$

		StoryTabs.getDeckPanel().setSize("100%", Story_Text_Height + "px"); //$NON-NLS-1$ //$NON-NLS-2$

		Window.addResizeHandler(new ResizeHandler() {
			public void onResize(ResizeEvent event) {
				resizeEverything();
				
			
			}

		});

		ResizeOnLoad = new Timer() {
			@Override
			public void run() {
				// We check the size here, and fix if not correct. (for IE, as
				// IE dosnt work with LoadListener due to the cache)

				//resizeStoryBox();
				
				// set icon size
				//Game_Window_Width = Window.getClientWidth();
				//setInterfaceIconSize();
				//-------------
				
				resizeEverything();
				
			}

		};

		ResizeOnLoad.schedule(1000);
		
		StoryTabs.setStylePrimaryName("standard_message"); //$NON-NLS-1$

		// StoryTabs.selectTab(0);
		CurrentLocationTabs.setHeight("100%"); //$NON-NLS-1$

		// remove welcome from being active

	//	CurrentLocationTabs
	//			.removeTabListener(CurrentLocationTabs.OurTabListener);
		CurrentLocationTabs.removeHandlers();
					
		
		openPages.clear();
		locationpuzzlesActive.clear();

		StoryTabs.getTabBar().setVisible(false);
		CurrentLocationTabs.setHeight("100%"); //$NON-NLS-1$
		CurrentLocationTabs.setWidth("100%"); //$NON-NLS-1$
	
		
		MainStoryText.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$
		// Add inventory

		InventoryButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {

				PlayersInventoryFrame.OpenDefault();
				// always open this when a panel is opened;
				closeallwindows.setAnimateOpen();
				// --

			}
		});
		InventoryButton.addMouseDownHandler(new MouseDownHandler() {
			public void onMouseDown(MouseDownEvent event) {

				// InventoryButton.setUrl("GameIcons/Inventory_open.png");
				// InventoryButton.setAnimateOpen();
				// toggle inventory open
				InventoryOpen = true;

			}
/*
			public void onMouseUp(Widget sender, int mx, int my) {

			}

			public void onMouseEnter(Widget sender) {

				InventoryButton.setAnimateOpen();
			}

			public void onMouseMove(Widget sender, int mx, int my) {

			}

			public void onMouseLeave(Widget sender) {
				if (InventoryOpen == false) {
					InventoryButton.setAnimateClose();
				}
			}*/
		});
		
		InventoryButton.addMouseOverHandler(new MouseOverHandler(){
			public void onMouseOver(MouseOverEvent event) {
				InventoryButton.setAnimateOpen();
			}
			
		});
		InventoryButton.addMouseOutHandler(new MouseOutHandler(){
			public void onMouseOut(MouseOutEvent event) {
				if (InventoryOpen == false) {
					InventoryButton.setAnimateClose();
				}
			}
		});

		// add forum link
		ForumLinkButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {

				// loadforum
				Window.open("http://forum.res-nova.nl/fora/", "_blank", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
			}
		});

		ForumLinkButton.addMouseOverHandler(new MouseOverHandler() {		

			public void onMouseOver(MouseOverEvent event) {
				ForumLinkButton.setAnimateOpen();
			}
		});
		ForumLinkButton.addMouseOutHandler(new MouseOutHandler(){

			public void onMouseOut(MouseOutEvent event) {
				ForumLinkButton.setAnimateClose();
				
			}
			
		});
		
		
		MessageForwardButton.addClickHandler(new ClickHandler() {

			public void onClick(ClickEvent event) {
				String mess = MessageHistory.getnextmessage();

				// remove the tags
				mess = mess.replaceAll("\\<.*?>", "").trim();

				Feedback.setTextNow(" " + mess);
			}

		});
		MessageForwardButton.addMouseOverHandler(new MouseOverHandler(){
			public void onMouseOver(MouseOverEvent event) {
				MessageForwardButton.setAnimateOpen();			}
			
		});
		MessageForwardButton.addMouseOutHandler(new MouseOutHandler(){
			public void onMouseOut(MouseOutEvent event) {
				MessageForwardButton.setAnimateClose();		}
			
		});

		MessageBackButton.addMouseOverHandler(new MouseOverHandler(){
			public void onMouseOver(MouseOverEvent event) {
				
				MessageBackButton.setAnimateOpen();
			}
		});
		MessageBackButton.addMouseOutHandler(new MouseOutHandler(){
			public void onMouseOut(MouseOutEvent event) {
				
				MessageBackButton.setAnimateClose();
			}

		});
		
		MessageBackButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				String mess = MessageHistory.getprevmessage();

				// remove the tags
				mess = mess.replaceAll("\\<.*?>", "").trim();

				Feedback.setTextNow(" " + mess);

			}

		});

		// MessageHistory popup
		MessageHistoryButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {

				if (MessageHistoryOpen == false) {
					messagehistory.setHeight("300px"); //$NON-NLS-1$
					messagehistory.setWidth(((FeedbackContainer.getParent()
							.getOffsetWidth()))
							+ "px"); //$NON-NLS-1$
					messagehistory.setStyleName("Feedback"); //$NON-NLS-1$
					messagehistory.scrolltobottom();

					
					// loadpanel
					RootPanel.get().add(messagehistory,
							DOM.getElementById("feedback").getAbsoluteLeft(),
							DOM.getElementById("feedback").getAbsoluteTop() - 300);
					MessageHistoryButton.setAnimateOpen();
					MessageHistoryOpen = true;

				} else {
					RootPanel.get().remove(messagehistory);
					MessageHistoryOpen = false;
					MessageHistoryButton.setAnimateClose();
				}

			}
		});

		// Add Notepad

		
		
		NotepadButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				// RootPanel.get().add(MyApplication.fadeback,0, 0);
				PlayersNotepadFrame.OpenDefault();

			}
		});
		NotepadButton.addMouseDownHandler(new MouseDownHandler() {
			public void onMouseDown(MouseDownEvent event) {

				NotepadOpen = true;

				// NotepadButton.setUrl("GameIcons/Notebook_open.png");
				// toggle inventory open
				// NotepadOpen = true;
				// always open this when a panel is opened;
				closeallwindows.setAnimateOpen();
				// --

			}

		});
		
		
		NotepadButton.addMouseOverHandler(new MouseOverHandler(){
			public void onMouseOver(MouseOverEvent event) {
				NotepadButton.setAnimateOpen();
			}
		});
		NotepadButton.addMouseOutHandler(new MouseOutHandler(){
			public void onMouseOut(MouseOutEvent event) {
				if (NotepadOpen == false) {
					NotepadButton.setAnimateClose();
				}
			}			
		});

		ControllPanelButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				// always open this when a panel is opened;
				closeallwindows.setAnimateOpen();
				// --

				RootPanel.get().add(MyApplication.fadeback, 0, 0);
				// ControlPanel.ShowDefault();
				DOM.setStyleAttribute(fadeback.getElement(),
						"zIndex", "" + (MyApplication.z_depth_max + 1)); //$NON-NLS-1$ //$NON-NLS-2$
				DOM.setStyleAttribute(fadeback.getElement(),
						"z-index", "" + (MyApplication.z_depth_max + 1)); //$NON-NLS-1$ //$NON-NLS-2$
				z_depth_max = z_depth_max + 1;

				ControllPanelShadows.OpenDefault();

				ControllPanelShadows.getElement().getStyle().setProperty(
						"zIndex", "2000"); //$NON-NLS-1$ //$NON-NLS-2$
				ControllPanelShadows.getElement().getStyle().setProperty(
						"z-index", "2000"); //$NON-NLS-1$ //$NON-NLS-2$

				// make sure its on top

				ControllPanelShadows.fixedZdepth(2000);

			}
		});

		ControllPanelButton.addMouseDownHandler(new MouseDownHandler() {
			public void onMouseDown(MouseDownEvent event) {
				ControllPanelOpen = true;
			}

		});
		
		ControllPanelButton.addMouseOverHandler(new MouseOverHandler(){
			public void onMouseOver(MouseOverEvent event) {
				ControllPanelButton.setAnimateOpen();
			}
			
		});
		
		ControllPanelButton.addMouseOutHandler(new MouseOutHandler(){
			public void onMouseOut(MouseOutEvent event) {
				if (ControllPanelOpen == false) {
					ControllPanelButton.setAnimateClose();
				}
			}
			
		});

		// invisible by default
		SecretsPopupPanelButton.setVisible(false);
		SecretsPopupPanelButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				SecretPanelFrame.OpenDefault();

				// always open this when a panel is opened;
				// closeallwindows.setAnimateOpen();
			}

		});
		SecretsPopupPanelButton.addMouseDownHandler(new MouseDownHandler() {
			public void onMouseDown(MouseDownEvent event) {

				SecretsPanelOpen = true;

			
			}
		});

		SecretsPopupPanelButton.addMouseOutHandler(new MouseOutHandler() {			
			public void onMouseOut(MouseOutEvent event) {
				if (SecretsPanelOpen == false) {
					SecretsPopupPanelButton.setAnimateClose();
				}
			}
		});
		SecretsPopupPanelButton.addMouseOverHandler(new MouseOverHandler() {	
			public void onMouseOver(MouseOverEvent event) {
				SecretsPopupPanelButton.setAnimateLoop();
			}
		});
		
		// close all button
		closeallwindows.addClickHandler(new ClickHandler() {

			public void onClick(ClickEvent event) {

				closeallwindows.setAnimateClose();

				// close popups
				// Iterator <PopUpWithShadow> itp =
				// System.out.print("popups open="+overlayPopUpsOpen.size());
				DebugWindow.addText("popups open=" + overlayPopUpsOpen.size()); //$NON-NLS-1$

				int size = overlayPopUpsOpen.size();
				int closei = size - 1;
				while (closei > -1) {

					DebugWindow.addText("closing "); //$NON-NLS-1$

					PopUpWithShadow closethis = overlayPopUpsOpen.get(closei);

					DebugWindow
							.addText("-" + closethis.getWidget().getClass() + "-"); //$NON-NLS-1$ //$NON-NLS-2$

					closethis.CloseDefault();
					closei--;
				}

				// close cluebox
				ClueReveal.setOpen(false);
			//	OpenClueBox.setUrl("./GameTextures/TitleStrip_leftOpen.jpg");
			//	JargStaticImages.BIGTitleStripleftOpen().applyTo(OpenClueBox);
				OpenClueBoxButton.applyTo(OpenClueBox);
				
				//remove fade
				RootPanel.get().remove(fadeback);				
				
				// make sure main ones are closed too all main panels.
				// SecretPanelFrame.CloseDefault();
				// PlayersNotepadFrame.CloseDefault();
				// PlayersInventoryFrame.CloseDefault();
			}

		});

		
	/*	//setup Joker Panel
		Joker.addClickListener(new ClickListener(){

			public void onClick(Widget sender) {
				
				CluePanelFrame.OpenDefault();
				
			}
			
		});
		
		*/
		ScoreAndJokerContainer.add(PlayersScore);
		ScoreAndJokerContainer.setCellVerticalAlignment(PlayersScore,
				HasVerticalAlignment.ALIGN_MIDDLE);
	//	ScoreAndJokerContainer.add(Joker);
	//	ScoreAndJokerContainer.setCellVerticalAlignment(Joker,
	//			HasVerticalAlignment.ALIGN_MIDDLE);

		ScoreAndJokerContainer.setSize("100px", "28px");

		// ScoreAndJokerContainer.setStylePrimaryName("clueBox");
		//PlayersScore.SetScore(2500);
		ScoreAndClueBox.setHeight("40px");
		ScoreAndClueBox.add(ScoreAndJokerContainer);

		// ScoreAndClueBox.setStylePrimaryName("ScoreBox");
		ClueReveal.setHeight("20px");
		ClueReveal.setAnimationEnabled(true);
		//ClueReveal.getHeaderTextAccessor().setText("Clues");
		//clear the header
		ClueReveal.setHeader(new Label(""));
		ClueReveal.setContent(playersClues);
		

		// ClueReveal.setStylePrimaryName("clueBox");
		ClueReveal.getHeader().getElement().getStyle().setProperty("color",
				"white");


		


		RootPanel.get().add(closeallwindows, Window.getClientWidth() - 55, 0);
		DOM.setStyleAttribute(closeallwindows.getElement(), "zIndex", "1805");

		// decorations
		
		try {
			RootPanel.get("Statuefeet").add(StatueFeat); //$NON-NLS-1$
			RootPanel.get("clocklady").add(StatueHead); //$NON-NLS-1$

			RootPanel.get("clocklady").add(gwt_clock, 35, 40); //$NON-NLS-1$
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		
		
		StatueFeat.setTitle("the game is a");
		
		gwt_clock.addClickListener(new ClickListener() {
			int clickcount = 0;

			public void onClick(Widget sender) {
				gwt_clock.SetModeRandom(3000);
				clickcount++;
				System.out.print(clickcount);
				
				
			
				
				if (clickcount > 5) {

					//add score
					processInstructions(
							" \n - AddScore = 5 \n ", "ClockClickedALot"); //$NON-NLS-1$
			
					
					RootPanel.get().add(clockpopup,
							RootPanel.get("clocklady").getAbsoluteLeft() + 35,
							RootPanel.get("clocklady").getAbsoluteTop() - 30);
					// put it on top
					DOM.setIntStyleAttribute(clockpopup.getElement(), "zIndex",
							5000);

					// timer to make it vanish
					Timer vanishimage = new Timer() {

						@Override
						public void run() {
							clockpopup.removeFromParent();
						}

					};
					vanishimage.schedule(3000);
				} else {
					processInstructions(
							" \n - AddScore = 1 \n ", "Clock"+clickcount); //$NON-NLS-1$
			
				}

			}

		});
		
		//titles
		if (Document.get().getElementById("titlecontainer") != null){
			ScoreBoxVisible = true;
		} else {
	    //no title or score
			ScoreBoxVisible = false;
			
		}
		
		// gwt_clock.setRadius((int)(StatueHead.getOffsetWidth()/2.2));

		TitleBarLeft.getElement().getStyle().setProperty("backgroundImage", "url(../GameIcons/BIG/TitleStrip.jpg)");
		TitleBarLeft.setWidth("100%");
		TitleBarLeft.setHeight("55px");
		TitleBarLeft.setStylePrimaryName("TitleBarLeft");
		TitleBarLeft.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);	
		

		//final Image LeftBit = new Image("./GameTextures/TitleStrip_leftbit.jpg");
		
		
		LeftBit.setHeight("55px");
		TitleBarLeft.add(LeftBit);
		TitleBarLeft.setCellWidth(LeftBit, "25px");
		
	
		OpenClueBox.setHeight("55px");
		
		TitleBarLeft.add(OpenClueBox);
		TitleBarLeft.setCellWidth(OpenClueBox, "24px");
		
		
		OpenClueBox.addClickHandler(new ClickHandler(){
			public void onClick(ClickEvent event) {
				ClueReveal.setOpen(!ClueReveal.isOpen());
				if (!ClueReveal.isOpen()){
					
				//OpenClueBox.setUrl("./GameTextures/TitleStrip_leftOpen.jpg");
					OpenClueBoxButton.applyTo(OpenClueBox);
				
				//open close all box
				 if (MyApplication.overlayPopUpsOpen.size()<1){
					 if (CluePopUp.isAttached()==false){
					 closeallwindows.setAnimateClose();
					 }
				 }
				
				} else {
				//OpenClueBox.setUrl("./GameTextures/TitleStrip_leftClose.png");
					CloseClueBoxButton.applyTo(OpenClueBox);
					
				closeallwindows.setAnimateOpen();
				}
			}
			
		});
		
		TitleBarLeft.add(ScoreBack);	
		ScoreBack.setWidth("170px");
		ScoreBack.setHeight("55px");
		TitleBarLeft.setCellWidth(ScoreBack, "170px");
		TitleBarLeft.getElement().getStyle().setProperty("backgroundImage", "url(./GameIcons/BIG/TitleStrip.jpg)");
		
		BuyBack.setHeight("55px");
		TitleBarLeft.add(BuyBack);
		BuyBack.addClickHandler(new ClickHandler(){

			public void onClick(ClickEvent event) {
				
				   DebugWindow.addText("opening clue panel");
				   
				   //change button apperance
				   //TitleStrip
				   BuyCloseButton.applyTo(BuyBack);	
				   
					CluePanelFrame.OpenDefault();
					closeallwindows.setAnimateOpen();
					
					
				
			}
			
		});
		TitleBarLeft.setCellWidth(BuyBack, "26px");
		//spacer for the end

		//Image spacer =  JargStaticImages.BIGTitleBackground().createImage();
		spacer.setUrl("./GameIcons/BIG/TitleStrip.jpg");
		spacer.setWidth("100%");
		 spacer.setHeight("55px");
		TitleBarLeft.add(spacer);
		
		
		try {
			RootPanel.get("ScoreBox").add(TitleBarRight);
		} catch (Exception e1) {
			
			e1.printStackTrace();
		}
		
		
		//TitleBarRight.setStylePrimaryName("TitleBarRight");	


		TitleBarRight.setWidth("100%");
		TitleBarRight.setHeight("56px");

		if (ScoreBoxVisible){
		RootPanel.get().add(ScoreAndClueBox, ScoreBack.getAbsoluteLeft(),ScoreBack.getAbsoluteTop()+(ScoreBack.getHeight()/2)-15);
        DOM.setStyleAttribute(ScoreAndClueBox.getElement(), "zIndex", "110");
		}
		//Image TopStrip = new Image("./GameTextures/TitleStrip.jpg");
        
        //Image TopStrip = JargStaticImages.BIGTitleBackground().createImage();
        TopStripBigGap.setUrl("./GameIcons/BIG/TitleStrip.jpg");
        TopStripBigGap.setWidth("100%");	
		TopStripBigGap.setHeight("55px");
		
		TitleBarRight.add(TopStripBigGap);
		TitleBarRight.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		
		//Image Cuyperstitle= new Image("./GameTextures/TitleStrip_right.png");
		
		
	//	Cuyperstitle = new SpiffyIcon(BigCuypers2LogoImages);
		
		Cuyperstitle.addClickHandler(new ClickHandler(){
			public void onClick(ClickEvent event) {
				Cuyperstitle.setAnimateLoop();
				
				//add score 
				processInstructions(
						" \n - AddScore = 5 \n ", "SpunTheWheel"); //$NON-NLS-1$
		
				
				Timer stopSpining = new Timer(){
					@Override
					public void run() {
						Cuyperstitle.setAnimateClose();
					}					
				};				
				stopSpining.schedule(3000);				
			}			
		});
		
		//JargStaticImages.BIGTitleStripRight0().createImage();
		Cuyperstitle.setWidth("177px");		
		Cuyperstitle.setHeight("55px");
		TitleBarRight.add(Cuyperstitle);
		TitleBarRight.setCellWidth(Cuyperstitle, "1px");

		//we try each icon out seperately, because some are optional for some games
		
		try {
			RootPanel.get("Inventory").add(InventoryButton); //$NON-NLS-1$
			InventoryButton.setWidth("100%"); //$NON-NLS-1$
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			

			
			RootPanel.get("soldier").add(solider); //$NON-NLS-1$
			solider.setStyleName("solider"); //$NON-NLS-1$

			DOM.setStyleAttribute(solider.getElement(), "zIndex", "0");
			
			
			RootPanel.get("Notepad").add(NotepadButton); //$NON-NLS-1$
			NotepadButton.setWidth("100%"); //$NON-NLS-1$
			RootPanel.get("ControllPanel").add(ControllPanelButton); //$NON-NLS-1$
			ControllPanelButton.setWidth("100%"); //$NON-NLS-1$
			
			RootPanel.get("chapterlist").add(ChapterList); //$NON-NLS-1$

			RootPanel.get("musicControll").add(musicPlayer); //$NON-NLS-1$
			musicPlayer.setSize("90%","100%");
			
			//reposition music box to float above the rest
			int MpSizeX = DOM.getElementById("musicControll").getOffsetWidth()-60;
			int MpSizeY = musicPlayer.CurrentMusicTrackLabel.getOffsetHeight();
			int MpX = DOM.getElementById("musicControll").getAbsoluteLeft()+20;
			int MpY = DOM.getElementById("musicControll").getAbsoluteTop()+DOM.getElementById("musicControll").getOffsetHeight();					
							
			musicPlayer.CurrentMusicTrackLabel.setPixelSize(MpSizeX, MpSizeY);
			musicPlayer.CurrentMusicTrackLabel.ListContainer.setWidth(MpSizeX+"px");
			musicPlayer.CurrentMusicTrackLabel.getElement().getStyle().setProperty("zIndex", "500");
			RootPanel.get().add(musicPlayer.CurrentMusicTrackLabel, MpX,MpY-23);
			musicPlayer.setSize(DOM.getElementById("musicControll").getOffsetWidth()+"px", "100%");
			
			RootPanel.get("Secretlink").add(SecretsPopupPanelButton); //$NON-NLS-1$
			RootPanel.get("ForumLink").add(ForumLinkButton); //$NON-NLS-1$
		} catch (Exception e) {
			e.printStackTrace();
		}

		RootPanel.get("bigtextbox").add(StoryTabs); //$NON-NLS-1$

		//RootPanel.get().add(ClueReveal,
		//		DOM.getElementById("bigtextbox").getAbsoluteLeft()+20,
		//		DOM.getElementById("bigtextbox").getAbsoluteTop() -8);
		//RootPanel.get().add(ClueReveal,	ScoreBack.getAbsoluteLeft(),ScoreBack.getAbsoluteTop()+ScoreBack.getOffsetHeight());
		
		DOM
				.setStyleAttribute(ClueReveal.getElement(), "zIndex",
						"1000");
		playersClues.setSize((DOM.getElementById("bigtextbox").getOffsetWidth()-14)+"px", (DOM.getElementById("bigtextbox").getOffsetHeight()-21)+"px");
		
		
		// RootPanel.get("answerbox").add(AnswerBox);
		// RootPanel.get("answerbox").add(EnterAns);

		// we have to do this to get around the text going off the bottom of the
		// frame (in FF and Chrome)
		
		//FeedbackContainer.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$
		FeedbackContainer.setWidth("100%");
		FeedbackContainer.setStylePrimaryName("Feedback");
		
		//FeedbackContainer.add(Feedback);	
		
		ScrollPanel FeedbackScroller = new ScrollPanel();
		FeedbackContainer.add(FeedbackScroller);
		FeedbackScroller.setSize("100%", "70px");
		
		//FeedbackScroller.add(new Label ("This is a test label for testing \n the feedback overflow \n settings for when the text is too big. Scrollbars should appearonly when needed, and the box should keep a steady size at all times. \n sorry for the inconvience this has caused, normal messages will return shortly......................................................... - DF "));

		VerticalPanel FeedbackToBottom = new VerticalPanel();
		FeedbackToBottom.setSize("100%", "100%");
		FeedbackToBottom.add(Feedback);	
		FeedbackToBottom.setCellVerticalAlignment(Feedback, VerticalPanel.ALIGN_BOTTOM);
		
		FeedbackScroller.add(FeedbackToBottom);	
		
		
		FeedbackContainer.setCellVerticalAlignment(Feedback,
				HasVerticalAlignment.ALIGN_BOTTOM);

		RootPanel.get("feedback").add(FeedbackContainer); //$NON-NLS-1$
		// feedback history flip thingy
		MessageForwardButton.setSize("19px", "19px");
		Style MHBStyle2 = MessageForwardButton.getElement().getStyle();
		MHBStyle2.setProperty("zIndex", "250"); //$NON-NLS-1$ //$NON-NLS-2$

		MessageBackButton.setSize("19px", "19px");
		Style MHBStyle3 = MessageBackButton.getElement().getStyle();
		MHBStyle3.setProperty("zIndex", "250"); //$NON-NLS-1$ //$NON-NLS-2$

		MessageHistoryButton.setSize("16px", "16px"); //$NON-NLS-1$ //$NON-NLS-2$
		Style MHBStyle = MessageHistoryButton.getElement().getStyle();
		MHBStyle.setProperty("zIndex", "250"); //$NON-NLS-1$ //$NON-NLS-2$

		RootPanel.get().add(MessageHistoryButton,
				DOM.getElementById("feedback").getAbsoluteLeft() + FeedbackContainer.getOffsetWidth()-20,
				DOM.getElementById("feedback").getAbsoluteTop());

		RootPanel.get().add(MessageForwardButton,
				MessageHistoryButton.getAbsoluteLeft() - 20,
				MessageHistoryButton.getAbsoluteTop());

		RootPanel.get().add(MessageBackButton,
				MessageHistoryButton.getAbsoluteLeft() - 40,
				MessageHistoryButton.getAbsoluteTop());

		// AnsBar.setWidth("100%");
		AnsBar.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		AnsBar.setHeight("100%"); //$NON-NLS-1$
		AnsBar.add(AnswerBox);
		// AnsBar.setBorderWidth(2);
		AnsBar.add(EnterAns);
		// EnterAns.setWidth("200px");
		RootPanel.get("ansbar").add(AnsBar); //$NON-NLS-1$

		//titles
		if (Document.get().getElementById("titlecontainer") != null){
		RootPanel.get("titlecontainer").add(TitleBarLeft);
		} else {
	    //no title or score
			ScoreBoxVisible = false;
			
		}
		
		
		// Things that have to be set after other things are added;
		 RootPanel.get().add(ClueReveal,	ScoreBack.getAbsoluteLeft(),ScoreBack.getAbsoluteTop()+ScoreBack.getOffsetHeight()-5);
			

		StoryTabs.setSize("100%", "100%"); //$NON-NLS-1$ 
		
		// StoryTabs.setWidth(""+(StoryTabs.getParent().getOffsetWidth()-16)+"px");
		// StoryTabs.setHeight((StoryTabs.getParent().getOffsetHeight()-15)+"px");

		System.out
				.print("get offset-" + StoryTabs.getParent().getOffsetWidth()); //$NON-NLS-1$
		StoryTabs.getDeckPanel().setSize("100%", Story_Text_Height + "px"); //$NON-NLS-1$ //$NON-NLS-2$

	}

	public void loadGamesText() {
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.GET,
		// "text/messages_dutch.properties");
				homeurl+"text/messages_dutch.properties");

		try {
			requestBuilder.sendRequest("", new RequestCallback() { //$NON-NLS-1$
						public void onError(Request request, Throwable exception) {
							DebugWindow.setText("http get failed"); //$NON-NLS-1$
						}

						public void onResponseReceived(Request request,
								Response response) {

							// DebugWindow.setText("\n got
							// text"+response.getText().length()+" ");

							// load the text
							GamesText.LoadText(response.getText());
							DebugWindow.addText("\n loaded text");

							// update interface language
							ControllPanelShadows.caption
									.setText(LoadGamesText.MainGame_SaveOrLoadYourGame);
							PlayersInventoryFrame.caption
									.setText(LoadGamesText.MainGame_Inventory);
							PlayersNotepadFrame.caption
									.setText(LoadGamesText.MainGame_Charecter_Profiles);
							SecretPanelFrame.caption
									.setText(LoadGamesText.MainGame_Secrets_Found);

							// //close all title

							closeallwindows
									.setTitle(LoadGamesText.MainGame_CloseAlWindows);

							EnterAns.setText(LoadGamesText.MainGame_submit);

							// update controll panel text

							ControlPanel.changepassword
									.setText(LoadGamesText.ControllPanel_ChangePassword);
							ControlPanel.sound_options
									.setText(LoadGamesText.ControllPanel_SoundEffects);
							ControlPanel.soundon
									.setText(LoadGamesText.ControllPanel_on);
							ControlPanel.soundoff
									.setText(LoadGamesText.ControllPanel_off);
							ControlPanel.animation_options
									.setText(LoadGamesText.ControllPanel_AnimationEffects);
							ControlPanel.animationon
									.setText(LoadGamesText.ControllPanel_on);
							ControlPanel.animationoff
									.setText(LoadGamesText.ControllPanel_off);
							ControlPanel.autosaveon
									.setText(LoadGamesText.ControllPanel_on);
							ControlPanel.autosaveoff
									.setText(LoadGamesText.ControllPanel_off);					
							
							ControlPanel.LayoutSizeOveride
									.setText(LoadGamesText.ControllPanel_InterfaceSize);
							ControlPanel.NewTopBar.Title
									.setText(LoadGamesText.ControllPanel_ControllPanel);
							ControlPanel.animationoff
									.setText(LoadGamesText.ControllPanel_off);
							ControlPanel.SaveGameDataToSever
									.setText(LoadGamesText.ControllPanel_ClickHereToSaveYourProgress);
							ControlPanel.LoadGameData
									.setText(LoadGamesText.ControllPanel_LoadFromText);
							ControlPanel.LogOut
									.setText(LoadGamesText.ControllPanel_ClickHereToLogOut);

							ControlPanel.LayoutModes.clear();
							ControlPanel.LayoutModes
									.addItem(LoadGamesText.ControllPanel_Default);
							ControlPanel.LayoutModes
									.addItem(LoadGamesText.ControllPanel_Small);
							ControlPanel.LayoutModes
									.addItem(LoadGamesText.ControllPanel_Medium);
							ControlPanel.LayoutModes
									.addItem(LoadGamesText.ControllPanel_Big);

							// update reset box text
							ControlPanel.ResetGameBox.lab_warning
									.setText(LoadGamesText.GameReset_Warning);
							ControlPanel.ResetGameBox.resetgamebutton
									.setText(LoadGamesText.GameReset_Button);
							// ControlPanel.ResetGameBox.
							// .setText(MyApplication.GamesText.GameReset_Warning);
							// update change password
							ControlPanel.ChangePasswordBox.changepassword_button
									.setText(LoadGamesText.ControllPanel_ChangePassword);

							// Update login box bits
							user_login.signup
									.setText(LoadGamesText.Login_SignUp);
							user_login.lab_password
									.setText(LoadGamesText.Login_Password);
							user_login.lab_rememberme
									.setText(LoadGamesText.Login_Rememberme);
							user_login.guestlogin
									.setText(LoadGamesText.Login_GuestLogin);
							user_login.forgotpassword
									.setText(LoadGamesText.Login_ForgotPassword);
							user_login.lab_name
									.setText(LoadGamesText.Login_Username);
							user_login.clearcookies
									.setText(LoadGamesText.Login_ClearCookies);
							user_login.lab_loginplease.setText(LoadGamesText.Login_PleaseLogin);
							
							//CluePanel popup
							CluePopUp.instructions.setText(LoadGamesText.CluePanel_instructions);
							CluePopUp.instructions2.setText(LoadGamesText.CluePanel_instructions2);
							CluePopUp.chapterheader.setText(LoadGamesText.CluePanel_chapterheader);
							CluePopUp.buy.setText(LoadGamesText.CluePanel_buy);
							CluePopUp.cancel.setText(LoadGamesText.CluePanel_cancel);
							

						}
					});
		} catch (RequestException ex) {
			DebugWindow.addText("can not connect to games text file"); //$NON-NLS-1$
		}
	}

	public static void setInterfaceIconSize() {


		//Window.alert("screen size set 0");
	        		
		iconsizestring = "BIG"; //$NON-NLS-1$
		if (InterfaceSize.compareTo(LoadGamesText.ControllPanel_Default) == 0) { //$NON-NLS-1$
			if (Game_Window_Width < 1050) {
				iconsizestring = "MEDIUM"; //$NON-NLS-1$
			}
			if (Game_Window_Width < 800) {
				iconsizestring = "SMALL"; //$NON-NLS-1$
			}
		} else {
			if (InterfaceSize.compareTo(LoadGamesText.ControllPanel_Small) == 0) { //$NON-NLS-1$
				iconsizestring = "SMALL"; //$NON-NLS-1$
			}
			if (InterfaceSize.compareTo(LoadGamesText.ControllPanel_Medium) == 0) { //$NON-NLS-1$
				iconsizestring = "MEDIUM"; //$NON-NLS-1$
			}
			if (InterfaceSize.compareTo(LoadGamesText.ControllPanel_Big) == 0) { //$NON-NLS-1$
				iconsizestring = "BIG"; //$NON-NLS-1$
			}
		}

		
	    
		
		// InventoryButton.setURL(
		// "GameIcons/" + iconsizestring + "/cc2rugzakje0.png", 6);
		
		// InventoryButton.setURL(
		// "GameIcons/" + iconsizestring +
		// "/"+InventoryButton.originalfilename+".png", 6);
		
		if (iconsizestring.equals("BIG")) {

			if (StatueHead.BundleImageMode){
				StatueHead.setFrames(LadyClockBig);
				} else {

					//Window.alert("GameIcons/" + iconsizestring + "/" + StatueHead.originalfilename+".png set");
					
					StatueHead.setURL("GameIcons/" + iconsizestring + "/" + StatueHead.originalfilename+".png",
							StatueHead.frametotal+1);
					
					//Window.alert("url set too"+StatueHead.getUrl());
				}
			StatueFeat.setFrames(LadyFeatBig);
			
			if (solider.BundleImageMode){
				solider.setFrames(SoldierBig);
				} else {
						solider.setURL("GameIcons/" + iconsizestring + "/" + solider.originalfilename+".png",
								solider.frametotal+1);
						
				}
			//topbar
			BigLeftBit.applyTo(LeftBit);
			BigBuyOpenButton.applyTo(BuyBack);
			BigScoreBack.applyTo(ScoreBack);
			BigOpenClueBox.applyTo(OpenClueBox);

			LeftBit.setHeight("55px");
			BuyBack.setHeight("55px");
			OpenClueBox.setHeight("55px");
			ScoreBack.setHeight("55px");
			ScoreBack.setWidth("170px");
			TitleBarRight.setHeight("56px");
			
			DOM.getElementById("ScoreBox").getStyle().setProperty("height", "55px");
			
			BuyCloseButton = BigBuyCloseButton;
			BuyOpenButton = BigBuyOpenButton;
			OpenClueBoxButton = BigOpenClueBox;
			CloseClueBoxButton = BigCloseClueBox;
			
			TitleBarLeft.setHeight("55px");
			TitleBarLeft.getElement().getStyle().setProperty("backgroundImage", "url(./GameIcons/BIG/TitleStrip.jpg)");
			
			TopStripBigGap.setUrl("./GameIcons/BIG/TitleStrip.jpg");
			TopStripBigGap.setWidth("100%");	
			TopStripBigGap.setHeight("55px");				
			spacer.setUrl("./GameIcons/BIG/TitleStrip.jpg");
			spacer.setHeight("55px");
			
			//title bar set
			Cuyperstitle.setFrames(BigCuypers2LogoImages);
			
			
			
			InventoryButton.setFrames(BigInventoryImages);
						
			NotepadButton.setFrames(BigNotepadImages);
			ControllPanelButton.setFrames(BigControllPanelImages);
			ForumLinkButton.setFrames(BigForumImages);
			SecretsPopupPanelButton.setFrames(BigSecretsImages);
			
		} else if (iconsizestring.equals("MEDIUM")) {
			
			
			if (StatueHead.BundleImageMode){
				StatueHead.setFrames(LadyClockMid);
				} else {

					StatueHead.setURL("GameIcons/" + iconsizestring + "/" + StatueHead.originalfilename+".png",
							StatueHead.frametotal+1);
					
				}
			StatueFeat.setFrames(LadyFeatMid);
			
			if (solider.BundleImageMode){
			solider.setFrames(SoldierMid);
			} else {
					solider.setURL("GameIcons/" + iconsizestring + "/" + solider.originalfilename+".png",
							solider.frametotal+1);
					
			}
			//topbar
			MediumLeftBit.applyTo(LeftBit);
			MediumBuyOpenButton.applyTo(BuyBack);
			MediumOpenClueBox.applyTo(OpenClueBox);

			LeftBit.setHeight("47px");
			BuyBack.setHeight("47px");
			OpenClueBox.setHeight("47px");
			ScoreBack.setHeight("47px");
			ScoreBack.setWidth("140px");
			TitleBarRight.setHeight("47px");
			
			DOM.getElementById("ScoreBox").getStyle().setProperty("height", "47px");
			DOM.getElementById("ScoreBox").setAttribute("Style", "height:47px");
			
			
			BuyCloseButton = MediumBuyCloseButton;
			BuyOpenButton = MediumBuyOpenButton;
			OpenClueBoxButton = MediumOpenClueBox;
			CloseClueBoxButton = MediumCloseClueBox;
			
			MediumScoreBack.applyTo(ScoreBack);
			

			TopStripBigGap.setUrl("./GameIcons/MEDIUM/TitleStrip.jpg");
			TopStripBigGap.setWidth("100%");	
			TopStripBigGap.setHeight("47px");
			spacer.setUrl("./GameIcons/MEDIUM/TitleStrip.jpg");
			spacer.setHeight("47px");
			TitleBarLeft.setHeight("47px");
			TitleBarLeft.getElement().getStyle().setProperty("backgroundImage", "url(./GameIcons/MEDIUM/TitleStrip.jpg)");
			
			//title bar set
			Cuyperstitle.setFrames(MediumCuypers2LogoImages);
			
			InventoryButton.setFrames(MediumInventoryImages);
			NotepadButton.setFrames(MediumNotepadImages);
			ControllPanelButton.setFrames(MediumControllPanelImages);
			ForumLinkButton.setFrames(MediumForumImages);
			SecretsPopupPanelButton.setFrames(MediumSecretsImages);
			
		} else if (iconsizestring.equals("SMALL")) {
					
			if (StatueHead.BundleImageMode){
				StatueHead.setFrames(LadyClockSmall);
				} else {

					//Window.alert("GameIcons/" + iconsizestring + "/" + StatueHead.originalfilename+".png set");
					
					StatueHead.setURL("GameIcons/" + iconsizestring + "/" + StatueHead.originalfilename+".png",
							StatueHead.frametotal+1);
					
					//Window.alert("url set too"+StatueHead.getUrl());
				}
			
			StatueFeat.setFrames(LadyFeatSmall);
			
			if (solider.BundleImageMode){
				solider.setFrames(SoldierSmall);
				} else {
						solider.setURL("GameIcons/" + iconsizestring + "/" + solider.originalfilename+".png",
								solider.frametotal+1);
						
				}
			//topbar
			SmallLeftBit.applyTo(LeftBit);
			SmallBuyOpenButton.applyTo(BuyBack);
			SmallScoreBack.applyTo(ScoreBack);
			SmallOpenClueBox.applyTo(OpenClueBox);
			BuyCloseButton = SmallBuyCloseButton;
			BuyOpenButton = SmallBuyOpenButton;
			OpenClueBoxButton = SmallOpenClueBox;
			CloseClueBoxButton = SmallCloseClueBox;
			
			LeftBit.setHeight("40px");
			BuyBack.setHeight("40px");
			OpenClueBox.setHeight("40px");
			ScoreBack.setHeight("40px");
			TitleBarRight.setHeight("40px");
			ScoreBack.setWidth("120px");
			
			DOM.getElementById("ScoreBox").getStyle().setProperty("height", "40px");
			
			
			TopStripBigGap.setUrl("./GameIcons/SMALL/TitleStrip.jpg");
			spacer.setUrl("./GameIcons/SMALL/TitleStrip.jpg");
			TopStripBigGap.setWidth("100%");	
			TopStripBigGap.setHeight("40px");
			spacer.setHeight("40px");	
			TitleBarLeft.setHeight("40px");
			TitleBarLeft.getElement().getStyle().setProperty("backgroundImage", "url(./GameIcons/SMALL/TitleStrip.jpg)");
			
			//title bar set
			Cuyperstitle.setFrames(SmallCuypers2LogoImages);
			
			InventoryButton.setFrames(SmallInventoryImages);
			NotepadButton.setFrames(SmallNotepadImages);
			ControllPanelButton.setFrames(SmallControllPanelImages);
			ForumLinkButton.setFrames(SmallForumImages);
			SecretsPopupPanelButton.setFrames(SmallSecretsImages);
			
		} else {

			if (StatueHead.BundleImageMode){
				StatueHead.setFrames(LadyClockBig);
				} else {

					//Window.alert("GameIcons/" + iconsizestring + "/" + StatueHead.originalfilename+".png set");
					
					StatueHead.setURL("GameIcons/" + iconsizestring + "/" + StatueHead.originalfilename+".png",
							StatueHead.frametotal+1);
					
					//Window.alert("url set too"+StatueHead.getUrl());
				}
			
			StatueFeat.setFrames(LadyFeatBig);
			
			if (solider.BundleImageMode){
				solider.setFrames(SoldierBig);
				} else {
						solider.setURL("GameIcons/" + iconsizestring + "/" + solider.originalfilename+".png",
								solider.frametotal+1);
						
				}
			//topbar
			BigLeftBit.applyTo(LeftBit);
			BigBuyOpenButton.applyTo(BuyBack);
			BigScoreBack.applyTo(ScoreBack);
			BigOpenClueBox.applyTo(OpenClueBox);

			LeftBit.setHeight("55px");
			BuyBack.setHeight("55px");
			OpenClueBox.setHeight("55px");
			ScoreBack.setHeight("55px");
			ScoreBack.setWidth("170px");

			DOM.getElementById("ScoreBox").getStyle().setProperty("height", "55px");
			
			BuyCloseButton = BigBuyCloseButton;
			BuyOpenButton = BigBuyOpenButton;
			OpenClueBoxButton = BigOpenClueBox;
			CloseClueBoxButton = BigCloseClueBox;
			
			TitleBarLeft.setHeight("55px");
			TitleBarLeft.getElement().getStyle().setProperty("backgroundImage", "url(./GameIcons/BIG/TitleStrip.jpg)");
			
			TopStripBigGap.setUrl("./GameIcons/BIG/TitleStrip.jpg");
			TopStripBigGap.setWidth("100%");	
			TopStripBigGap.setHeight("55px");				
			spacer.setUrl("./GameIcons/BIG/TitleStrip.jpg");
			spacer.setHeight("55px");
			
			//title bar set
			Cuyperstitle.setFrames(BigCuypers2LogoImages);
			
			
			
			InventoryButton.setFrames(BigInventoryImages);
						
			NotepadButton.setFrames(BigNotepadImages);
			ControllPanelButton.setFrames(BigControllPanelImages);
			ForumLinkButton.setFrames(BigForumImages);
			SecretsPopupPanelButton.setFrames(BigSecretsImages);
		}

		//NotepadButton.setURL(
		//		"GameIcons/" + iconsizestring + "/cc2notebook0.png", 4); //$NON-NLS-1$ //$NON-NLS-2$
	//	ControllPanelButton.setURL(
	//			"GameIcons/" + iconsizestring + "/CCtype0.png", 4); //$NON-NLS-1$ //$NON-NLS-2$
	//	ForumLinkButton.setURL(
	//			"GameIcons/" + iconsizestring + "/CC2forum0.png", 4); //$NON-NLS-1$ //$NON-NLS-2$
	//	SecretsPopupPanelButton.setURL(
	//			"GameIcons/" + iconsizestring + "/easteregg0.png", 5); //$NON-NLS-1$ //$NON-NLS-2$
		//StatueHead.setURL(
		//		"GameIcons/" + iconsizestring + "/CCladyclock0.png", 3); //$NON-NLS-1$ //$NON-NLS-2$
	//	StatueFeat
	//			.setURL(
	//					"GameIcons/" + iconsizestring + "/" + StatueFeat.originalfilename + ".png", 1); //$NON-NLS-1$ //$NON-NLS-2$
	//	solider.setURL("GameIcons/" + iconsizestring + "/CCsoldier0.png", 5); //$NON-NLS-1$ //$NON-NLS-2$
		// fix for IE because ie is dumb
		StatueHead.getElement().getStyle().setProperty("zIndex", "50"); //$NON-NLS-1$ //$NON-NLS-2$
		
		
		

		//set screen size
		
		if  (iconsizestring.compareTo("SMALL")==0) { 
			ControllPanel.changecss("smallscreen"); //$NON-NLS-1$
			//Window.alert("screen size set a");
		}
		if  (iconsizestring.compareTo("MEDIUM")==0) { 
			ControllPanel.changecss("midscreen"); //$NON-NLS-1$
			//Window.alert("screen size set b ");
		}
		if  (iconsizestring.compareTo("BIG")==0) { 
			ControllPanel.changecss("default"); //$NON-NLS-1$
			//Window.alert("screen size set c");
		}
		
		//Window.alert("screen size set 1 "+iconsizestring);
		
	}

	public void startgamefromlocalcontrollfile(final String fileurl) {
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.GET,
				fileurl);

		try {
			requestBuilder.sendRequest("", new RequestCallback() { //$NON-NLS-1$
						public void onError(Request request, Throwable exception) {
							System.out.println("http failed"); //$NON-NLS-1$
						}

						public void onResponseReceived(Request request,
								Response response) {

							// catch error
							if (response.getText().length() < 10) {
								System.out
										.println("controll file not recieved;" + response.getText()); //$NON-NLS-1$
								MainStoryText
										.setText("controll file not recieved;" + response.getText()); //$NON-NLS-1$
								return;
							}

							controllscript = response.getText();

							// crop till start;
							// "Game Controll Starts Here:"

							int StartIndex = controllscript
									.indexOf("Game Controll Starts Here:"); //$NON-NLS-1$

							controllscript = controllscript.substring(
									StartIndex, controllscript.length());


							
							//swap custom words
							controllscript = SwapCustomWords(controllscript);
							
							Log.info("setting up answers");
							
							//set up answers
							gamesAnswerStore = new GamesAnswerStore(controllscript);
							
							
							// once loaded we start the main game loop
							maingameloop();
						}
					});
		} catch (RequestException ex) {
			System.out.println("can not connect to game controll file"); //$NON-NLS-1$
		}

	}

	public void LoadItemMixScript() {

		// RequestBuilder requestBuilder = new
		// RequestBuilder(RequestBuilder.POST,
		// textfetcher_url);
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.GET,
				inventory_url + "ItemControllScript.txt"); //$NON-NLS-1$
		try {
			requestBuilder.sendRequest("", new RequestCallback() { //$NON-NLS-1$
						public void onError(Request request, Throwable exception) {
							System.out.println("http failed"); //$NON-NLS-1$
						}

						public void onResponseReceived(Request request,
								Response response) {

							String responsetext = response.getText();
							// update widgets HTML field
							itemmixscript = responsetext;
						}
					});
		} catch (RequestException ex) {
			String responsetext = "can not connect to game controll file"; //$NON-NLS-1$
			itemmixscript = responsetext;
		}

	}

	public void GetTextSecurely(final String fileurl, final HTML updateThis) {

		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.POST,
				textfetcher_url);

		try {
			requestBuilder.sendRequest(
					"FileURL=" + fileurl, new RequestCallback() { //$NON-NLS-1$
						public void onError(Request request, Throwable exception) {
							System.out.println("http failed"); //$NON-NLS-1$
						}

						public void onResponseReceived(Request request,
								Response response) {

							String responsetext = response.getText();
							// update widgets HTML field
							updateThis.setText(responsetext);
						}
					});
		} catch (RequestException ex) {
			String responsetext = "can not connect to game controll file"; //$NON-NLS-1$
			updateThis.setText(responsetext);
		}

	}

	public void startgamefromcontrollfile(final String fileurl) {

		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.POST,
				textfetcher_url);

		try {
			requestBuilder.sendRequest(
					"FileURL=" + fileurl, new RequestCallback() { //$NON-NLS-1$
						public void onError(Request request, Throwable exception) {
							System.out.println("http failed"); //$NON-NLS-1$
						}

						public void onResponseReceived(Request request,
								Response response) {

							controllscript = response.getText();

							// crop till start;
							// "Game Controll Starts Here:"

							int StartIndex = controllscript
									.indexOf("Game Controll Starts Here:"); //$NON-NLS-1$

							// catch error
							if (StartIndex == -1) {
								System.out
										.println("controll file not recieved;" + response.getText()); //$NON-NLS-1$
								MainStoryText
										.setText("controll file not recieved;" + response.getText()); //$NON-NLS-1$
								return;
							}

							controllscript = controllscript.substring(
									StartIndex, controllscript.length());

							System.out.print(controllscript);
							
							//swap custom works
							controllscript = SwapCustomWords(controllscript);

							Log.info("setting up answers");
							
							//set up answers
							gamesAnswerStore = new GamesAnswerStore(controllscript);
							Log.info("ans set up");
							
													
							
							// once loaded we start the main game loop

							 maingameloop();
						}
					});
		} catch (RequestException ex) {
			System.out.println("can not connect to game controll file"); //$NON-NLS-1$
		}

	}

	public static void maingameloop() {

		// Maingame here
		if (GamesRunning){
			return;
		}
		
		GamesRunning = true;
		
		
		// We add the answer listener to the main answer box;
	//	Window.setTitle("adding click handle for entering answers");
		EnterAns.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				// if over one letters scan if its correct answer
				if (AnswerBox.getText().length() > 1) {
					Log.info("answer given from enter");
					AnswerGiven(AnswerBox.getText());
				}
			}
		});
		
		
		AnswerBox.addKeyDownHandler(new KeyDownHandler() {
			public void onKeyDown(KeyDownEvent event) {

				int Key = event.getNativeKeyCode();
				if (Key == 13) {
					AnswerBox.setText(RemoveCartReturns(AnswerBox.getText())
							.trim());

					// if over one letters scan if its correct answer
					if (AnswerBox.getText().length() > 1) {
						Log.info("answer given from keydown");
						AnswerGiven(AnswerBox.getText());
					}

				}

			}

		});

	}

	private static void start_of_game_script() {
		
		//display scrollbars on page
		Window.enableScrolling(true);
		
		// wait to make sure controll script is loaded
		// Set loading text
		MainStoryText.setText(LoadGamesText.MainGame_StoryText_Loading);
		Feedback.setText(LoadGamesText.MainGame_LoadingNewGame);

		Timer temptimer = new Timer() {

			@Override
			public void run() {

				if (controllscript.length() > 5) {

					this.cancel();
					
				//	Window.alert(" controll script loaded running setup ");
					
					// Set loading text
					MainStoryText
							.setText(LoadGamesText.MainGame_StoryText_Loading
									+ "...");
					Feedback.setText(LoadGamesText.MainGame_LoadingNewGame
							+ "...");
					// grab start commands
					int FirstBitsStart = controllscript.indexOf("Start:", 0) + 6; //$NON-NLS-1$
					int FirstBitsEnd = controllscript.indexOf("ans=", 0); //$NON-NLS-1$
					// System.out.print("/n ans next pos="+FirstBitsStart);
					DebugWindow.addText("/n ans next pos=" + FirstBitsStart); //$NON-NLS-1$
					// Isolate instructions to process
					final String instructionset = controllscript.substring(
							FirstBitsStart, FirstBitsEnd);

					System.out
							.print("\n -instruction set- \n " + instructionset + " \n -instruction set- \n"); //$NON-NLS-1$ //$NON-NLS-2$
					DebugWindow
							.addText("\n -instruction set- \n " + instructionset + " \n -instruction set- \n"); //$NON-NLS-1$ //$NON-NLS-2$

					// if theres no preloaded instructions, then we process the
					// first lot
					// if (StartFromURL == false) {
					//Window.alert("processing starting instructions"+instructionset);
					
					processInstructions(instructionset, "Start");
					// }
					//Window.alert("triggering main game loop");
					maingameloop();
				}
			}

		};

	//	Window.alert(" setting timer for starting controll script ");
		temptimer.scheduleRepeating(30);
//add history triggers
		
	}

	public static void AnswerGiven(String Ans) {

	//	Log.info("answer "+Ans+"given while in"+location.toLowerCase());
	//	Log.info("The New Ans system would have returned:"+gamesAnswerStore.checkAns(Ans, location.toLowerCase()));
		
	//	Window.setTitle("answer entered "+Ans);		
		
		if (Ans.equals("DebugWindow")) {
			DebugWindow.setStyleName("standard_message"); //$NON-NLS-1$
			DebugWindow.setSize("15%", "15%"); //$NON-NLS-1$ //$NON-NLS-2$
			RootPanel.get().add(DebugWindow, 0, 0);

		}

		// if the ans is a special code;

		if ((Ans.startsWith("SPC")) && (Ans.length() == 12)) {
			specialCodeEntered(Ans);
			return;
		}

		
		DebugWindow.addText("starting ans search..."); //$NON-NLS-1$
		EnterAns.setText(LoadGamesText.MainGame_Sending);

		// trim and lower case the answer;
		Ans = Ans.trim().toLowerCase();
		int AnswerIndex = -1;

		
		//NEW ANS test;
		Boolean isCalc = calc.isCalculation(Ans);
		String RunCode = gamesAnswerStore.checkAns(Ans,location.toLowerCase(),isCalc);
		
		if (RunCode!=null){
			
			Log.info("processing instructions:"+RunCode);
			processInstructions(RunCode,Ans+"Given@"+location.toLowerCase());
			//reset message on button
			EnterAns.setText(LoadGamesText.MainGame_Submit);

			return;
		}
		
		// Else its a calc?
		if (isCalc) {

			String result = "" + calc.AdvanceCalculation(Ans);
			System.out.println("-" + result + "-");

			if (result.endsWith(".0")) {
				System.out.println("=" + result + "=");

				result = result.replaceFirst("\\.0", "");
				System.out.println("=" + result + "=");

			}
			messagehistory.AddNewMessage_notrecorded("-- " + Ans);
			Feedback.setText(LoadGamesText.MainGame_Mathsbeforeans + " "
					+ result + " " + LoadGamesText.MainGame_Mathsafterans);
			messagehistory
					.AddNewMessage("<div class=\"MessageHistoryReplyStyle\" >  " + LoadGamesText.MainGame_Mathsbeforeans + result + LoadGamesText.MainGame_Mathsafterans + "</div>"); //$NON-NLS-1$ //$NON-NLS-2$

			//reset message on button
			EnterAns.setText(LoadGamesText.MainGame_Submit);

			return;
		}
		
		
		
		//if (true) return;
		//--(temp stop to test code)--
		// All code below in this method is now useless!
		//------------------------------------------------
		
	/*	
		
		// search for answer (specific to chapter)
	//	Window.setTitle("search for answer matchs");	
		
		// loop till we find the ans at the correct chapter
		int starthere = 0;
		while (starthere <= controllscript.length()) {
			// get answer position, search for each combination of a ans
			// frameing
			int AnswerLineA = controllscript.toLowerCase().indexOf(Ans,
					starthere);

			// check its not last
			if (AnswerLineA < 0) {
				break;
			}

			// ans must be a word unto itself
			String char_before_ans = controllscript.toLowerCase().substring(
					(AnswerLineA - 1), AnswerLineA);
			if (!((char_before_ans.compareTo(" ") == 0) || (char_before_ans.compareTo(",") == 0))) { //$NON-NLS-1$ //$NON-NLS-2$
				starthere = AnswerLineA + 1;
				continue;
			}

			String char_after_ans = controllscript.toLowerCase().substring(
					(Ans.length() + AnswerLineA),
					Ans.length() + AnswerLineA + 1);
			DebugWindow.addText("-after=" + char_after_ans + "-"); //$NON-NLS-1$ 
			testafter = -4;
			testafter = (char_after_ans.indexOf(" ")) + (char_after_ans.indexOf(",")) + (char_after_ans.indexOf("\r")) + (char_after_ans.indexOf("\n")); //$NON-NLS-1$
			// testafter = char_after_ans.matches("[ ,\\r\\n]+");

			DebugWindow.addText("=" + testafter + ".   "); //$NON-NLS-1$ 

			if (testafter < -3) {
				// <0 changed to <-1 and added "AnswerLineA" rather then just
				// ++1
				starthere = AnswerLineA + 1;
				continue;
			}

			// MyApplication.AnswerBox.setTitle(""+AnswerLineA);
			int AnswerLineIndex = controllscript.lastIndexOf(
					"ans=", AnswerLineA); //$NON-NLS-1$

			// check there isnt a newline before the answer start (in which
			// case, it wasnt a real answer
			int Lastnewline = controllscript.lastIndexOf("\n", AnswerLineA); //$NON-NLS-1$

			if (Lastnewline > AnswerLineIndex) {
				starthere = AnswerLineA + 1;
				continue;
			}

			// check its not last
			if (AnswerLineA < 0) {
				break;
			}

			// get whole line
			String AnswerLine = controllscript.toLowerCase().substring(
					AnswerLineIndex,
					controllscript.indexOf("\n", AnswerLineIndex));

			// check it isnt part of a multi-word ans
			// check the next letter after any spaces is either a , or a newline

			String anwsers = AnswerLine.substring(AnswerLine.indexOf(":"))
					+ "\n";
			DebugWindow.addText(anwsers);
			if ((anwsers.matches(".*(,|:) *" + Ans
					+ " *(,|[\\n|\\r]).*[\\n|\\r]*")) == false) {
				DebugWindow.addText("part right");
				starthere = AnswerLineA + 1;
				continue;

			}

			// MyApplication.AnswerBox
			// .setTitle(AnswerLineIndex + " " + AnswerLine); //$NON-NLS-1$
			if (AnswerLine.startsWith("ans=" + location.toLowerCase() + ": ")) { //$NON-NLS-1$ //$NON-NLS-2$
				AnswerIndex = AnswerLineIndex;
				DebugWindow.addText("ans line correct" + location.toLowerCase());
				// MyApplication.AnswerBox.setTitle(AnswerLineIndex
				// + " -f- " + AnswerLine); //$NON-NLS-1$
				break;
			}
			starthere = AnswerLineA + 1;
		}

		// AnswerIndex =
		// controllscript.toLowerCase().indexOf("ans="+chapter.toLowerCase()+":
		// "+Ans);

		System.out.print("Answer given =" + "ans=" + location + ": " + Ans); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		System.out.print("-" + AnswerIndex); //$NON-NLS-1$

		if (AnswerIndex > -1) {
			// if its the right answer
			// Feedback.setText("correct");
			MyApplication.DebugWindow.addText("correct ans detected..."); //$NON-NLS-1$
			// System.out.print("correct"+AnswerIndex+Ans.length()+chapter.length()+5);

			// store ans in history box
			messagehistory.AddNewMessage_notrecorded("-- " + Ans); //$NON-NLS-1$

			// send for answer processing
			CorrectAnswerProcess(AnswerIndex + Ans.length() + location.length()
					+ 6);
			
			// set window title
			Window.setTitle(Username + LoadGamesText.MainGame_is_on_chapter
					+ location);

			// clear ans box
			AnswerBox.setText("");

			return;
		}
				
		
		// loop for non-specific answer
		starthere = 0;
		while (starthere <= controllscript.length()) {
			// get answer position, search for each combination of a ans
			// frameing
			int AnswerLineA = controllscript.toLowerCase().indexOf(Ans,
					starthere);

			// check its not last
			if (AnswerLineA < 0) {

				EnterAns.setText(LoadGamesText.MainGame_submit);
				break;
			}

			// ans must be a word unto itself
			String char_before_ans = controllscript.toLowerCase().substring(
					(AnswerLineA - 1), AnswerLineA);
			if (!((char_before_ans.compareTo(" ") == 0) || (char_before_ans.compareTo(",") == 0))) { 
				Log.info("_before ans check failed; no comma or space before ans_"+char_before_ans+"_");
				starthere = AnswerLineA + 1;
				continue;
			}

			String char_after_ans = controllscript.toLowerCase().substring(
					(Ans.length() + AnswerLineA),
					Ans.length() + AnswerLineA + 1);
			testafter = -4;
			testafter = (char_after_ans.indexOf(" ")) + (char_after_ans.indexOf(",")) + (char_after_ans.indexOf("\r")) + (char_after_ans.indexOf("\n")); 

			Log.info("____test ans=" + testafter + ".   "); //$NON-NLS-1$ //$NON-NLS-2$

			if (testafter < -3) { // <0 changed to <-1 and added "AnswerLineA"
				// rather then just ++1
				Log.info("failed after test"+char_after_ans);
				starthere = AnswerLineA + 1;
				continue;
			}

			// MyApplication.AnswerBox.setTitle(""+AnswerLineA);
			int AnswerLineIndex = controllscript.lastIndexOf(
					"ans=", AnswerLineA); //$NON-NLS-1$
			// check there isnt a newline before the answer start (in which
			// case, it wasnt a real answer
			int Lastnewline = controllscript.lastIndexOf("\n", AnswerLineA); //$NON-NLS-1$

			if (Lastnewline > AnswerLineIndex) {
				Log.info("___newline before suspected ans");
				starthere = AnswerLineA + 1;
				continue;
			}
			// check its not last
			if (AnswerLineA < 0) {
				Log.info("___last ans line");
				EnterAns.setText(LoadGamesText.MainGame_Submit);
				break;
			}

			// get whole line

			String AnswerLine = controllscript.toLowerCase().substring(
					AnswerLineIndex,
					controllscript.indexOf("\n", AnswerLineIndex));

			Log.info("___line is "+AnswerLine);
			
			String anwsers = AnswerLine.substring(AnswerLine.indexOf(":"))
					+ "\n";
			Log.info("___ans are"+anwsers);
						
			if ((anwsers.matches(".*(,|:) *" + Ans
					+ " *(,|[\\n|\\r]).*[\\n|\\r]*")) == false) {
				
				Log.info("part right2");
				
				starthere = AnswerLineA + 1;
				continue;

			}

			// MyApplication.AnswerBox
			// .setTitle(AnswerLineIndex + " " + AnswerLine); //$NON-NLS-1$
			if (AnswerLine.startsWith("ans=: ")) { //$NON-NLS-1$
				AnswerIndex = AnswerLineIndex;
				// MyApplication.AnswerBox.setTitle(AnswerLineIndex
				// + " -f- " + AnswerLine); //$NON-NLS-1$
				break;
			}
			starthere = AnswerLineA + 1;
		}

		if (AnswerIndex > -1) {
			// if its the right answer
			messagehistory.AddNewMessage_notrecorded("-- " + Ans); //$NON-NLS-1$
			
			Log.info("___processing from:"+(6 + AnswerIndex + Ans.length()));
			
			CorrectAnswerProcess(6 + AnswerIndex + Ans.length());
			
			// set window title
			Window.setTitle(Username + LoadGamesText.MainGame_is_on_chapter
					+ location);

			// clear ans box
			AnswerBox.setText("");

			return;
		} else {
			// test for maths input
			if (calc.isCalculation(Ans)) {

				String result = "" + calc.AdvanceCalculation(Ans);
				System.out.println("-" + result + "-");

				if (result.endsWith(".0")) {
					System.out.println("=" + result + "=");

					result = result.replaceFirst("\\.0", "");
					System.out.println("=" + result + "=");

				}
				messagehistory.AddNewMessage_notrecorded("-- " + Ans);
				Feedback.setText(LoadGamesText.MainGame_Mathsbeforeans + " "
						+ result + " " + LoadGamesText.MainGame_Mathsafterans);
				messagehistory
						.AddNewMessage("<div class=\"MessageHistoryReplyStyle\" >  " + LoadGamesText.MainGame_Mathsbeforeans + result + LoadGamesText.MainGame_Mathsafterans + "</div>"); //$NON-NLS-1$ //$NON-NLS-2$

				return;
			}

			//

			MyApplication.DebugWindow
					.addText("checking for generic ans..." + "ans=" + location.toLowerCase() + ": {default}"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

			// check for generic answer in this chapter
			AnswerIndex = controllscript.toLowerCase().indexOf(
					"ans=" + location.toLowerCase() + ": {default}"); //$NON-NLS-1$ //$NON-NLS-2$
			if (AnswerIndex > -1) {
				MyApplication.DebugWindow
						.addText("generic ans for chapter detected..."); //$NON-NLS-1$

				// store ans in history box
				messagehistory.AddNewMessage_notrecorded("-- " + Ans); //$NON-NLS-1$

				// send for answer processing
				// Ans.length() is not used, instead we use 11, for the number of chars in the ans length
				CorrectAnswerProcess(AnswerIndex + 11
						+ location.length() + 6);
				// set window title
				Window.setTitle(Username + LoadGamesText.MainGame_is_on_chapter
						+ location);

				// clear ans box
				AnswerBox.setText("");
				return;
			}

		}*/

	}

	private static void specialCodeEntered(String ans) {
		// goto special code function
		
		Log.info("special code entered");
		
		// check code
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.POST,
				"scripts/checkcode.php");

		try {
			requestBuilder.sendRequest(
					"checkthis=" + ans, new RequestCallback() { //$NON-NLS-1$
						public void onError(Request request, Throwable exception) {
							DebugWindow.addText("\n error");
						}

						public void onResponseReceived(Request request,
								Response response) {
							
							Log.info("special response recieved");							

							DebugWindow.addText("\n response"
									+ response.getText());

							if (response.getText().endsWith("VALID ID")) {

								// we look for where to send the gamer next;

								// search for {SPECIAL CODE} on current chapter
								String searchfor = "ans="
										+ location.toLowerCase()
										+ ": {special code}";
								DebugWindow.addText("\n looking for "
										+ searchfor);

								int AnswerIndex = controllscript.toLowerCase()
										.indexOf(searchfor);

								if (AnswerIndex == -1) {
									DebugWindow.addText("\n not found ");
									return;
								}
								

								Log.info("processing instructions:");	
								
								// process instructions;
								CorrectAnswerProcess(AnswerIndex + 14
										+ location.length() + 6);

							}

						}
					});
		} catch (RequestException ex) {
			DebugWindow.addText("\n error");
		}

	}

	public static void CorrectAnswerProcess(int StartHere) {

		// set unique action identifier (has to be manualy set elsewhere)
		// This is to stop duplicate scoreing
		int posOfLastNewline = controllscript.lastIndexOf("ans=", StartHere);
		
		int endOfAnsLine = controllscript.indexOf("\n", posOfLastNewline);
		
		String CurrentAnsLine = controllscript.substring(posOfLastNewline,
				endOfAnsLine);

		// System.out.print("-->"+CurrentAnsLine+"/n");
		// Window.alert("-->"+CurrentAnsLine+"/n");

		// get position of next answer
		int NextAnsPos = controllscript.indexOf("ans=", StartHere); //$NON-NLS-1$
		System.out.print("/n ans next pos=" + NextAnsPos); //$NON-NLS-1$

		// Isolate instructions to process
		final String instructionset = controllscript.substring(StartHere,
				NextAnsPos);

	//	Log.info("process this:"+instructionset);
		// System.out
		// .print("\n -instruction set- \n " + instructionset + " \n
		// -instruction set- \n"); //$NON-NLS-1$ //$NON-NLS-2$

		processInstructions(instructionset, CurrentAnsLine.trim());
      //  Window.alert("current ans line="+CurrentAnsLine.trim());
		
		//save the game
		if (autosaveon==true){
		//	DebugWindow.setText("SAVEING GAME....");
			ControlPanel.saveGame();			
		};
		
		Log.info("setting text pointlessly");		
		EnterAns.setText(LoadGamesText.MainGame_Submit);

	}

	public static void processInstructions(String instructionset,
			String UniqueTriggerIndent) {
		int StartHere;
		// Start pos to zero
		StartHere = 0;
		instructionset = instructionset + "\n"; //$NON-NLS-1$
		// clear command var
		String CurrentCommand = ""; //$NON-NLS-1$
		String CurrentProperty = ""; //$NON-NLS-1$
		String CurrentConditional = "";
		boolean conditionalsPassed = true;
		
	//	Log.info("processing instructions:"+instructionset);	
	//DebugWindow.addText("SaveData:::"+instructionset+"::::");
		
		// Loop for each instruction
	//	Window.alert("looping for each instruction");
		
		while (instructionset.indexOf("- ", StartHere) > -1) //$NON-NLS-1$
		{
			StartHere = instructionset.indexOf("- ", StartHere) + 2; //$NON-NLS-1$

			//first we check for a conditional
			String currentLine = instructionset.substring(StartHere,instructionset.indexOf("\n", StartHere));
			
			if (currentLine.trim().startsWith("(")){
				
						conditionalsPassed=false;
						String Conditionals = currentLine.trim().substring(1, currentLine.indexOf(")"));					
						Log.info("Conditionals="+Conditionals);
						//if there is one, we check whether the player pass's it.
						if (Conditionals.length()>1){
							conditionalsPassed = checkConditionals(Conditionals);
							Log.info("Conditionals checked");
							
						}
						//if not, we shunt the StartHere to the next conditional, or end it
						if (!conditionalsPassed){
							int NextCondition = instructionset.indexOf("- (", StartHere +Conditionals.length()+2); //$NON-NLS-1$
							
							
														
							if (NextCondition == -1 ){

								// after all commands we reselect the input box;
								AnswerBox.setFocus(true);
								//exit instruction processing
								Log.info("exit due to conditions not met 1");
								
								return;
								
							} else {
								
							Log.info("exit due to conditions not met, going to next condition at _"+ NextCondition);								
							StartHere = NextCondition;
							
							continue;
							}

						}
			}
			//else we continue
			
			
			// Get name of current command
			CurrentCommand = instructionset.substring(StartHere,
					instructionset.indexOf(" = ", StartHere)).trim(); //$NON-NLS-1$
			// Get the property of the command
			CurrentProperty = instructionset
					.substring(
							instructionset.indexOf(" = ", StartHere) + 3, instructionset.indexOf("\n", StartHere)).trim(); //$NON-NLS-1$ //$NON-NLS-2$
			
			// test
			//Log.info("\n command recieved;" + CurrentCommand + "\n"); //$NON-NLS-1$ //$NON-NLS-2$
			//Log.info("\n command property recieved;" + CurrentProperty + "\n"); //$NON-NLS-1$ //$NON-NLS-2$

			//Window.alert("processing instruction; "+CurrentCommand+","+CurrentProperty);
			
			
			
			// on different commands we do different things;
			// boy, I wish java support strings on switchs

			if (CurrentCommand.equalsIgnoreCase("SetLocation")) { //$NON-NLS-1$

				System.out
						.print("setting chapter to '" + CurrentProperty + "'; \n"); //$NON-NLS-1$ //$NON-NLS-2$
				location = CurrentProperty;
				Window.setTitle(Username + LoadGamesText.MainGame_is_on_chapter
						+ location);

			} else if (CurrentCommand.equalsIgnoreCase("Message")) //$NON-NLS-1$
			{
				// progressive messages
				if (CurrentProperty.indexOf(">>") > -1) { //$NON-NLS-1$
					// test location we are at in ans message memory
					DebugWindow.addText("display message:"); //$NON-NLS-1$

					int CurrentItem = 0;
					if (MultiMessagePlace.GetItem(AnswerBox.getText().trim())
							.isEmpty()) {
						// set it to item 0
						CurrentItem = 0;

					} else {
						// get current item
						CurrentItem = Integer.parseInt(MultiMessagePlace
								.GetItem((AnswerBox.getText())));
						DebugWindow.addText("message num:" + CurrentItem); //$NON-NLS-1$
					}

					DebugWindow.addText("display message:" + CurrentItem); //$NON-NLS-1$
					// display message number..
					int totalmessages = CurrentProperty
							.split("(\">>\")|(\" >> \")").length; //$NON-NLS-1$
					if (CurrentItem > totalmessages) {
						CurrentItem = 0;

					}

					CurrentProperty = CurrentProperty
							.split("(\">>\")|(\" >> \")")[CurrentItem]; //$NON-NLS-1$

					CurrentItem = CurrentItem + 1;

					MultiMessagePlace.RemoveItem((AnswerBox.getText().trim()));
					MultiMessagePlace.AddItem(
							"" + CurrentItem, (AnswerBox.getText().trim())); //$NON-NLS-1$

					DebugWindow
							.addText("get item test" + MultiMessagePlace.GetItem("thistest") + ":"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

				}

				// if theres a , in the propertys then we randomize
				if (CurrentProperty.indexOf("\",\"") > -1) { //$NON-NLS-1$

					int totalmessages = CurrentProperty.split("\",\"").length; //$NON-NLS-1$
					int selectthis = (int) (Math.random() * totalmessages);
					// note - to increase speed a precompiled regex can be used
					// here.
					CurrentProperty = CurrentProperty
							.split("(\",\")|(\" , \")")[selectthis]; //$NON-NLS-1$

				}
				CurrentProperty = CurrentProperty.replaceAll("\"", ""); //$NON-NLS-1$ //$NON-NLS-2$
				messagehistory
						.AddNewMessage("<div class=\"MessageHistoryReplyStyle\" >  " + CurrentProperty + "</div>"); //$NON-NLS-1$ //$NON-NLS-2$

				Feedback.setText(CurrentProperty);
			} else if (CurrentCommand.equalsIgnoreCase("PreviousMessage")) //$NON-NLS-1$
			{
				Feedback.setText(MessageHistory.getlastmessage(Integer
						.parseInt(CurrentProperty)));

			} else if (CurrentCommand.equalsIgnoreCase("SetMessageDelay")) //$NON-NLS-1$
			{
				Feedback.setDelay(Integer.parseInt(CurrentProperty));

			}  else if (CurrentCommand.equalsIgnoreCase("SetVariable")) //$NON-NLS-1$
			{ 
				//Get the variable name
				String name = CurrentProperty.split(",")[0].trim().toLowerCase();
				                           
				//Get value
				String value = CurrentProperty.split(",")[1].trim().toLowerCase();
				                                         
				//Set name to value								
				GameVariables.AddItemUniquely(value,name);
				
				
			} else if (CurrentCommand.equalsIgnoreCase("SubVariable")) //$NON-NLS-1$
			{ 
				//Get the variable name
				String name = CurrentProperty.split(",")[0].trim().toLowerCase();
				                           
				//Get value to add to
				String value = CurrentProperty.split(",")[1].trim().toLowerCase();
				                     
				//is it a number?
				try {
					int ValueOf = Integer.valueOf(value);
					//add to this if it exists
					
					int ValueOfItem =  Integer.valueOf(GameVariables.GetItem(name));
					
					int newValue = (ValueOfItem-ValueOf);
					Log.info("subtract to "+newValue);
					
					//Set name to value								
					GameVariables.AddItemUniquely(""+newValue,name);
					
				} catch (NumberFormatException e) {					
					//Not a number, then we just ignore this command
					Log.info("attempted to subtract  something not a number,or variable not set");
				}
				
				
				
			} else if (CurrentCommand.equalsIgnoreCase("AddVariable")) //$NON-NLS-1$
			{ 
				//Get the variable name
				String name = CurrentProperty.split(",")[0].trim().toLowerCase();
				                           
				//Get value to add to
				String value = CurrentProperty.split(",")[1].trim().toLowerCase();
				                     
				//is it a number?
				try {
					int ValueOf = Integer.valueOf(value);
					//add to this
					int ValueOfItem =  Integer.valueOf(GameVariables.GetItem(name));
					int newValue = (ValueOfItem+ValueOf);
					Log.info("setting to "+newValue);
					
					//Set name to value								
					GameVariables.AddItemUniquely(""+newValue,name);
					
				} catch (NumberFormatException e) {					
					//Not a number, then we just ignore this command
					Log.info("attempted to add  something not a number,or variable not set");
				}
				
				
				
			} else if (CurrentCommand.equalsIgnoreCase("SetScore")) //$NON-NLS-1$
			{
				// if score isnt already taken;
				PlayersScore.SetScore(Integer.parseInt(CurrentProperty));
				Feedback.setText("Current Score is:" + CurrentProperty);
				messagehistory
						.AddNewMessage("<div class=\"MessageHistoryReplyStyle\" >  Current Score is:" + CurrentProperty + "</div>"); //$NON-NLS-1$ //$NON-NLS-2$

			} else if (CurrentCommand.equalsIgnoreCase("EnterAns")) //$NON-NLS-1$
			{
				// this is a special function for entering another answer automaticaly.
				// It should be used at the end of scripts, and is for the purpose of allowing nested
				// or repeated sets of actions to be written easily.
				Log.info("answer given by script:"+CurrentProperty+" at location="+location);
				AnswerGiven(CurrentProperty);
			
			} else if (CurrentCommand.equalsIgnoreCase("SetClueBox")) //$NON-NLS-1$
			{
				playersClues.LoadFromString(CurrentProperty.trim());
				
			}
				else if (CurrentCommand.equalsIgnoreCase("AddScore")) //$NON-NLS-1$
			
			{
				// if score isnt already taken 

				if (ScoresAwarded.indexOf("|" + UniqueTriggerIndent + "|") == -1) {
					PlayersScore.AddScore(Integer.parseInt(CurrentProperty));
					Feedback.setText(LoadGamesText.MainGame_Score_Awarded+" " + CurrentProperty);
					messagehistory
							.AddNewMessage("<div class=\"MessageHistoryReplyStyle\" >  Score Awarded:" + CurrentProperty + "</div>"); //$NON-NLS-1$ //$NON-NLS-2$

					// add to scores set string

					ScoresAwarded = ScoresAwarded + " |" + UniqueTriggerIndent
							+ "| ";
				}

			} else if (CurrentCommand.equalsIgnoreCase("PointsAwardedFor")) //$NON-NLS-1$
			{
				ScoresAwarded = CurrentProperty;

			} else if (CurrentCommand.equalsIgnoreCase("SetMessageSpeed")) //$NON-NLS-1$
			{
				Feedback.setSpeed(Integer.parseInt(CurrentProperty));

			} else if (CurrentCommand.equalsIgnoreCase("AddItem")) //$NON-NLS-1$
			{
				if (CurrentProperty.trim().length()>0)
				{
				
				if (PlayersInventory.playerHasItem(CurrentProperty) == false) {
					System.out
							.println("Adding " + CurrentProperty + " to the inventory \n"); //$NON-NLS-1$ //$NON-NLS-2$
					
					InventoryButton.setAnimateOpenThenClose();

					PlayersInventory.AddItem(CurrentProperty);
					PlayersInventory.OpenDefault();

				} else {
					Feedback
							.setText(LoadGamesText.MainGame_YouAlreadyHaveThisItem);
				}
				
				}
				
			

			} else if (CurrentCommand.equalsIgnoreCase("ClearInventory")) //$NON-NLS-1$
			{
				Log.info("clearing inventory");
				PlayersInventory.ClearInventory();

			} else if (CurrentCommand.equalsIgnoreCase("RemoveItem")) //$NON-NLS-1$
			{
				
				System.out.println("Removing " + CurrentProperty + " to the inventory \n"); //$NON-NLS-1$ //$NON-NLS-2$
				
				PlayersInventory.RemoveItem(CurrentProperty);

			} else if (CurrentCommand.equalsIgnoreCase("SpecialEffect")) //$NON-NLS-1$
			{
				Log.info("Setting special effect to " + CurrentProperty + " \n"); //$NON-NLS-1$ //$NON-NLS-2$
				TriggerEffect(CurrentProperty);
			} else if (CurrentCommand.equalsIgnoreCase("StoryBox")) //$NON-NLS-1$
			{
				if (CurrentProperty.equals("1 Pierres aktetas.html")) {
					CurrentProperty = "10 Pierres aktetas.html";
				}

				System.out
						.print("Setting '" + CurrentProperty + "' to storybox \n"); //$NON-NLS-1$ //$NON-NLS-2$
				
				
				//remove any page selection stuff
				triggerSelectCheck = false;
				pageToSelect="";
				
				//clear any tig messages\
				if (lastclicked_item != null){
				lastclicked_item.TiGFeedback.setText("");
				}
				
				// Page selection should be done -after- all the new pages are specified, not before.			
				setNewPage(CurrentProperty);
				
				
				
				// CurrentLocationTabs.setNewPage(CurrentProperty);

			} else if (CurrentCommand.equalsIgnoreCase("SelectPage")) //$NON-NLS-1$
			{
				
				selectPage(CurrentProperty);
				// CurrentLocationTabs.setNewPage(CurrentProperty);

			} else if (CurrentCommand.equalsIgnoreCase("RemoveLocation")) //$NON-NLS-1$
			{
				System.out
						.print("Removing '" + CurrentProperty + "' from storybox \n"); //$NON-NLS-1$ //$NON-NLS-2$
				// removePage(CurrentProperty);
				CurrentLocationTabs.removePage(CurrentProperty);

			} else if (CurrentCommand.equalsIgnoreCase("OpenItem")) //$NON-NLS-1$
			{
				//if the item is currently in the inventory, we set it to add and open automaticaly.
				if (PlayersInventory.playerHasItem(CurrentProperty) == false) {
					
					//add item with trigger
					InventoryButton.setAnimateOpenThenClose();
					PlayersInventory.AddItem(CurrentProperty,true);
					PlayersInventory.OpenDefault();					
					

				} else {
					//else we just open it
					PlayersInventory.triggerItem(CurrentProperty);

				}
				
				
			} else if (CurrentCommand.equalsIgnoreCase("OpenURL")) //$NON-NLS-1$
			{
				Window.open(CurrentProperty, "_blank", ""); //$NON-NLS-1$ //$NON-NLS-2$

			} else if (CurrentCommand.equalsIgnoreCase("NewChapter")) //$NON-NLS-1$
			{
				//remove any page selection stuff
				triggerSelectCheck = false;
				pageToSelect="";
				
				Log.info("setting new chapter");
				newchapter(CurrentProperty);
				

			} else if (CurrentCommand.equalsIgnoreCase("AddProfile")) //$NON-NLS-1$
			{
				if (CurrentProperty.equals("Thm45.html")) {
					CurrentProperty = "Th0m45.html";
				}

				PlayersNotepad.AddPage(CurrentProperty, CurrentProperty
						.substring(0, CurrentProperty.indexOf(".html")));
				NotepadButton.setAnimateOpenThenClose();

			} else if (CurrentCommand.equalsIgnoreCase("SetTIGitem")) //$NON-NLS-1$
			{
				String itemnamesearch = CurrentProperty.split(",")[0]; //$NON-NLS-1$
				String state = CurrentProperty.split(",")[1]; //$NON-NLS-1$
				DebugWindow.addText("\n setting tig item.."); //$NON-NLS-1$
				(lastclicked_item).setItemState(itemnamesearch, state);

			} else if (CurrentCommand.equalsIgnoreCase("CheckTIG")) //$NON-NLS-1$
			{

				(lastclicked_item).testCombination();

			} else if (CurrentCommand.equalsIgnoreCase("TIGMessage")) //$NON-NLS-1$
			{
				// progressive messages
				if (CurrentProperty.indexOf(">>") > -1) { //$NON-NLS-1$
					// test location we are at in ans message memory
					DebugWindow.addText("display message:"); //$NON-NLS-1$

					int CurrentItem = 0;
					if (MultiMessagePlace.GetItem(AnswerBox.getText().trim())
							.isEmpty()) {
						// set it to item 0
						CurrentItem = 0;

					} else {
						// get current item
						CurrentItem = Integer.parseInt(MultiMessagePlace
								.GetItem((AnswerBox.getText())));
						DebugWindow.addText("message num:" + CurrentItem); //$NON-NLS-1$
					}

					DebugWindow.addText("display message:" + CurrentItem); //$NON-NLS-1$
					// display message number..
					int totalmessages = CurrentProperty
							.split("(\">>\")|(\" >> \")").length; //$NON-NLS-1$
					if (CurrentItem > totalmessages) {
						CurrentItem = 0;

					}

					CurrentProperty = CurrentProperty
							.split("(\">>\")|(\" >> \")")[CurrentItem]; //$NON-NLS-1$

					CurrentItem = CurrentItem + 1;

					MultiMessagePlace.RemoveItem((AnswerBox.getText().trim()));
					MultiMessagePlace.AddItem(
							"" + CurrentItem, (AnswerBox.getText().trim())); //$NON-NLS-1$

					DebugWindow
							.addText("get item test" + MultiMessagePlace.GetItem("thistest") + ":"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

				}

				// if theres a , in the propertys then we randomize
				if (CurrentProperty.indexOf("\",\"") > -1) { //$NON-NLS-1$

					int totalmessages = CurrentProperty.split("\",\"").length; //$NON-NLS-1$
					int selectthis = (int) (Math.random() * totalmessages);
					// note - to increase speed a precompiled regex can be used
					// here.
					CurrentProperty = CurrentProperty
							.split("(\",\")|(\" , \")")[selectthis]; //$NON-NLS-1$

				}
				CurrentProperty = CurrentProperty.replaceAll("\"", ""); //$NON-NLS-1$ //$NON-NLS-2$
				//toggleimagegroupPopUp.TiGFeedback.setText(CurrentProperty);
				lastclicked_item.TiGFeedback.setText(CurrentProperty);

			} else if (CurrentCommand.equalsIgnoreCase("PopUpMessage")) //$NON-NLS-1$
			{

				if (CurrentProperty.indexOf(",") > -1) { //$NON-NLS-1$
					int totalmessages = CurrentProperty.split("\",\"").length; //$NON-NLS-1$
					int selectthis = (int) (Math.random() * totalmessages);
					// note - to increase speed a precompiled regex can be used
					// here.
					CurrentProperty = CurrentProperty
							.split("(\",\")|(\" , \")")[selectthis]; //$NON-NLS-1$
				}
				CurrentProperty = CurrentProperty.replaceAll("\"", ""); //$NON-NLS-1$ //$NON-NLS-2$
				DebugWindow.addText(MyApplication.lastclicked_x
						+ "  " + lastclicked_item.getWidgetCount()); //$NON-NLS-1$

				Label messagepop = new Label(CurrentProperty.trim());

				if (!(messageArrow == null)) {
					messageArrow.removeFromParent();
				}

				messageArrow = new SpiffyArrow(30, 30);

				messagepop.setSize("100px", "50px"); //$NON-NLS-1$ //$NON-NLS-2$
				messagepop.setStylePrimaryName("mesagePopUps"); //$NON-NLS-1$

				// position based on freespace
				// check for too far right
				if (lastclicked_x > (lastclicked_item.getOffsetWidth() - 200)) {
					messageArrow.SetArrowTopRight();
					lastclicked_item.imagegroupframe.add(messageArrow,
							lastclicked_x - 30, lastclicked_y);
					lastclicked_item.imagegroupframe.add(messagepop,
							lastclicked_x - 30 - 107, lastclicked_y + 29);

				} else {
					lastclicked_item.imagegroupframe.add(messageArrow,
							lastclicked_x, lastclicked_y);
					lastclicked_item.imagegroupframe.add(messagepop,
							lastclicked_x + 30, lastclicked_y + 29);

				}

				if (!(lastpopupmessage == null)) {
					lastpopupmessage.removeFromParent();
				}
				lastpopupmessage = messagepop;

			} else if (CurrentCommand.equalsIgnoreCase("PopUpAdvert")) //$NON-NLS-1$
			{
				// DebugWindow.addText(CurrentProperty);
				imagePNGPopUp imagepop = new imagePNGPopUp(CurrentProperty
						.trim(), ""); //$NON-NLS-1$
				PopUpWithShadow imagepopupcontainer = new PopUpWithShadow(null,
						"30%", "25%", "ADVERT", imagepop); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
				imagepopupcontainer.OpenDefault();
				imagepopupcontainer.setPopupPosition(
						(int) (Math.random() * (Window.getClientWidth() / 2)),
						(int) (Math.random() * (Window.getClientHeight() / 2)));

			} else if (CurrentCommand.equalsIgnoreCase("PopUpImage")) //$NON-NLS-1$
			{
				// DebugWindow.addText(CurrentProperty);
				imagePNGPopUp imagepop = new imagePNGPopUp(CurrentProperty
						.trim(), ""); //$NON-NLS-1$
				PopUpWithShadow imagepopupcontainer = new PopUpWithShadow(null,
						"30%", "25%", "Amuse", imagepop); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
				imagepopupcontainer.OpenDefault();
				// imagepopupcontainer.setPopupPosition(
				// (Window.getClientWidth() / 2)-(
				// imagepopupcontainer.getOffsetWidth()/2 ),
				// (Window.getClientHeight() / 2)-(
				// imagepopupcontainer.getOffsetHeight()/2 ));

			} else if (CurrentCommand.equalsIgnoreCase("StopSounds")) //$NON-NLS-1$
			{
				
				Iterator<Sound> it = CurrentPlayingSounds.iterator();
				while (it.hasNext()){
				
					Sound currentSoundToStop = it.next();
					currentSoundToStop.stop();
				}
				

			}else if (CurrentCommand.equalsIgnoreCase("PlaySound")) //$NON-NLS-1$
			{
				Sound sound = soundController.createSound(
						Sound.MIME_TYPE_AUDIO_MPEG, audioLocation_url
								+ CurrentProperty);
				sound.play();
				
				CurrentPlayingSounds.add(sound);

			} else if (CurrentCommand.equalsIgnoreCase("AddMusicTrack")) //$NON-NLS-1$
			{
				// DebugWindow.addText("adding music track:"+CurrentProperty);
				musicPlayer.addTrack(CurrentProperty);

			} else if (CurrentCommand.equalsIgnoreCase("PlayMusicTrack"))
			{
				
				//track number
				int track_to_play = Integer.parseInt(CurrentProperty);
				
				// start music//
				musicPlayer.CurrentMusicTrackLabel
						.setItemSelected(track_to_play,true);
				musicPlayer.playtrack(track_to_play);
				
			} else if (CurrentCommand.equalsIgnoreCase("AddSecret")) //$NON-NLS-1$
			{
				// reveal button;
				SecretsPopupPanelButton.setVisible(true);

				String secretname = CurrentProperty.split(",")[0]; //$NON-NLS-1$
				String secreturl = CurrentProperty.split(",")[1]; //$NON-NLS-1$
				SecretPanel.addItem(secretname, secreturl);

			} else if (CurrentCommand.equalsIgnoreCase("SendEmail")) //$NON-NLS-1$
			{

				sendemail(CurrentProperty);

			} else if (CurrentCommand.equalsIgnoreCase("SetSoldierIcon")) //$NON-NLS-1$
			{
				String iconloc = CurrentProperty.split(",")[0]; //$NON-NLS-1$
				//only update if url string is present
				if (iconloc.length()>5){
				int iconframes = Integer
						.parseInt(CurrentProperty.split(",")[1]); //$NON-NLS-1$

				solider.setURL(
						"GameIcons/" + iconsizestring + "/" + iconloc,
						iconframes);
				DebugWindow.addText("-seticon-" + iconloc);
				}
			}  else if (CurrentCommand.equalsIgnoreCase("SetClockLadyIcon")) //$NON-NLS-1$
			{
				String iconloc = CurrentProperty.split(",")[0]; //$NON-NLS-1$
				//only update if url string is present
				if (iconloc.length()>5){
				int iconframes = Integer
						.parseInt(CurrentProperty.split(",")[1]); //$NON-NLS-1$

				StatueHead.setURL(
						"GameIcons/" + iconsizestring + "/" + iconloc,
						iconframes);
				DebugWindow.addText("-seticon-" + iconloc);
				}
			} else if (CurrentCommand.equalsIgnoreCase("SetInventoryIcon")) //$NON-NLS-1$
			{

				String iconloc = CurrentProperty.split(",")[0]; //$NON-NLS-1$
				
				
				// if its Margriet, we can use the preloaded ones;
				if (iconloc.startsWith("magrietbag")) {					
					
					// update image sets
					BigInventoryImages = BigMarInventoryImages;
					MediumInventoryImages = MediumMarInventoryImages;
					SmallInventoryImages = SmallMarInventoryImages;
					
					
					
					if (iconsizestring.equals("BIG")) {
						InventoryButton.setFrames(BigInventoryImages);
					} else if (iconsizestring.equals("MEDIUM")) {
						InventoryButton.setFrames(MediumInventoryImages);
					} else if (iconsizestring.equals("SMALL")) {
						InventoryButton.setFrames(SmallInventoryImages);
					} else {
						InventoryButton.setFrames(BigInventoryImages);
					}
					
				} else {

					// else we load from the url
					if (iconloc.length()>5){
					int iconframes = Integer.parseInt(CurrentProperty
							.split(",")[1]); //$NON-NLS-1$

					InventoryButton.setURL("GameIcons/" + iconsizestring + "/"
							+ iconloc, iconframes);
					DebugWindow.addText("-seticon-" + iconloc);
					}
				}

			} else if (CurrentCommand.equalsIgnoreCase("SetStoryboxBackgroundClass")) //$NON-NLS-1$
			{
				
				Element bottompanel = (Element)StoryTabs.getDeckPanel().getElement().getFirstChild().getFirstChild().getFirstChild().getChildNodes().getItem(1);
				
				if (CurrentProperty.compareTo("none") == 0) { //$NON-NLS-1$
					//StoryTabs.getDeckPanel().setStyleName("");
					bottompanel.setClassName("_none_");
					
				} else {
					Log.info("setting deck style.");
					//StoryTabs.getDeckPanel().setStyleName("blah1"+CurrentProperty);
					
					
					//Log.info("nodes="+bottompanel.getInnerHTML());
					bottompanel.setClassName(CurrentProperty);
					
					
				}

			}else if (CurrentCommand.equalsIgnoreCase("SetBackgroundClass")) //$NON-NLS-1$
			{
				
				if (CurrentProperty.compareTo("none") == 0) { //$NON-NLS-1$
					RootPanel.getBodyElement().setClassName("");
					
				} else {
					RootPanel.getBodyElement().setClassName(CurrentProperty);
					
				}

			}else if (CurrentCommand.equalsIgnoreCase("SetBackgroundImage")) //$NON-NLS-1$
			{
				
				if (CurrentProperty.compareTo("none") == 0) { //$NON-NLS-1$
					RootPanel.getBodyElement().setAttribute("background", ""); //$NON-NLS-1$ //$NON-NLS-2$
					CurrentBackground = "none";
					
				} else {
									RootPanel.getBodyElement().setAttribute(
							"background", CurrentProperty); //$NON-NLS-1$
					
					CurrentBackground = CurrentProperty;
					

				}

			} else if (CurrentCommand.equalsIgnoreCase("SetClockMode")) //$NON-NLS-1$
			{
				if (CurrentProperty.compareTo("fast") == 0) { //$NON-NLS-1$
					gwt_clock.setModeFast();
				} else {
					gwt_clock.setModeNormal();
				}

			} else if (CurrentCommand.equalsIgnoreCase("SetGameMode")) //$NON-NLS-1$
			{
				if (CurrentProperty.compareTo("hacked") == 0) { //$NON-NLS-1$

					if (EffectOverlay.isAttached() == false) {
						RootPanel.get().add(EffectOverlay, 0, 0);
					}

					// add second advert. Cuyperbix its archtechral-ishious!
					EffectOverlay.ProcessThisAfter(" - SetBackgroundImage = GameTextures/hackedback.gif \n - SetClockMode = fast \n - PopUpAdvert = advert/Advert1.jpg \n - PopUpAdvert = advert/Advert2.jpg \n"); //$NON-NLS-1$
					EffectOverlay.Hacked_in();
					EffectOverlay.Hacked_out();
					Feedback.setDirection(Direction.RTL);
					((HTML) (messagehistory.MessageHistoryScroller.getWidget()))
							.setDirection(Direction.RTL);

					StatueHead.setURL("GameIcons/" + iconsizestring + "/" +"ladyclocklonger0.png", 3);
					
					Blinking = new Timer() {

						@Override
						public void run() {
							StatueHead.setAnimateOpenThenClose();

						}

					};

					Blinking.scheduleRepeating(5000);
					// set feet hacked 
					StatueFeat.setURL("GameIcons/" + iconsizestring + "/"
							+ "CCfeethacked0.png", 1);

					// make cylon soldier

					solider.setURL("GameIcons/" + iconsizestring + "/" + "CCsoldier0.png", 5);
					solider.BundleImageMode = false;
					
					Cyclonish = new Timer() {

						@Override
						public void run() {
							solider.setAnimateOpenThenClose();

						}

					};

					Cyclonish.scheduleRepeating(5000);

				} else {
					if (EffectOverlay.isAttached() == false) {
						RootPanel.get().add(EffectOverlay, 0, 0);
					}
					//make sure it isnt just resetting the background
					//this is a crude fix specific to the cuypers code. Remove in later games
					
					if (CurrentBackground.endsWith("hackedback.gif")){
						CurrentBackground = "GameTextures/CCmonMCdark.jpg";
					}
					EffectOverlay
							.ProcessThisAfter(" - SetBackgroundImage = "+CurrentBackground+" \n - SetClockMode = normal \n"); //$NON-NLS-1$

					
				
					
					EffectOverlay.Hacked_in();
					EffectOverlay.Hacked_out();
					Feedback.setDirection(Direction.LTR);
					((HTML) (messagehistory.MessageHistoryScroller.getWidget()))
							.setDirection(Direction.LTR);

					// RootPanel.getBodyElement().setAttribute("background",
					// "");

					// gwt_clock.setModeNormal();
					// set feet hacked
					StatueFeat.setURL("GameIcons/" + iconsizestring + "/"
							+ "CCfeetb.png", 1);
					
					// make normal soldier

					if (iconsizestring.equals("SMALL")){
						solider.setFrames(SoldierSmall);
						} else if (iconsizestring.equals("MEDIUM")){
							solider.setFrames(SoldierMid);
						} else {
							solider.setFrames(SoldierBig);
						}
					solider.BundleImageMode = true;

					Blinking.cancel();
					Cyclonish.cancel();
				}

			}

		}

		// after all commands we reselect the input box;
		AnswerBox.setFocus(true);

	}

	private static void sendemail(String currentProperty) {

		// First we grab the emails contents
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.POST,
				textfetcher_url);

		try {
			requestBuilder
					.sendRequest(
							"FileURL=Game%20Emails/" + currentProperty, new RequestCallback() { //$NON-NLS-1$
								public void onError(Request request,
										Throwable exception) {

								}

								public void onResponseReceived(Request request,
										Response response) {

									// we have the email
									// we now divide up the lines
									String emailtext = response.getText();

									String Title = emailtext
											.substring(
													emailtext
															.indexOf("Subject:") + 8, emailtext.indexOf("\n", emailtext.indexOf("Subject:") + 8)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
									String From = emailtext
											.substring(
													emailtext.indexOf("From:") + 5, emailtext.indexOf("\n", emailtext.indexOf("From:") + 5)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
									String Content = emailtext
											.substring(emailtext
													.indexOf("Message:") + 8); //$NON-NLS-1$

									RequestBuilder emailer = new RequestBuilder(
											RequestBuilder.POST, emailer_url);

									try {
										emailer
												.sendRequest(
														"Title=" + Title + "&From=" + From + "&Content=" + Content, new RequestCallback() { //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
															public void onError(
																	Request request,
																	Throwable exception) {

															}

															public void onResponseReceived(
																	Request request,
																	Response response) {
																// Feedback.setText(response.getText());

															}
														});
									} catch (RequestException ex) {
										// blah blah
										// Feedback.setText("emailer failed");

									}

								}
							});
		} catch (RequestException ex) {
			// blah blah
			// Feedback.setText("email data missing");

		}

	}

	static void newchapter(String CurrentProperty) {
		// remove quotes
		CurrentProperty = CurrentProperty.substring(1, (CurrentProperty
				.length() - 1));

		System.out
				.print("Createing a new chapter called '" + CurrentProperty + "' \n"); //$NON-NLS-1$ //$NON-NLS-2$

		LocationTabSet NewChapter = new LocationTabSet();
		AllLocationTabSets.add(NewChapter);

		// disable current tabs
		CurrentLocationTabs.disableAllTabFunctions();

		openPages.clear();
		locationpuzzlesActive.clear();

		CurrentLocationTabsIndex = AllLocationTabSets.indexOf(NewChapter);
		CurrentLocationTabs = AllLocationTabSets.get(CurrentLocationTabsIndex);
		StoryTabs.add(CurrentLocationTabs, CurrentProperty);

		ChapterList.addTab(CurrentProperty, StoryTabs
				.getWidgetIndex(CurrentLocationTabs));
		StoryTabs.selectTab(StoryTabs.getWidgetIndex(CurrentLocationTabs));
		
		
		
		
	}

	public static void TriggerEffect(final String EffectName) {

		Log.info("-" + EffectName + "-" + (EffectName.compareTo("Flash") == 0)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

		if (EffectName.compareTo("Flash") == 0) {
			
			if (EffectOverlay.isAttached() == false) {
				RootPanel.get().add(EffectOverlay, 0, 0);
			}
			EffectOverlay.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$\
			Log.info("- Flash starting -");
			EffectOverlay.Flash(10);
			EffectOverlay.Flash(10);
			
			Log.info("- Flash done -");
			
			
		}		
		
		if (EffectName.compareTo("FadeOut") == 0) { //$NON-NLS-1$

			
			if (EffectOverlay.isAttached() == false) {
				RootPanel.get().add(EffectOverlay, 0, 0);
			}
			EffectOverlay.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$
			EffectOverlay.FadeOut(2000);
			
			Log.info("- Fadeing out -");
			
		}

		if (EffectName.compareTo("FadeIn") == 0) { //$NON-NLS-1$

			if (EffectOverlay.isAttached() == false) {
				RootPanel.get().add(EffectOverlay, 0, 0);
			}
			EffectOverlay.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$
			EffectOverlay.FadeIn(2000);
			
			Log.info("- Fadeing in -");

		}
		if (EffectName.compareTo("Hacked") == 0) { //$NON-NLS-1$
			if (EffectOverlay.isAttached() == false) {
				RootPanel.get().add(EffectOverlay, 0, 0);
			}
			EffectOverlay.Hacked_in();

			EffectOverlay.Hacked_out();

		}
		if (EffectName.compareTo("Clear") == 0) { //$NON-NLS-1$

			EffectOverlay.Clear();

		}
	}

	public void removePage(final String RemoveLocation) {

		int TabCount = CurrentLocationTabs.getWidgetCount();
		int cindex = 0;
		System.out.println("remove-" + RemoveLocation); //$NON-NLS-1$

		for (Iterator<String> it = CurrentLocationTabs.OpenPagesInSet
				.iterator(); it.hasNext();) {

			String currentItem = it.next();

			if (currentItem.compareTo(RemoveLocation) == 0) {
				CurrentLocationTabs.OpenPagesInSet.remove(currentItem);
			}

		}

		// remove tab
		while (cindex < TabCount) {
			if (openPages.get(cindex).indexOf(RemoveLocation) > -1) {

				// we remove it from the tabs
				CurrentLocationTabs.remove(cindex);

				openPages.remove(cindex);
				// set chapter name to match
				locationpuzzlesActive.remove(cindex);

				return;
			}
			cindex++;
		}

	}

	
	public static void selectPage(String NewMessageURL){
	
		
		
		//this command has to be delayed untill all chapters pending to be loaded are loaded.
				
		if (NumberOfChaptersLeftToLoad==0){
		
		int TabCount = CurrentLocationTabs.OpenPagesInSet.size();
		int cindex = 0;
		
		//remove html if present
		int index = NewMessageURL.indexOf(".html");
		if (index>0){
		NewMessageURL = NewMessageURL.substring(0,index);
		}
		
		//DebugWindow.setText("/n index" + cindex + "tabCount" + TabCount +":-:"+NewMessageURL); 
				
		while (cindex < TabCount) {
			
			System.out.println("/n -=-=-=-");
			System.out.println("/n -=-=-=-"+cindex);
			System.out.println("/n -=-=-=-" + CurrentLocationTabs.OpenPagesInSet.get(cindex)+"::"+NewMessageURL); 
					
			if (CurrentLocationTabs.OpenPagesInSet.get(cindex).indexOf(NewMessageURL) > -1) {
				System.out.println("/n match. Already Open."); //$NON-NLS-1$
				// we set it to front and return
				System.out.println("Current LocationTabs ="+CurrentLocationTabs.getWidgetCount());
				
				
				CurrentLocationTabs.selectTab(cindex);

				
				return;
			}
			
			cindex++;
		}
		triggerSelectCheck = false;
		pageToSelect="";
		} else {
			
			triggerSelectCheck = true;
			pageToSelect= NewMessageURL;
		}
		
	}
	
	public static void setNewPage(final String NewMessageURL) {

		// First we check if its on the page list already.
		// ==

		int TabCount = CurrentLocationTabs.getWidgetCount();
		int cindex = 0;
		System.out.println("/n index" + cindex + "tabCount" + TabCount); //$NON-NLS-1$ //$NON-NLS-2$

		while (cindex < TabCount) {
			if (openPages.get(cindex).indexOf(NewMessageURL) > -1) {

				Log.info("match. page Already Open."); //$NON-NLS-1$
				// we set it to front and return
				
				
				
				CurrentLocationTabs.selectTab(cindex);

				return;
			}

			cindex++;
		}

		// if it dosnt;
		Log.info("setting page " + NewMessageURL); //$NON-NLS-1$
		CurrentLocationTabs.OpenPagesInSet.add(NewMessageURL.replace(
				".html", "")); //$NON-NLS-1$ //$NON-NLS-2$

		// place the current location in a temp
		final LocationTabSet TempCurrentLocationTabs = CurrentLocationTabs;

		// disable answer box
		AnswerBox.setEnabled(false);

		// turned off while offline

		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.POST,
				textfetcher_url);

		
		//update pending list
		NumberOfChaptersLeftToLoad++;
		
		
		try {
			// requestBuilder.sendRequest("", new RequestCallback() {
			requestBuilder
					.sendRequest(
							"FileURL=Game Message Text/" + NewMessageURL.trim(), new RequestCallback() { //$NON-NLS-1$
								public void onError(Request request,
										Throwable exception) {
									System.out.println("http failed"); //$NON-NLS-1$
									AnswerBox.setEnabled(true);

									AnswerBox.setText(""); //$NON-NLS-1$
								}

								public void onResponseReceived(Request request,
										Response response) {

									//instertItemsIntoText
									
									String responseString = response.getText();
									
									//Window.alert("response string = "+responseString);
									
									
									HTML StoryText = new HTML(MyApplication.SwapCustomWords(responseString)
													+ "<br><br>"); //$NON-NLS-1$
									
									//we used to have a scroller here, but now it might not be needed, so we replace it with a simple panel
									//ScrollPanel StoryScroller = new ScrollPanel();
									SimplePanel StoryScroller = new SimplePanel();
									//set relative
									 DOM.setStyleAttribute(StoryScroller.getElement(), "position", "relative");
									
									 StoryScroller.add(StoryText);
									
									//StoryScroller.add(new HTML("|^^^^^^^^^^^^^^^^^^^^^^^^"));
									
									StoryText.getElement().getStyle().setPropertyPx("padding", 0);
									StoryText.getElement().getStyle().setPropertyPx("margin", 0);
									
									System.out.println(StoryText);
									String randomstyle = "backgroundtexture" + ((int) ((Math.random() * 3) + 1)); //$NON-NLS-1$

									StoryText.addStyleName("maintextsettings");
									// if firefox, set the back of the scroller
									// instead
									if (MyApplication.Client.toLowerCase()
											.contains("firefox")
											|| MyApplication.Client
													.toLowerCase().contains(
															"chrome")) {
										 StoryScroller.addStyleName(randomstyle);
										// MyApplication.DebugWindow.addText("firefox
										// found");

									} else {
										StoryText
												.setStylePrimaryName(randomstyle);
										MyApplication.DebugWindow
												.addText("client found="
														+ Client);

									}

									
									StoryText.addStyleName("pngfix");
									
									StoryScroller.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$
									
									DOM.setStyleAttribute(StoryScroller
											.getElement(), "zIndex", "150");

									StoryText.setHeight("100%"); //$NON-NLS-1$ //$NON-NLS-2$
									//StoryText.SetWidth("100%");
									
									
									// StoryText.addStyleName("overflowscroll");

									// TempCurrentLocationTabs.addStyleName("overflowscroll");
									TempCurrentLocationTabs
											.setHeight(Story_Text_Height + "px"); //$NON-NLS-1$
									TempCurrentLocationTabs
											.setWidth((Story_Text_Width - 2)
													+ "px"); //$NON-NLS-1$

									TempCurrentLocationTabs.setSize(
											"100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$

									// TempCurrentLocationTabs.setHeight(TempCurrentLocationTabs.getOffsetHeight()+"px");

									Label Tab = new Label();
									Tab.setText(NewMessageURL.substring(0,
											NewMessageURL.length() - 5));

									// if current location is the active one,
									// then we add to the lists;

									if (TempCurrentLocationTabs
											.equals(CurrentLocationTabs)) {
										// add opened chapter name to list
										openPages.add(NewMessageURL);
										// set chapter name to match
										locationpuzzlesActive.add(location);
										AnswerBox.setEnabled(true);
										AnswerBox.setFocus(true);
										AnswerBox.setText(""); //$NON-NLS-1$
									}
									TempCurrentLocationTabs
											.add(StoryScroller, (NewMessageURL
													.substring(0, NewMessageURL
															.length() - 5)));
									TempCurrentLocationTabs
											.selectTab(TempCurrentLocationTabs
													.getWidgetIndex(StoryScroller));
									
									
									//now we add items if theres any.
									//Window.alert("trying to swap text over"+responseString);	
									if (responseString.contains("<!-- item=\"")){
										Log.info("adding divs");
										insertItemDivsIntoText(StoryText);		
										
									}
									if (responseString.contains("<!-- run")){
										Log.info("running commands for page");
										runPagesCommands(StoryText,NewMessageURL);
										
										
										
									}
									System.out.print("\n -----------------number of temp tabs = "+TempCurrentLocationTabs.getWidgetCount());
									// new line;
								//	CurrentLocationTabs = TempCurrentLocationTabs;
									// ---
									System.out.print("\n -----------------number of current tabs = "+CurrentLocationTabs.getWidgetCount());
									
									//note the -15 is new also -5 more from the height
									StoryText
											.setSize(
													Story_Text_Width - 30 - 15
															+ "px", Story_Text_Height - 55 + "px"); //$NON-NLS-1$ //$NON-NLS-2$

									
									
									
									
									//update pending list
									NumberOfChaptersLeftToLoad--;
									//check if selection if nesscery
									if (triggerSelectCheck){
										//Window.alert(" setting page too :"+pageToSelect+":");
										selectPage( pageToSelect);	
									}
								//	Window.alert("setting new page"+StoryText);
									
								}

								
							});
		} catch (RequestException ex) {
			System.out.println("cant load message text"); //$NON-NLS-1$
			AnswerBox.setEnabled(true);

			AnswerBox.setText(""); //$NON-NLS-1$
		}
	}

	
	static public void runPagesCommands(HTML storyText, String NewMessageURL) {
		
		//need to devid this into two sections; "run once" and "run everytime"
		
		//find "run once" commands and process ---------
				
		//get start of commands;
		//these commands are in the format;
		//<!-- run:Message="blahblah";AddItem=blah; -->
		
		String Text =  storyText.getHTML();
		
		
		int Start = Text.indexOf("runonce:")+8;	
		int End = Text.indexOf("-->",Start);
		String commands = "";
		if (Start>8){
		commands = " - "+Text.substring(Start, End).replaceAll(";","\n - ");
		if (commands.endsWith(" - ")){
			commands = commands.substring(0, commands.length()-3);
		}
		
		Log.info("run once commands ="+commands+"."+Start+"|"+End);		
		processInstructions(commands,"fromStoryText"+NewMessageURL);
		}
		
		//find "run everytime" commands store and process ---------
		//
		//
		//
		 Start = Text.indexOf("run:")+4;		
		 End = Text.indexOf("-->",Start);
		 
		 if (Start>4){
         commands = " - "+Text.substring(Start, End).replaceAll(";","\n - ");
			if (commands.endsWith(" - ")){
				commands = commands.substring(0, commands.length()-3);
			}			
			//Log.info("run everytime commands ="+commands+"."+Start+"|"+End);
			Log.info("storing commands in ~"+NewMessageURL.split("\\.")[0]+"~");
			
			PageCommandStore.AddItem(commands,NewMessageURL.split("\\.")[0]);		
			
		 //Store it	
			processInstructions(commands,"fromStoryText"+NewMessageURL);
			
		 }
		
		
		
	}

	static public String RemoveCartReturns(String input_string) {
		input_string = input_string.replaceAll("\n", " "); //$NON-NLS-1$ //$NON-NLS-2$
		input_string = input_string.replaceAll("\r", " "); //$NON-NLS-1$ //$NON-NLS-2$
		input_string = input_string.replaceAll("\r\n", " "); //$NON-NLS-1$ //$NON-NLS-2$
		return input_string;
	}

	
	/** This inserts the divs that get replaced by inventory items Allowing images, tigs and other items 
	 * to be embeded straight into the page :) **/
	static public void insertItemDivsIntoText(HTML input_text) {
		
		String input_string = input_text.getHTML();
		
		//String input_string = input_text.getText();
		int starthere = 0;
		//array of widget names
		//ArrayList<String> widgets_to_add_ids = new ArrayList<String>();
		//widgets_to_add_ids.clear();
		
		//	int BookShelfNum = 0; // change to global later
		
		//Window.alert("searching for <item= in :\n"+input_string);
		
		
			while (input_string.indexOf("<!-- item=\"", starthere) > 0) { //$NON-NLS-1$

				//Window.alert("looking for item match");
				
				//starthere = starthere + 1;
				int bookshelfloc = input_string.indexOf("<!-- item=\""); //$NON-NLS-1$
				if (bookshelfloc == -1 ){
					//Window.alert("no matchs found");
					return;
				}
				//Window.alert("found at:"+bookshelfloc);
				
				//        "\>
				int itemnameendloc = input_string.indexOf("\"", bookshelfloc+11); //$NON-NLS-1$
				int bookshelfendloc = input_string.indexOf("-->", bookshelfloc); //$NON-NLS-1$
				//Window.alert("ends at:"+bookshelfendloc);
				
				String stringbefore = input_string.substring(0, bookshelfloc);
				String itemName = input_string.substring(bookshelfloc + 11,
						itemnameendloc);
				
				String stringafter = input_string.substring(bookshelfendloc + 3);

				
				// input_string =
				// stringbefore+"<a class=\"bookshelf\" href=\""+stringurl+"\"
				// target=\"_blank\"><img border=\"0\" src=\"blank.gif\"
				// width=\"30\" height=\"29\"></a>"
				// +stringafter;

				
				
				
				//((InventoryIcon)currentItem.getDropTarget())
				
				//Window.alert("getting item "+itemName);
				
				//String testName = InventoryPanel.itemList.get(0).itemName;
								
			
				
				//add the item.
				//	Window.alert("trying to add item");
					try {
						
					//	Window.alert("add item:"+itemName);
						//processInstructions("- AddItem = "+itemName,"addItemFromStoryText");
						
						
						if (PlayersInventory.playerHasItem(itemName) == false) {
							Log.info("adding item");
								PlayersInventory.AddItem(itemName);
						}
						
					
					} catch (Exception e) {
						
						Window.alert("cant add item");
					}
					
					//Window.alert("getting item 2"+itemName);
					
										
				
					
				
				//Window.alert(itemName);
				
				//String popupElement = ((InventoryIcon)InventoryPanel.itemList.get(0).getDropTarget()).PopUp.getElement().getString();
				//String popupElement = ((InventoryIcon)InventoryPanel.itemList.get(0).getDropTarget()).ItemWithShadow.getElement().getString();
				
				input_string = stringbefore
				+ "<div ID=\""+location+"_item_"+itemName+"\"></div>" + stringafter; //$NON-NLS-1$ 						
				
				//find item named that
				
				
				 widgets_to_add_ids.add(location+"_item_"+itemName);				 
				
				starthere = bookshelfendloc+2;
				
			}			
		//	Window.alert("divs added?:"+input_string);
			
			input_text.setHTML(input_string);
					
				
			
			//now the text is updated, we attach the items, but we first have to wait for any new ones to load;
			Timer newTestTimer = new Timer(){

				@Override
				public void run() {
					//Log.info("checking for inline items");
					
					//check all IDs have loaded
					int i=0;
					while (i<widgets_to_add_ids.size()){
						String itemToAddsName = widgets_to_add_ids.get(i);
						Widget ItemToAdd = PlayersInventory.getItem(itemToAddsName.replaceFirst(location+"_item_", ""));			
						if (ItemToAdd == null){
							Log.info("no item found under that name : "+itemToAddsName);
							//Window.alert("no item found under that name : "+itemToAddsName);
							return;
						}
						i++;
					}
					//if all are ok we update	
					//Log.info(i+" items found");
					
					updateWidgetsInStoryText();
					this.cancel();
				}
				
			};
			
			
			//in future we should tie this to the loading of the text itself.
			newTestTimer.scheduleRepeating(50);
					
		return;
	}

	private static void updateWidgetsInStoryText() {
		int i=0;
		while (i<widgets_to_add_ids.size()){
			
			Log.info("adding items to page");
			
			String itemToAddsName = widgets_to_add_ids.get(i);
			
			Widget ItemToAdd = PlayersInventory.getItem(itemToAddsName.replaceFirst(location+"_item_", ""));			
			if (ItemToAdd == null){
				Log.info("no item found under that name : "+itemToAddsName);
				return;
			}
			RootPanel.get(itemToAddsName).add(ItemToAdd);	
			
			//remove the item (this is quite crude, having to add it to the inventory and remove it again, probably should have an internal store
			//Window.setTitle("removing item from store:"+itemToAddsName.replaceFirst(location+"_item_", ""));
			
			PlayersInventory.RemoveItem(itemToAddsName.replaceFirst(location+"_item_", ""));	
		
		i++;
		}
		widgets_to_add_ids.clear();
	}
	
	static public void SwapUserSpecificWords(){
		
		
		if (loggedIn) {
			controllscript = controllscript.replaceAll("<USERNAME>", Username); //$NON-NLS-1$
			controllscript = controllscript.replaceAll("<ORGANISATION>", Organisation); //$NON-NLS-1$
		}
		
		
	}
	
	static public String SwapCustomWords(String input_string) {
		
		
		if (loggedIn){
			 //SwapUserSpecificWords();
			input_string = input_string.replaceAll("<USERNAME>", Username); //$NON-NLS-1$
			input_string = input_string.replaceAll("<ORGANISATION>", Organisation); //$NON-NLS-1$
		}
		
		//replace variables
		Iterator<String> VarNames = GameVariables.getAllUniqueNames().iterator();
		
		while(VarNames.hasNext()){
			
			String currentVarName = VarNames.next().toLowerCase();
			String currentVarValue = GameVariables.GetItem(currentVarName).toLowerCase(); 
			input_string = input_string.replaceAll("<V:"+currentVarName+">", currentVarValue); //currentVarName
			
		}
		
		
		
		// bookshelf link swap
		// <bookshelf="www.blah.com">
		// <a class="bookshelf" href="www.blah.com"></a>
		// get location
		int starthere = 0;
	//	int BookShelfNum = 0; // change to global later
		while (input_string.indexOf("<bookshelf=\"", starthere) > 0) { //$NON-NLS-1$

			starthere = starthere + 1;
			int bookshelfloc = input_string.indexOf("<bookshelf=\""); //$NON-NLS-1$
			int bookshelfendloc = input_string.indexOf("\">", bookshelfloc); //$NON-NLS-1$
			String stringbefore = input_string.substring(0, bookshelfloc);
			String stringurl = input_string.substring(bookshelfloc + 12,
					bookshelfendloc);
			String stringafter = input_string.substring(bookshelfendloc + 2);

			// input_string =
			// stringbefore+"<a class=\"bookshelf\" href=\""+stringurl+"\"
			// target=\"_blank\"><img border=\"0\" src=\"blank.gif\"
			// width=\"30\" height=\"29\"></a>"
			// +stringafter;

			input_string = stringbefore
					+ "<a style=\"height:32px\" href=\"" + stringurl + "\" target=\"_blank\"><img height=\"29\" width=\"32\" border=\"0\" class=\"bookshelf\" src=\"blank.gif\"/></a>" + stringafter; //$NON-NLS-1$ //$NON-NLS-2$
		}
		
		
		
		
		return input_string;
	}

	public void test_for_logged_in_user() {

		RequestBuilder requestBuilder2 = new RequestBuilder(RequestBuilder.GET,
				homeurl+"Login_System/TestIfUserIsLoggedIn.php"); //$NON-NLS-1$
		try {
			requestBuilder2.sendRequest("", new RequestCallback() { //$NON-NLS-1$
						public void onError(Request request, Throwable exception) {
							System.out.println("error in user logged in test"); //$NON-NLS-1$
						}

						public void onResponseReceived(Request request,
								Response response) {
							
							
							if (response.getText().compareTo("NO") == 0) { //$NON-NLS-1$
								// display login box
								System.out.println("response"); //$NON-NLS-1$

								// RootPanel.get().add(
								// MyApplication.loginbackground, 0, 0);

								DOM.setStyleAttribute(fadeback.getElement(),
										"z-Index", "" + (z_depth_max + 1)); //$NON-NLS-1$ //$NON-NLS-2$
								z_depth_max = z_depth_max + 1;
								user_login.show();
								user_login.center();
								DOM.setStyleAttribute(user_login.getElement(),
										"z-Index", "" + (z_depth_max + 1)); //$NON-NLS-1$ //$NON-NLS-2$
								z_depth_max = z_depth_max + 1;

								// set user as not logged in
								Username = "not logged in"; //$NON-NLS-1$
								MyApplication.loggedIn = false;

							} else if (response.getText().startsWith("NOLOGIN") == true) {

								
								
								Organisation = response
										.getText()
										.substring(
												response.getText().indexOf(
														"organisation:") + 13, response.getText().indexOf("~", response.getText().indexOf("organisation:") + 13)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
						//		Client = response
						//				.getText()
						//				.substring(
						//						response.getText().indexOf(
						//								"client:") + 7, response.getText().indexOf("~", response.getText().indexOf("client:") + 7)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

								if (DOM.getElementById("tempback")!=null){
									
									MyApplication.fadeWebpageOverlay();
									//fade out backgroundd
								//DOM.setStyleAttribute(DOM
									//	.getElementById("tempback"),
									//	"visibility", "hidden");
								
								}
								Window.setTitle(LoadGamesText.MainGame_Welcome_Back +" (nologin system found");
								
								Window.setStatus(Client);
								
								DebugWindow.addText("client=" + Client);
								DebugWindow.addText("response text="+ response.getText());
								
								MyApplication.loggedIn = false;
								
								// Feedback.setText("response
								// text="+response.getText());
								// now we wait for the controll script to load
								// before starting
								if (controllscript.length() > 5) {
									start_of_game_script();
								} else {

									Timer startgamedelay = new Timer() {

										@Override
										public void run() {
											if (controllscript.length() > 5) {
												start_of_game_script();
												this.cancel();
											}
										}

									};

									startgamedelay.scheduleRepeating(100);

								}

							} else {
								Username = response
										.getText()
										.substring(
												response.getText().indexOf(
														"username:") + 9, response.getText().indexOf("~", response.getText().indexOf("username:") + 9)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
								Organisation = response
										.getText()
										.substring(
												response.getText().indexOf(
														"organisation:") + 13, response.getText().indexOf("~", response.getText().indexOf("organisation:") + 13)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
						//		Client = response
						//				.getText()
						//				.substring(
						//						response.getText().indexOf(
						//								"client:") + 7, response.getText().indexOf("~", response.getText().indexOf("client:") + 7)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
								// we set the username, and log him in.

								
								Window
										.setTitle(LoadGamesText.MainGame_Welcome_Back
												+ Username);
								Window.setStatus(Client);
								DebugWindow.addText("client-" + Client);
								user_login.LoginUser();
								
								//enable scrollbars
								Window.enableScrolling(true);
								
								
								/*
								DebugWindow.addText("Setting text-"+Client);
								
								if (Client.indexOf("Firefox") > -1) { //$NON-NLS-1$
									StoryTabs.getDeckPanel().setAnimationEnabled(false);
									StoryTabs.setAnimationEnabled(false);

								} else {
									StoryTabs.getDeckPanel().setAnimationEnabled(true);

								}*/
							}
							// now we know is the user is logged in or not, we
							// start the preloader;
							// // then the preloader
							RequestBuilder requestBuilder3 = new RequestBuilder(
									RequestBuilder.POST, textfetcher_url);

							try {
								requestBuilder3
										.sendRequest(
												"FileURL=" + "Preloadlist.txt", new RequestCallback() { //$NON-NLS-1$ //$NON-NLS-2$
													public void onError(
															Request request,
															Throwable exception) {

														MyApplication.DebugWindow
																.setText("\n preloader failed exception" + exception.getLocalizedMessage()); //$NON-NLS-1$
													}

													public void onResponseReceived(
															Request request,
															Response response) {

														// MyApplication.DebugWindow.setText("\n
														// preloading"+response.getText());
														// Preloader = new
														// Preloader(response.getText());

														// split up to array
														List<String> LoadingList = Arrays
																.asList(response
																		.getText()
																		.split(
																				"\n"));

														//ArrayList<String> LoadingArrayList = new ArrayList<String>(
														//		LoadingList);

														// Window.alert("<br>preloading
														// list"+LoadingArrayList.size());
														Iterator<String> it = (LoadingList
																.iterator());

														// loop over
														while (it.hasNext()) {
															String preloadthis = it
																	.next()
																	.trim();
															Preloader
																	.addToLoading(preloadthis);
														}

														Preloader.preloadList();
													}
												});
							} catch (RequestException ex) {
								MyApplication.DebugWindow
										.setText("\n preloader failed"); //$NON-NLS-1$
							}
						}

					});

		} catch (RequestException ex) {
			
			Window.alert("no login system found, assumeing guest user");
			
			System.out.println(" cant check login, assume guest"); //$NON-NLS-1$
			
			//load data
			MyApplication.loadGameData(" newuser");
			MyApplication.messagehistory.messageslist.setHTML("(No login script found, assumeing guest user");
			//activate game
			MyApplication.maingameloop();
			MyApplication.user_login.hide();
			//fix size
			MyApplication.resizeStoryBox();
		
			MyApplication.Username = "guest"; //$NON-NLS-1$
			MyApplication.Organisation = "pc";
			
		}

	}
	public void onValueChange(ValueChangeEvent<String> event) {
		
		
		
		try {
			String PostString = event.getValue();
			updateStatus(PostString);
		} catch (Exception e) {			
			// TODO Auto-generated catch block
			Window.alert("history update error");
		}
	}

	public void updateStatus(String PostString) {
//
		
		
		System.out
				.print("_____________________________________----------------------------------------"); //$NON-NLS-1$

		PostString = URL.decode(PostString);
		if (PostString.startsWith("DEBUG")) { //$NON-NLS-1$

			//processInstructions("\n - AddItem = 1 Amuse \n- AddItem = 1 Cuypersmusical \n- AddItem = 1 Krantenartikel \n- AddItem = 1 Moordenaar \n- AddItem = 1 Portretcollage \n- AddItem = Loep \n- AddProfile = Pierre Cuypers junior.html \n- AddProfile = Pierre J.H. Cuypers.html \n- NewChapter = \"1 Welkom\" \n- StoryBox = 1 Welkom.html \n- AddMusicTrack = 1 INTRO.mp3 \n- SetScore = 2500 \n- PointsAwardedFor =  \n- SetLocation = Start \n- SetBackgroundImage = GameTextures/CCmonPCdark.jpg \n- SetClockLadyIcon = .png,1 \n- SetInventoryIcon = .png,6  \n","debug");
			
			
			processInstructions(
					"- AddItem = newspaper \n - AddItem = TextScrollTest \n - AddItem = whokilledhans \n - AddItem = magnifyingglass \n - AddItem = TigDemo2 \n - AddProfile = Pierre J H Cuypers.html \n - StoryBox = 1 Welkom.html \n - StoryBox = 1.1 Help.html \n - StoryBox = 1.2 Score.html \n - SelectPage = 1 Welkom.html", "Debug"); //$NON-NLS-1$
		}

		if (PostString.startsWith("LoadGameData=")) { //$NON-NLS-1$

			final String GameData = PostString.substring(13);

			// de-encrypt string and load the data
			loadGameData(GameData);
			// ------

		} else {
			Log.info("answer given from updatestatus");
			//Window.alert(PostString);
			 AnswerGiven(PostString);
		}

	}

	private void resizeEverything() {
		
		//unfix width of frame;
	//DOM.getElementById("gwtlink_borderframe").setAttribute("style", "");
		
		//wait a moment
		
		//Timer resizeStuffNOW = new Timer(){

		//	@Override
		//	public void run() {

				Game_Window_Width = Window.getClientWidth();
				
				//get width of border
				//int Game_Frame_Width = DOM.getElementById("gwtlink_borderframe").getOffsetWidth();
				
				
				
				
//				Game_Window_Height = Window.getClientWidth();

				try {
					setInterfaceIconSize();
				} catch (Exception e) {
				
					e.printStackTrace();
				}
				

				// resize message history if open
				if (MessageHistoryOpen == true) {
					RootPanel.get().remove(messagehistory);
					MessageHistoryOpen = false;
					MessageHistoryButton.setAnimateClose();
				}

				resizeStoryBox();

				// resize inventory if open
				if (InventoryOpen == true) {
					PlayersInventory.OpenDefault();
				}

				// reposition cluebox
				//RootPanel.get().add(ScoreAndClueBox,
				//		Window.getClientWidth() - 229, 7);


				
				DOM.setStyleAttribute(ScoreAndClueBox.getElement(), "zIndex",
						"110");

				
				//RootPanel.get().add(ClueReveal,
				//		DOM.getElementById("bigtextbox").getAbsoluteLeft()+20,
				//		DOM.getElementById("bigtextbox").getAbsoluteTop() -8);
				RootPanel.get().add(ClueReveal,	ScoreBack.getAbsoluteLeft(),ScoreBack.getAbsoluteTop()+ScoreBack.getOffsetHeight()-5);
				
				
				DOM
						.setStyleAttribute(ClueReveal.getElement(), "zIndex",
								"1000");
				playersClues.setSize((DOM.getElementById("bigtextbox").getOffsetWidth()-14)+"px", (DOM.getElementById("bigtextbox").getOffsetHeight()-21)+"px");
				
//			ClueReveal.setWidth(ScoreAndJokerContainer.getOffsetWidth()
//					+ "px");
				
				
				if (Document.get().getElementById("musicControll")!=null){
				RootPanel.get("musicControll").add(musicPlayer); //$NON-NLS-1$
				}
				musicPlayer.setSize("90%", "100%");
				

				//fix width of frame so its not a %
				//this makes scrolling neater		
			//	DOM.getElementById("gwtlink_borderframe").getStyle().setPropertyPx("width",Game_Frame_Width);
		//	}
		
		
	//	};
		
		//resizeStuffNOW.schedule(4000);
	}

	static public void resizeStoryBox() {

		
		
		RootPanel.get().add(closeallwindows, Window.getClientWidth() - 55, 0);
		DOM.setStyleAttribute(closeallwindows.getElement(), "zIndex", "1805");

		// set animation for all except firefox3 (has some glitch)
		// Feedback.setTitle(Client);
		//Log.info("Resizing for-"+Client);
		
		if (Client.toLowerCase().indexOf("firefox") > -1) { //$NON-NLS-1$
			StoryTabs.getDeckPanel().setAnimationEnabled(false);
			StoryTabs.setAnimationEnabled(false);

		} else {
			StoryTabs.getDeckPanel().setAnimationEnabled(true);
			
			//note;at some point this should be a proper options system
			StoryTabs.getDeckPanel().setAnimationEnabled(false);
			StoryTabs.setAnimationEnabled(false);
		}

		//tempory remove these buttons, as they are being moved, it looks nicer for them to disasper first
		RootPanel.get().remove(MessageHistoryButton);
		RootPanel.get().remove(MessageBackButton);
		RootPanel.get().remove(MessageForwardButton);
		
		
		
		Timer Blah = new Timer() {
			@Override
			public void run() {
				
				// Store screen settings
				Story_Text_Height = RootPanel
						.get("bigtextbox").getOffsetHeight() - 5; //used to be -2
				
				Story_Text_Width = RootPanel.get("bigtextbox").getOffsetWidth() - 5; //$NON-NLS-1$

				Log.info("setting size to-"+Story_Text_Height+","+Story_Text_Width);
				
				
				//if width not set, run this again later
				if (Story_Text_Width<10){					
					this.cancel();
					this.schedule(1200);
					return;
				}
				
				DebugWindow.addText("" + Story_Text_Height); //$NON-NLS-1$

				RootPanel.get("bigtextbox").add(StoryTabs); //$NON-NLS-1$
				// fix text window to right size
				// StoryTabs.setWidth(Story_Text_Width+"px");
				
				
				
				
				StoryTabs.getDeckPanel().setSize(
						Story_Text_Width + "px", Story_Text_Height + "px"); //$NON-NLS-1$ //$NON-NLS-2$

				
				
				CurrentLocationTabs.getDeckPanel().setSize(
						Story_Text_Width + "px", Story_Text_Height + "px"); //$NON-NLS-1$ //$NON-NLS-2$
				CurrentLocationTabs.setWidth(Story_Text_Width + "px"); //$NON-NLS-1$

				//fix score position
				if (ScoreBoxVisible){
				RootPanel.get().add(ScoreAndClueBox, ScoreBack.getAbsoluteLeft(),ScoreBack.getAbsoluteTop()+(ScoreBack.getHeight()/2)-15);
				}


				Log.info("setting size to-"+Story_Text_Height+","+Story_Text_Width);
				
				// fix all the stoytex to the right size
				for (Iterator<LocationTabSet> currentlocation = (AllLocationTabSets
						.iterator()); currentlocation.hasNext();) {

					LocationTabSet These = currentlocation.next();
					These.setWidth(Story_Text_Width + "px"); //$NON-NLS-1$
					These.getDeckPanel().setWidth(Story_Text_Width + "px"); //$NON-NLS-1$
					These.setHeight("100%"); //$NON-NLS-1$
					These.getDeckPanel().setHeight("100%"); //$NON-NLS-1$

					int x = 0;
					for (Iterator<Widget> it = (These.iterator()); it.hasNext();) {

						x++;
						// we set the scrollpanel containter to the correct
						// width and height;

						// then we set the with of the contents;
						ScrollPanel scrollybit = ((ScrollPanel) (it.next()));

						scrollybit.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$
						
						//scrollybit.getWidget().setSize(
						//		"100%", (Story_Text_Height - 80) + "px"); //$NON-NLS-1$ //$NON-NLS-2$
						scrollybit.getWidget().setHeight(
								 (Story_Text_Height - 80) + "px"); //$NON-NLS-1$ //$NON-NLS-2$
						//set width?
						scrollybit.getWidget().setWidth(
								 (Story_Text_Width - 80) + "px"); //$NON-NLS-1$ //$NON-NLS-2$

						
						
						DOM.setStyleAttribute(scrollybit.getElement(),
								"zIndex", "150");
						
						// ((ScrollPanel)(it.next())).setSize((Story_Text_Width-10)+"px",(Story_Text_Height-50)+"px");
						// Window.setTitle( "x="+x+" set to="+Story_Text_Width
						// );
					}

				}
				
				
				//reposition message history
				DebugWindow.setTitle("resizing");
				
				RootPanel.get().add(MessageHistoryButton,
						DOM.getElementById("feedback").getAbsoluteLeft()+ Feedback.getOffsetWidth()-20,
						DOM.getElementById("feedback").getAbsoluteTop());

				RootPanel.get().add(MessageForwardButton,
						MessageHistoryButton.getAbsoluteLeft() - 20,
						MessageHistoryButton.getAbsoluteTop());

				RootPanel.get().add(MessageBackButton,
						MessageHistoryButton.getAbsoluteLeft() - 40,
						MessageHistoryButton.getAbsoluteTop());
				DebugWindow.setTitle("..done message history bits :"+DOM.getElementById("feedback").getAbsoluteTop()+" :"+FeedbackContainer.getAbsoluteTop()+":");
				
				// reposition clock relative to statue if statue is there, if not we wait for it to appear
				
				
				//if clocklady is present we position the clock
				if (Document.get().getElementById("clocklady") != null)
				{
				
				if (StatueHead.getWidth()>33){
				//	Window.alert("drawing clock"+StatueHead.getWidth());
				RootPanel.get().remove(gwt_clock);
				RootPanel.get("clocklady").add(gwt_clock, (int) (StatueHead.getOffsetWidth() * 0.315), (int) (StatueHead.getOffsetWidth() * 0.585)); //$NON-NLS-1$

				gwt_clock.setRadius((int) (StatueHead.getOffsetWidth() / 2.2));
				} else {
					
					Timer displayClockAfterStatueLoaded = new Timer(){

						@Override
						public void run() {
							//Window.alert("testing statue:"+StatueHead.getWidth());
							
							if (StatueHead.getWidth()>33){
								//Window.alert("drawing clock");
								RootPanel.get().remove(gwt_clock);
								RootPanel.get("clocklady").add(gwt_clock, (int) (StatueHead.getOffsetWidth() * 0.315), (int) (StatueHead.getOffsetWidth() * 0.585)); //$NON-NLS-1$


								gwt_clock.setRadius((int) (StatueHead.getOffsetWidth() / 2.2));
								this.cancel();
								
							} 
						}
						
					};
					
					displayClockAfterStatueLoaded.scheduleRepeating(1000);
					
				}
				
				
				}
				//reposition music box to float above the rest if music box is present
				if (Document.get().getElementById("musicControll")!=null){
					
				int MpSizeX = DOM.getElementById("musicControll").getOffsetWidth()-60;
				int MpSizeY = musicPlayer.CurrentMusicTrackLabel.getOffsetHeight();
				int MpX = DOM.getElementById("musicControll").getAbsoluteLeft()+20;
				int MpY = DOM.getElementById("musicControll").getAbsoluteTop()+DOM.getElementById("musicControll").getOffsetHeight();					
				musicPlayer.CurrentMusicTrackLabel.setPixelSize(MpSizeX, MpSizeY);
				musicPlayer.CurrentMusicTrackLabel.ListContainer.setWidth(MpSizeX+"px");
				musicPlayer.CurrentMusicTrackLabel.getElement().getStyle().setProperty("zIndex", "500");
				RootPanel.get().add(musicPlayer.CurrentMusicTrackLabel, MpX,MpY-23);
				musicPlayer.setSize(DOM.getElementById("musicControll").getOffsetWidth()+"px", "100%");
				
				}

			}
		};
		// deattach the Storytext stuff
		RootPanel.get("bigtextbox").remove(StoryTabs); //$NON-NLS-1$

		// wait a mo for the browser to catch up (if its IE that is, Opera works
		// just dandy)
		if (Client.indexOf("msie") > -1) { //$NON-NLS-1$
			
		//	Window.alert("triggering IE resize in 0.9 seconds");
			Blah.schedule(900);
			
			//firefox probably dosnt need it
		} else if (Client.indexOf("firefox2") > -1) { //$NON-NLS-1$
			Blah.schedule(900);
		} else {
			Blah.run();
		}



	}

	public static void loadGameData(String GameData) {

		//remove first space
		GameData = GameData.substring(1);
		// Feedback.setText("new user-"+GameData);
		MyApplication.Feedback.setTitle("loading game 2.5");
		if ((GameData.compareTo("newuser") == 0) || (GameData.length() < 4)) { 
			MyApplication.Feedback.setTitle("loading game 2.6");
			DebugWindow.addText("start game script");
			start_of_game_script();
			MyApplication.Feedback.setTitle("loading game 2.8");
			musicPlayer.CurrentMusicTrackLabel
					.setItemSelected(musicPlayer.CurrentMusicTrackLabel
							.getItemCount() - 1,true);
			musicPlayer.playtrack(MusicBox.musicTracks.size() - 1);
			user_login.hide();
		} else {

			

			// make sure login is off
			MyApplication.user_login.hide();

			//double check
			if (GameData.length() < 4) {
				return;
			}

			String responsetext = GameData.replaceAll("<br />", "\n"); //$NON-NLS-1$ //$NON-NLS-2$
			responsetext = responsetext.replaceAll("<br>", "\n"); //$NON-NLS-1$ //$NON-NLS-2$
			responsetext = responsetext.substring(0, responsetext
					.indexOf(":end")); //$NON-NLS-1$
			// Window.alert(responsetext);
			// Feedback.setText(responsetext);
			// update widgets HTML field
		//	System.out.println("\n Instructions-:" + GameData); //$NON-NLS-1$
			
					
			processInstructions(responsetext, "Loading");

			// start music
//
//			MusicBox.CurrentMusicTrackLabel
//					.setItemSelected(musicPlayer.CurrentMusicTrackLabel
//							.getItemCount() - 1, true);
//			musicPlayer.playtrack(MusicBox.musicTracks.size() - 1);
			// }
			// });
			// } catch (RequestException ex) {
			// String responsetext = "can not process save file"; //$NON-NLS-1$
			// System.out.print(responsetext + " " + ex.getMessage());
			// //$NON-NLS-1$
			// }

		}

	}
	
	static boolean checkConditionals(String conditions){
		
		
		//the conditions should be a coma seperated list of conditions
		//loop for each
		
		
		conditions = conditions.trim().toLowerCase();
		 
		String conditionsArray[];
		
		
		
		if (conditions.contains("&&")){
			Log.info("splitting conditions...");
		conditionsArray = conditions.split("&&");
		} else {
			Log.info("just one condition...");
		conditionsArray = new String[]{conditions};
		}
		
		for (String currentCondition : conditionsArray) {
        
			
		Log.info("current condition="+currentCondition);
			
      
		String currentConditionType = currentCondition.split(" = ")[0].trim();
		String currentProperty = currentCondition.split(" = ")[1].trim();
		
		Log.info("checkingtype "+currentConditionType);
		Log.info("checkingpropety "+currentProperty);
		
		if (currentConditionType.startsWith("playerhas")){
			//check player has item
			if (PlayersInventory.playerHasItem(currentProperty)){
				Log.info("player has item "+currentProperty+"(passed check)");					
			} else {
				return false;
			}
		}
		if (currentConditionType.startsWith("playerdoesnothave")){
			//check player has item
			if (PlayersInventory.playerHasItem(currentProperty)){
					return false;		
			} else {
				Log.info("player dosnt have item "+currentProperty+"(passed check)");	
			}
		}
		if (currentConditionType.startsWith("ison")){
			//check player is on chapter
			if (location.equalsIgnoreCase(currentProperty)){
				Log.info("player is on chapter "+currentProperty+"(passed check)");					
			} else {
				return false;
			}
		}
		if (currentConditionType.startsWith("checkvalue")){
			
			//split property
			String nametocheck = currentProperty.split(",")[0].trim().toLowerCase();
			String valueToCompareTo = currentProperty.split(",")[1].trim().toLowerCase();
			
			//detect if its a greater then comparison
			if (valueToCompareTo.startsWith("<")){
				
				int intValueToCompare = Integer.parseInt(valueToCompareTo.substring(1, valueToCompareTo.length()));
				int existingValue =  Integer.parseInt(GameVariables.GetItem(nametocheck));	
				
				Log.info("variable "+existingValue+" is less then "+intValueToCompare);
				
				if (existingValue<intValueToCompare){
					Log.info("yup, its less then");
					
					continue;	
				} else {
					Log.info("nope, it isn't less then");
					
					return false;
				}
				
			}

			//detect if its a less then comparison
			if (valueToCompareTo.startsWith(">")){
				
				int intValueToCompare = Integer.parseInt(valueToCompareTo.substring(1, valueToCompareTo.length()));
				int existingValue =  Integer.parseInt(GameVariables.GetItem(nametocheck));	
				
				Log.info("variable "+existingValue+" is greater then "+intValueToCompare);
				
				if (existingValue>intValueToCompare){
					Log.info("yup, its greater then");
					
					continue;	
				} else {
					Log.info("nope, it isn't greater then");
					
					return false;
				}
				
			}
					
			//check value is equal
			Log.info("variable "+nametocheck+" does it have value "+valueToCompareTo);
			
			if (GameVariables.GetItem(nametocheck).equals(valueToCompareTo)){
				Log.info("variable "+nametocheck+" has value "+valueToCompareTo);					
			} else {
				Log.info("no, "+nametocheck+" has value "+GameVariables.GetItem(nametocheck));
				
				return false;
			}
		}
		
		 }	 
		
		return true;	
	}
	
	static void fadeWebpageOverlay(){
		
		final Timer fadeout = new Timer (){
			private double backopacity=100;

			@Override
			public void run() {
								
				Style style = DOM.getElementById("tempback").getStyle();
				style.setProperty("filter", "alpha(opacity="+backopacity+")");
				style.setProperty("opacity", ""+(backopacity/100));
				
				//ThisImage.getElement().setAttribute("style", " filter: alpha(opacity="+opacity+"); opacity: "+(opacity/100)+";");
				backopacity=backopacity-6;
				if (backopacity<6){
					DOM.setStyleAttribute(DOM.getElementById("tempback"),"visibility","hidden");
					this.cancel();
					
				}
				
				
				
			}
		
		};

		
		fadeout.scheduleRepeating(100);
		
	return;
	}
}
