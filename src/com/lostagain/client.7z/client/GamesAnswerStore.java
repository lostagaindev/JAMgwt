/**
 * 
 */
package com.darkflame.client;

import java.util.ArrayList;

import com.allen_sauer.gwt.log.client.Log;


/**
 * Stores the games answers and functions to check them
 */
public class GamesAnswerStore {
	
	static final ArrayList<Answer> AllAnswer = new ArrayList<Answer>();
	
	public GamesAnswerStore(String IncomingScriptFile){
		
		
		String CurrentChapter = "";
		String CurrentCodeBlock = "";
		//parse file into array.
		int currentPosInScript = 0;	
		while (currentPosInScript<=IncomingScriptFile.length()){
			
			CurrentChapter = "";
			CurrentCodeBlock = "";
			
			//find next ans line
			int Loc = IncomingScriptFile.indexOf("ans=", currentPosInScript)+4;
			
			//if no ans then exit
			if (Loc == -1){
				break;
			}
			
			
			//extract chapter
			int chapEndLoc;
			//Special-case detection for no chapter specified
		//	Log.info("no chapter test:"+IncomingScriptFile.charAt(Loc));
			
			if (IncomingScriptFile.charAt(Loc) == ':')
			{
				Log.info("no chapter for this ans");
				CurrentChapter = "__any__";
				chapEndLoc = Loc+1;
				
			} else {
			
			   //get the chapter name
			   chapEndLoc = IncomingScriptFile.indexOf(':',Loc+1);
			   CurrentChapter = IncomingScriptFile.substring(Loc, chapEndLoc);
					
			}
			//Log.info("Scanning Chapter = "+CurrentChapter);
			
			//extract ans
			int AnsEnd = IncomingScriptFile.indexOf("\r",chapEndLoc);
			int AnsEnd2 = IncomingScriptFile.indexOf("\n",chapEndLoc);
			AnsEnd = (AnsEnd<AnsEnd2)?AnsEnd:AnsEnd2;
			
				
			String AnsLine = IncomingScriptFile.substring(chapEndLoc+1,AnsEnd);			
			//Log.info("Answer line="+AnsLine);
			
			//create answer array
			String[] AnsArray = getAnswerArray(AnsLine);
			
			//extract codeblock
			int StartLoc =  IncomingScriptFile.indexOf("- ",Loc+1);
			
			//exit if no more codeblocks
			if (StartLoc == -1){
				break;
			}
			
		    int EndLoc = IncomingScriptFile.indexOf("ans=",StartLoc);
			CurrentCodeBlock = IncomingScriptFile.substring(StartLoc, EndLoc);
			//Log.info("Scanning Code = "+CurrentCodeBlock);
			
			//loop over ans and add them
			
			
			
			for (String CurrentAns:AnsArray){
				
				Log.info("storing data for ans;"+CurrentAns+" in chapter "+CurrentChapter);
				Log.info("Code block for this section is...;"+CurrentCodeBlock);
				
				Answer newAnswer = new Answer(CurrentAns.trim(),CurrentChapter.trim(),CurrentCodeBlock);
				//add the answer into the array
				AllAnswer.add(newAnswer);
				
				
			}
			
			
			
			//update current position to end;
			currentPosInScript = EndLoc -1;
				
			
			
		}
		
		
	}
	
	public String[] getAnswerArray(String ansline){
		
		String Ans[] = ansline.split(",");
				
		return Ans;
	}
	
	public String checkAns(String AnsGiven, String InChapter, boolean isCalc){
	
		AnsGiven = AnsGiven.trim();
		//check for exact match first
		String code = checkForExactMatch(AnsGiven,InChapter);
		
		//else we check for wildcard match in the chapter
		if (code==null){
			Log.info("no exact match found for chapter, checking for regex matchs");
			code = checkForWildcardMatch(AnsGiven,InChapter);
		}
		
		//else we check for match not assigned a chapter
		if (code==null){
			Log.info("checking non-specific chapter answers");
			code = checkForNonChapterSpecificAns(AnsGiven,InChapter);
		}
		// if its a calculation we exit here
		if (isCalc){
			Log.info("is calculation, so skip default replys");
			return null;
		}
		//
		
		//else we check for default match in the chapter
		if (code==null){
			Log.info("no exact match found for non specifics, checking for default matchs");
			code = checkForDefaultAns(AnsGiven,InChapter);
		}
		
		
		return code;
	}
	
	/** returns code to run for answer if found, else null**/
	public String checkForExactMatch(String AnsGiven, String InChapter)
	{
		
		
		String code = null;		
		
		//look for ans that fits requirements
		for (Answer Ans:AllAnswer){
			
		//	Log.info("checking for chapter match:"+InChapter+" "+Ans.Chapter);
			//Log.info("checking for ans match:"+AnsGiven+" "+Ans.Answer);
						
			if ((Ans.Chapter.equalsIgnoreCase(InChapter)&&(AnsGiven.equalsIgnoreCase(Ans.Answer)))){
				Log.info("matched"+Ans.ScriptCodeBlock);
				return Ans.ScriptCodeBlock;
				
			}
			
			
		}
		
		//--- else we return null		
		return null;
	}
	
	/** returns code to run for answer if found, else null**/
	public String checkForWildcardMatch(String AnsGiven, String InChapter)
	{
		String code = null;		
		
		//look for ans that fits requirements
		for (Answer Ans:AllAnswer){
			
			if ((Ans.Chapter.equalsIgnoreCase(InChapter)&&(AnsGiven.matches(Ans.Answer)))){
				
				return Ans.ScriptCodeBlock;
				
			}
			
			
		}
		
		//--- else we return null		
		return null;
	}
	
	/** returns code to run for answer if found, else null**/
	public String checkForDefaultAns(String AnsGiven, String InChapter)
	{
		String code = null;		
		
		//look for ans that fits requirements
		for (Answer Ans:AllAnswer){
			
			if ((Ans.Chapter.equalsIgnoreCase(InChapter)&&(Ans.Answer.equals("{default}")))){
				
				
				return Ans.ScriptCodeBlock;
				
			}
			
			
		}
		
		//--- else we return null		
		return null;
	}
	/** check for non-specific-chapter answers **/
	public String checkForNonChapterSpecificAns(String AnsGiven, String InChapter)
	{
		String code = null;		
		
		//look for ans that fits requirements
		for (Answer Ans:AllAnswer){
			
			if ((Ans.Chapter.equals("__any__")&&(Ans.Answer.equalsIgnoreCase(AnsGiven)))){
								
				return Ans.ScriptCodeBlock;
				
			}
			if ((Ans.Chapter.equals("__any__")&&(AnsGiven.matches(Ans.Answer)))){
				
				return Ans.ScriptCodeBlock;
				
			}
			
		}
		
		//--- else we return null		
		return null;
	}
}
