package com.darkflame.client;

import java.util.ArrayList;

import java.util.Iterator;

import com.allen_sauer.gwt.log.client.Log;


public class AssArray {
	final  ArrayList<String> Items = new ArrayList<String>();
	final  ArrayList<String> Names = new ArrayList<String>();
	
	public AssArray(){
		//nothing
	}
	
	/** Adds a new item, but checks the name first and overwrites it if it exists already 
	 * Note, if more then one exists, it overwriters the last one **/
	public void AddItemUniquely(String newitem, String newname){
		
		if (Names.contains(newname)){
		  int indextoremove = getItemIndex(newname);
		  Items.set(indextoremove, newitem);
		  Log.info("Setting existing variable "+indextoremove+" name="+newname+" value="+newitem);
			
		} else {
		  Items.add(newitem);
		  Names.add(newname);
		  Log.info("Setting variable name="+newname+" value="+newitem);
			
		}
		
		
	}
	
	public void AddItem(String newitem, String newname){
		Items.add(newitem);
		Names.add(newname);
	}
	public void RemoveItem(String removethisitem){
		//find location
		int indextoremove = getItemIndex(removethisitem);
		//if present
		if (indextoremove>-1){
		Items.remove(indextoremove);
		Names.remove(indextoremove);
		}
	}

	private int getItemIndex(String removethisitem) {
		int i=0;
		int indextoremove = -1;
		for (Iterator<String>it = Names.iterator(); it.hasNext(); ) {
			  String currentItem = it.next(); 
			// Log.info("testing against;"+currentItem+"|"+removethisitem);			  
			  if (currentItem.compareTo(removethisitem)==0){
				  Log.info("match found "+i);
				  indextoremove=i;
			  };
			  
			  i=i+1;
			
		}
		return indextoremove;
	}
	
	/** returns all the names in a string array */
	public ArrayList<String> getAllUniqueNames(){
		
		//loop adding unique names to list;		
		final  ArrayList<String> uniquenames = new ArrayList<String>();
		

		for (Iterator<String>it = Names.iterator(); it.hasNext(); ) {
			
			String currentItem = it.next(); 
			  
			  //test if not in uniquenames
			  
			  boolean present=false;
		//	  System.out.print( "\n -- array size :"+uniquenames.size());
			  
			  for (Iterator<String>uniquenamesit = uniquenames.iterator(); uniquenamesit.hasNext(); ) {
				  String checkthis = uniquenamesit.next();
					//System.out.print( "\n inner loop:"+checkthis);
					
					if (checkthis.equals(currentItem)){
						present=true;
					}
					
					
			  }
			
		     	if (!present){
			  uniquenames.add(currentItem);
				}
		}
		
		
		
		
		return uniquenames;
		
	}
	
	/** tests all the items assosated with the specified name for a match */
	public boolean TestForMatch(String ItemName,String TestAgainstThis){
		boolean match =false;
		
		//find location
		int i=0;
	//	int itemindex = -1;
		for (Iterator<String>it = Names.iterator(); it.hasNext(); ) {
			  String currentItem = it.next(); 
			  if (currentItem.compareTo(ItemName)==0){
				  //we now test if the value matchs
				//   itemindex=i;
				   String testthis = Items.get(i);
				   if (testthis.equals(TestAgainstThis)){
					   match=true;
				   }
				   
			  };
			  i=i+1;
			
		}
		
		
		return match;
	}
	
	/** gets all items of this name **/
	public ArrayList<String> GetAllItems(String ItemName){
		
		final ArrayList<String> ItemsToReturn = new ArrayList<String>();
		
		//find location
		int i=0;
		for (Iterator<String>it = Names.iterator(); it.hasNext(); ) {
			  String currentItem = it.next(); 
			  if (currentItem.compareTo(ItemName)==0){
				  ItemsToReturn.add(Items.get(i));
				  
				  
			  };
			  i=i+1;
			
			  
		}
		
		
		return ItemsToReturn;
	}
	
	/** gets the last item of this name **/	
	public String GetItem(String ItemName){
		String Item = "";
		int itemindex = getItemIndex(ItemName);
		Log.info("itemindex="+itemindex);
		//if present
		if (itemindex>-1){
			Item = Items.get(itemindex);
		} else {
			Item = "";
		}
			
		
		return Item;
	}
	
}
