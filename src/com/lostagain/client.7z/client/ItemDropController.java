/*
 * Copyright 2008 Fred Sauer
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.darkflame.client;

import com.google.gwt.user.client.ui.Widget;
import com.allen_sauer.gwt.dnd.client.DragContext;
import com.allen_sauer.gwt.dnd.client.VetoDragException;
import com.allen_sauer.gwt.dnd.client.drop.SimpleDropController;
import com.allen_sauer.gwt.log.client.Log;
/**
 * Sample SimpleDropController which discards draggable widgets which are
 * dropped on it.
 */
final class ItemDropController extends SimpleDropController {

  private static final String CSS_DEMO_BIN_DRAGGABLE_ENGAGE = "demo-bin-draggable-engage";

  private Widget test;
  public String itemName;
  
 
  public ItemDropController(Widget test){	

  //public ItemDropController(InventoryIcon dropTarget){	
	  super(test);

	  
	    this.test = test;
	    System.out.print("test");
	    itemName = ((InventoryIcon)(test)).Name;
	    //itemName = test.Name;

  }
  @Override
  public void onDrop(DragContext context) {
	  

	  
   // System.out.print("\n test drop recieved:"+test.getUrl()+" with ");
    InventoryPanel ip = (InventoryPanel)(this.getDropTarget().getParent().getParent().getParent());
  
    ip.targetPanel.add(context.draggable,ip.NextFreeSlotX(),ip.NextFreeSlotY());
    
   // Window.alert("placed"+ip.NextFreeSlotX()+" "+ip.NextFreeSlotY());
    
    
    
    super.onDrop(context);
   // ip.dragController.unregisterDropController(context.dropController);
    //ip.dragController.unregisterDropController(this);
    
    System.out.print("\n is attached? = "+this.test.isAttached());
    
    // Item Mix trigger
        
    InventoryIcon Item1  = (InventoryIcon)(context.draggable);
    InventoryIcon Item2  = (InventoryIcon)this.getDropTarget();
    
    
 //   MyApplication.DebugWindow.addText("\n name = "+ Item1.Name + " and " + Item2.Name);

    
    //Get the types;
    String Item1Type = ((isPopUpType)(Item1.PopUp)).POPUPTYPE();
    String Item2Type = ((isPopUpType)(Item2.PopUp)).POPUPTYPE();
	
  //  MyApplication.DebugWindow.addText("\n type = "+ Item1Type + " and " + Item2Type);

    //the isItem check isnt working.
    
   // MyApplication.DebugWindow.addText("\n mag = "+ ((isItem)(Item1.PopUp)).MAGNIFYABLE() + " and " + ((isItem)(Item2.PopUp)).MAGNIFYABLE());
   // MyApplication.DebugWindow.addText("\n blah");
    
    String newline = "\r\n";
    Log.info("\n name = "+ Item1.Name + " and " + Item2.Name);
    //We now look for a match in the item script (if either X+B or B+X exist in the script, then we move on)
    String itemMixScriptL = MyApplication.itemmixscript.toLowerCase();
    int AnswerIndex = Math.max( (itemMixScriptL.indexOf(" "+Item1.Name.toLowerCase()+"+"+Item2.Name.toLowerCase()+newline)),(itemMixScriptL.indexOf(" "+Item2.Name.toLowerCase()+"+"+Item1.Name.toLowerCase()+newline))  ) ;
	
    // check one combination exists
    if  (AnswerIndex>-1){    	

        Log.info("match found");
    	//isolate commands to process
    	//from
    	int from = AnswerIndex+Item1.Name.length()+Item2.Name.length()+1;
    	int to  = MyApplication.itemmixscript.toLowerCase().indexOf("mix",from);
    	  System.out.print(" \n from: \n"+from+" to "+to);
    	String instructionset = MyApplication.itemmixscript.substring(from, to).trim()+"\n";	
    	System.out.print(" \n processing: \n"+instructionset);    	  
    	MyApplication.processInstructions(instructionset,"ItemMix:"+Item2.Name+"+"+Item1.Name+"| |ItemMix:"+Item1.Name+"+"+Item2.Name);
    	
    }
    
                
    //ie. if one is a mag and the other is magnifable, we can display it magnified!
    
   if (((((isItem)(Item2.PopUp)).MAGNIFYABLE()) && (Item2Type.compareTo("MAGNIFYINGGLASS")==0))
      || ((Item1Type.compareTo("MAGNIFYINGGLASS")==0) && ((isItem)(Item2.PopUp)).MAGNIFYABLE())) {
    	
	   Log.info("magnafying");
	   //get the item to open;
	   String iURL = "";
	   imagezoomPopUp mag = null;
	   PopUpWithShadow ItemWithShadow = null;
	   
	   //if one is an image;
	   if ((Item1Type.compareTo("PICTURE")==0)){
		    iURL = ((imagePopUp)(Item1.PopUp)).Imagelocation;
		    int sizex = ((imagePopUp)(Item2.PopUp)).rsizeX;
			int sizey = ((imagePopUp)(Item2.PopUp)).rsizeY;		   
			String itemname = ((imagePopUp)(Item1.PopUp)).Imagelocation;
			  itemname = itemname.substring( itemname.lastIndexOf("/")+1 );
		    if ( Item2.popedup == false){
		    	mag = new imagezoomPopUp(iURL,((imagePopUp)(Item1.PopUp)).ImageDiscription,sizex,sizey);
			ItemWithShadow =  new PopUpWithShadow(Item2,"30%","25%",LoadGamesText.Magnify_Magnify,mag);
		    Item2.popedup = true;
		    }
	   } else if((Item2Type.compareTo("PICTURE")==0)) {
		   iURL = ((imagePopUp)(Item2.PopUp)).Imagelocation;
		   //get size
		   int sizex = ((imagePopUp)(Item2.PopUp)).rsizeX;
		   int sizey = ((imagePopUp)(Item2.PopUp)).rsizeY;		   
		   String itemname = ((imagePopUp)(Item2.PopUp)).Imagelocation;
		   itemname = itemname.substring( itemname.lastIndexOf("/")+1 );
		   if ( Item1.popedup == false){
			   
			   mag = new imagezoomPopUp(iURL,((imagePopUp)(Item2.PopUp)).ImageDiscription,sizex,sizey);
		   ItemWithShadow =  new PopUpWithShadow(Item1,"30%","25%",LoadGamesText.Magnify_Magnify,mag);			
		   Item1.popedup = true;
		   }
	   } else if(((isItem)(Item2.PopUp)).MAGNIFYABLE()) {
		   MyApplication.DebugWindow.addText("loading mag item2..."+iURL);
			  
	   //if not then we must get the url from the items name;
		   iURL = ((isItem)(Item2.PopUp)).SourceURL();
		   //change to image location
		   iURL = iURL.substring(0, iURL.length()-4)+".jpg";
		   
		   //get size
		   int sizex = Integer.parseInt(((isItem)(Item2.PopUp)).sourcesizeX());
		   int sizey =  Integer.parseInt(((isItem)(Item2.PopUp)).sourcesizeY());
		   

		   
		   String itemname = ((isItem)(Item2.PopUp)).SourceURL();
		   itemname = itemname.substring( itemname.lastIndexOf("/")+1 );

		   
		   if ( Item1.popedup == false){

			   mag = new imagezoomPopUp(iURL,"",sizex,sizey);
			 
		   ItemWithShadow =  new PopUpWithShadow(Item1,"30%","25%",LoadGamesText.Magnify_Magnify+itemname,mag);
		  
		   Item1.popedup = true;
		   }
		   
		   
		   
	   }else if(((isItem)(Item1.PopUp)).MAGNIFYABLE()) {
			  
		   //if not then we must get the url from the items name;
			   iURL = ((isItem)(Item1.PopUp)).SourceURL();
			   //change to image location
			   iURL = iURL.substring(0, iURL.length()-4)+".jpg";
			   
			   //get size
			   int sizex = Integer.parseInt(((isItem)(Item1.PopUp)).sourcesizeX());
			   int sizey =  Integer.parseInt(((isItem)(Item1.PopUp)).sourcesizeY());
			   
			   
			   String itemname = ((isItem)(Item2.PopUp)).SourceURL();
			   itemname = itemname.substring( itemname.lastIndexOf("/")+1 );
			   if ( Item2.popedup == false){
				   
				   mag = new imagezoomPopUp(iURL,"",sizex,sizey);
			   ItemWithShadow =  new PopUpWithShadow(Item2,"30%","25%",LoadGamesText.Magnify_Magnify+itemname,mag);			
			   Item2.popedup = true;
			   }
			   
			   
			   
		   }
		ItemWithShadow.OpenDefault();
		
		  
	   
    }
    
   
    
    
  }

  @Override
  public void onEnter(DragContext context) {

    super.onEnter(context);    
    for (Widget widget : context.selectedWidgets) {
      widget.addStyleName(CSS_DEMO_BIN_DRAGGABLE_ENGAGE);
    }
  }

  @Override
  public void onLeave(DragContext context) {	

    for (Widget widget : context.selectedWidgets) {
      widget.removeStyleName(CSS_DEMO_BIN_DRAGGABLE_ENGAGE);
    }
    super.onLeave(context);
  }

  @Override
  public void onPreviewDrop(DragContext context) throws VetoDragException {

    super.onPreviewDrop(context);    
   
  }
  
}
