package com.darkflame.client;

import java.util.ArrayList;

import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.StackPanel;

public class Notebook extends AbsolutePanel implements hasCloseDefault, hasOpenDefault,isPopUpType {

	//background image
	HTML notebookpage = new HTML();
	
	//main stack panel
	StackPanel ProfilePages = new StackPanel();
	
	//array we keep of profiles in list
	final static ArrayList<String> ProfilePagesLoaded = new ArrayList<String>();

	
	  public void CloseDefault(){		
		  MyApplication.NotepadOpen = false;
		  MyApplication.NotepadButton.setAnimateClose();
		  
		  //remove fade
		 // RootPanel.get().remove(MyApplication.fadeback);
		  //update icons;  
		  //RootPanel.get().remove(this);
		 
		  
		  
	  }
	
	public Notebook(){
		//make topbar
		//  topBar NewTopBar = new topBar("Notebook",this);	  	
		  
		  //add title
		//  this.add(NewTopBar,0,0);
		 // NewTopBar.setWidth("100%");
		//this.add(notebookBackground, 0, 30);
		  setStylePrimaryName("notepadback");
		  //ProfilePages.setStylePrimaryName("DefaultTopBar");
		  
		  this.setWidth( (Window.getClientWidth()/2)+"px");
		  this.setHeight( (Window.getClientHeight()*0.7)+"px");
		  
		  //add html back
		  
			ScrollPanel MainContainer = new ScrollPanel();
			MainContainer.setHeight( (Window.getClientHeight()*0.69)+"px");
			MainContainer.setWidth("100%");
			MainContainer.add(ProfilePages);
		  this.add(MainContainer,0,5);
		  
		  
		  //this.add(new Label("Charecter Profils"),0,5);
		  ProfilePages.setWidth("100%");
		  
		  
		  //add first page
		  //ProfilePages.add(notebookpage, "Charecter Profiles"); 
		  
		 
	}

	public void AddPage(final String PageName, final String PageTitle){
			
		     
	    
	  //  RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.POST,
			//	MyApplication.textfetcher_url);
		
	RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.GET,
				 MyApplication.notebookpages_url+PageName);	
				 requestBuilder.setHeader("Content-Type", "text/plain;charset=utf-8");
				try {
				      requestBuilder.sendRequest("FileURL=" + MyApplication.notebookpages_url, new RequestCallback() {
				        public void onError(Request request, Throwable exception) {
				        	System.out.println("http failed");
				        }

				        public void onResponseReceived(Request request, Response response) {
				        	
				        	
				        	MyApplication.DebugWindow.setTitle(response.getHeadersAsString());
				        	
				        	String newPage = response.getText();
				        	
				        	int headerLoc = newPage.toLowerCase().indexOf("</head>");
				        	//crop the header if its there
				        	
				        	newPage = newPage.substring(headerLoc+7);
				        	
				        	//ScrollPanel PageContainer = new ScrollPanel();
				    		HTML newnotebookpage = new HTML(newPage);
				    		
				    		newnotebookpage.setHeight("100%");
				    		//PageContainer.setHeight((Window.getClientHeight()*0.5)+"px");
				    		
				    		//PageContainer.add(newnotebookpage);
				    	    ProfilePages.add(newnotebookpage,PageTitle); 	
				    	  //PageContainer.setHeight( "100%");
				    	   // newnotebookpage.setStyleName("overflowscroll");
				    	  //  Style notebookstyle = newnotebookpage.getElement().getStyle();
				    	    //notebookstyle.setProperty("overflow", "scroll");
				    	    
				    	    ProfilePagesLoaded.add(PageName);
				        }
				      });
				    } catch (RequestException ex) {
				    	System.out.println("can not connect to game controll file");
				    }
	    
	}
	
	
	
	public void ShowDefault(){
		
		this.setSize("55%", "70%");

		//screen size
		int ScreenSizeX = Window.getClientWidth();
		int ScreenSizeY = Window.getClientHeight();
		
		 
		// app size
		int NootbookSizeX = (int)Math.round(Window.getClientWidth()*0.5);
		int NootbookSizeY = (int)Math.round(Window.getClientHeight()*0.7);
		
		  int posX = ScreenSizeX/2 - NootbookSizeX/2;
		  int posY = ScreenSizeY/2 - NootbookSizeY/2;
		
		 
		RootPanel.get().add(this,posX, posY);
	}

	public void OpenDefault() {
		// TODO Auto-generated method stub
		
	}

	public boolean DRAGABLE() {
		// TODO Auto-generated method stub
		return true;
	}

	public boolean POPUPONCLICK() {
		// TODO Auto-generated method stub
		return false;
	}

	public String POPUPTYPE() {
		// TODO Auto-generated method stub
		return null;
	}

	public void RecheckSize() {
		// TODO Auto-generated method stub
		
	}
	public boolean MAGNIFYABLE() {
		// TODO Auto-generated method stub
		return false;
	}
	
}
