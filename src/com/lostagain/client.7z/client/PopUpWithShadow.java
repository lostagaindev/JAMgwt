package com.darkflame.client;

import java.util.Iterator;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.event.dom.client.MouseMoveEvent;
import com.google.gwt.event.dom.client.MouseMoveHandler;
import com.google.gwt.event.dom.client.MouseOutEvent;
import com.google.gwt.event.dom.client.MouseOutHandler;
import com.google.gwt.event.dom.client.MouseOverEvent;
import com.google.gwt.event.dom.client.MouseOverHandler;
import com.google.gwt.event.dom.client.MouseUpEvent;
import com.google.gwt.event.dom.client.MouseUpHandler;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.MouseListener;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class PopUpWithShadow extends PopupPanel implements MouseListener,MouseUpHandler,MouseMoveHandler,MouseDownHandler, isPopUpType, hasCloseDefault,hasOpenDefault {

	VerticalPanel verticalSplit = new VerticalPanel();

	Grid Container = new Grid(3,3);
	
	//set at this zindex flag
	public boolean fixed_zindex = false;
	public int fixed_zindex_value = 5000;
	

	public Label caption = new Label("PopUp (Drag Me)");
	private boolean dragging;
	private int dragStartX, dragStartY;

	String sizeX = "200px";
	String sizeY = "100px";
	Widget Contents = new Label("");
	
	// pretty colour base
	HTML overlay = new HTML("<div></div>");
	
	//topbar bits
	 HorizontalPanel TopBar = new HorizontalPanel();
	 
	 InterfaceIcon closeX = new InterfaceIcon("GameIcons/cc2xbutton0.jpg",3);
		
	 //source icon of popup
	 Widget SourceIcon = new Widget();
	 

	public PopUpWithShadow(Widget IconTrigger,String X,String Y,
			String title,Widget SetContents) {

		Contents=SetContents;
		
		SourceIcon = IconTrigger;
		
		sizeX = X;
		sizeY = Y;
		 
		this.setSize(Contents.getOffsetWidth()+16+"px", sizeY);
	
		DOM.setStyleAttribute(this.getElement(), "zIndex", "1050");
		
		this.setAnimationEnabled(true);
		
		
		//this needs its own topbar set up
		caption.setText(title);
		TopBar.add(caption);
		TopBar.add(closeX);
		closeX.setSize("21px", "19px");
		TopBar.setCellHorizontalAlignment(closeX,HasHorizontalAlignment.ALIGN_CENTER);
		TopBar.setStylePrimaryName("DefaultTopBar");
		TopBar.setWidth("100%");
		TopBar.setHeight("21px");
		TopBar.add(caption);
		TopBar.setCellWidth(caption, "95%");
		TopBar.add(closeX);
		TopBar.setCellHorizontalAlignment(caption, HasHorizontalAlignment.ALIGN_CENTER);
		TopBar.setCellHorizontalAlignment(closeX, HasHorizontalAlignment.ALIGN_RIGHT);
		
		//pass this to the close
		final Widget thisone = this;
		closeX.addMouseOverHandler(new MouseOverHandler(){
			public void onMouseOver(MouseOverEvent event) {
				  closeX.setAnimateOpen();
			}
			
		});
		closeX.addMouseOutHandler(new MouseOutHandler(){
			public void onMouseOut(MouseOutEvent event) {
				  closeX.setAnimateClose();
			}
			
		});
		/*
		closeX.addMouseListener(new MouseListener() {
		      public void onMouseDown(Widget sender,int mx,int my) {
		    	  
		    	  
		      }
		      public void onMouseUp(Widget sender,int mx,int my) {
		    	   
		      }
		      public void onMouseEnter(Widget sender) {
		    
		      }
		      public void onMouseMove(Widget sender,int mx,int my) {
		    	   
		      }
		      public void onMouseLeave(Widget sender)
		      {
		    	
		    	  
		      }
		    });
		    */
		closeX.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				
				Widget Sender = (Widget)event.getSource();
				 //InventoryPanel parent = (InventoryPanel)(Sender.getParent().getParent());
				 //parent.CloseDefault();
				 
				 //if the parent is the inventory panel, then we run its close function
				 System.out.print(Sender.getParent().getParent().getClass().getName());
				 String temp = Sender.getParent().getParent().getClass().getName();	
				
				 System.out.println(temp);				 
				
				((hasCloseDefault)thisone).CloseDefault();
				         			 
				RootPanel.get().remove(MyApplication.fadeback);
				
				 
			 }
		  });
		
		
		// this.setText("- Drag Me -");
		//verticalSplit.add(TopBar);
		//this.add(verticalSplit);
		//overlay.setSize("400px", "400px");
		//overlay.setStyleName("overlay");
		//verticalSplit.add(IContents);

	//	DOM.appendChild(this.getElement(), caption.getElement());
		//adopt(caption);
		//caption.setStyleName("Caption");
		
		
		//set to dragable if draggable unless not dragable
		
		if (((isPopUpType)Contents).DRAGABLE()){
		caption.addMouseMoveHandler(this);
		caption.addMouseUpHandler(this);
		caption.addMouseDownHandler(this);
		
		}
		//set to Z ordering to high, as this should be ontop of everything!
	//	this.getElement().setAttribute("STYLE", "z-index: 100");
		
		
		//set up shadows
		//set border shadows for title
		Container.setCellPadding(0);
		Container.setCellSpacing(0);
		Container.getCellFormatter().setStyleName(0, 0, "ShadowTopLeft pngfix");
		
		Container.getCellFormatter().setWidth(0, 0, "8px");
		Container.getCellFormatter().setHeight(0, 0, "21px");
		
		Container.setWidget(0, 1, TopBar);

		Container.getCellFormatter().setVerticalAlignment(0, 1, HasVerticalAlignment.ALIGN_MIDDLE);
		
		Container.getCellFormatter().setHorizontalAlignment(0, 1, HasHorizontalAlignment.ALIGN_CENTER);
		Container.getCellFormatter().setStyleName(0, 1, "DefaultTopBar");
		Container.getCellFormatter().setHeight(0, 1, "21px");
		Container.getCellFormatter().setStyleName(0, 2, "DefaultTopBar");
		Container.getCellFormatter().setHeight(0, 2, "21px");
				
		Container.getCellFormatter().setWidth(1, 0, "8px");
		Container.getCellFormatter().setStyleName(1, 0, "ShadowLeft pngfix");
		
		// load contents into HTML
		Container.setWidget(1, 1, Contents);
		System.out.println("co");

		Container.getCellFormatter().setStyleName(1, 1, "Backstyle");
		//Container.getCellFormatter().setStyleName(1, 1, "popup_border");
		
		if (!(Contents.getStylePrimaryName() == null))
				{		Container.getCellFormatter().setStyleName(1, 2, Contents.getStylePrimaryName());
				}
		
		Container.getCellFormatter().setWidth(2, 0, "8px");
		Container.getCellFormatter().setHeight(2, 0, "8px");
		Container.getCellFormatter().setStyleName(2, 0, "ShadowCorner pngfix");
		

		Container.getCellFormatter().setHeight(2, 1, "8px");
		Container.getCellFormatter().setStyleName(2, 1, "ShadowLower pngfix");
		
		Container.getCellFormatter().setWidth(2, 2, "16px");
		Container.getCellFormatter().setHeight(2, 2, "8px");
		Container.getCellFormatter().setStyleName(2, 2, "ShadowBottomRight pngfix");
		
		this.setWidget(Container);

	}
	

	@Override
	public boolean onEventPreview(Event event) {
		// We need to preventDefault() on mouseDown events (outside of the
		// DialogBox content) to keep text from being selected when it
		// is dragged.
		if (DOM.eventGetType(event) == Event.ONMOUSEDOWN) {
			if (DOM.isOrHasChild(caption.getElement(), DOM
					.eventGetTarget(event))) {
				DOM.eventPreventDefault(event);
			}
		}

		return super.onEventPreview(event);
	}

	public void onMouseDown(Widget sender, int x, int y) {
		
	}

	public void onMouseEnter(Widget sender) {
	}

	public void onMouseLeave(Widget sender) {
	}

	public void onMouseMove(Widget sender, int x, int y) {
		
	}

	public void onMouseUp(Widget sender, int x, int y) {
		
	}

	public String POPUPTYPE() {
		return ((isPopUpType)Contents).POPUPTYPE();
	}
	public boolean POPUPONCLICK() {
		return true;
	}
	public void RecheckSize() {
		
		//remove background, this popup specticaly dosnt use it
		 RootPanel.get().remove(MyApplication.fadeback);
		 
		 //remove shadow frame, as it dosnt use that either
		 RootPanel.get().remove(this.getParent());
		 
		 
		 //we can asign this now as being attached
	//	 MyApplication.overlayPopUpsOpen.add(this);
		 
		 
		 this.center();
	}

	public void CloseDefault() {
		MyApplication.overlayPopUpsOpen.remove(this);
		  //RootPanel.get().remove(this);
		if (!(SourceIcon==null)){
		((isInventoryIcon)SourceIcon).setPopedUp(false);
		}
		
		if (!(Contents==null)){
		((hasCloseDefault)(Contents)).CloseDefault();		
		}
		
	    this.hide();
	    
	  //always open this when a panel is opened;
		//if nothing else is open close the box
	  //  if (MyApplication.overlayPopUpsOpen.size()<1){
	//    MyApplication.closeallwindows.setAnimateClose();
	//    }
		//-
	  //if nothing else is open close the box
	    if (MyApplication.overlayPopUpsOpen.size()<1){
	    	if (MyApplication.ClueReveal.isOpen()==false){
	    	//	Window.alert("closeing window close");
	    		 MyApplication.closeallwindows.setAnimateClose();
	    	}
	    }
		//-
	    
	    
	}
	public void fixedZdepth (int setdepth)
	{
		fixed_zindex = true;
		fixed_zindex_value = setdepth;
		
		DOM.setStyleAttribute(this.getElement(), "z-index", ""+(fixed_zindex_value));
		DOM.setStyleAttribute(this.getElement(), "zIndex", ""+(fixed_zindex_value));
		
		
	}
	public void OpenDefault() {
		
		   MyApplication.DebugWindow.addText("opening popup");
		   
		int z=0;
		String tempz = " zdepth=first pop";
		MyApplication.z_depth_max=1000;
		//first we check over all the current open popups and their z-depth;
		Iterator<PopUpWithShadow> popupIter = MyApplication.overlayPopUpsOpen.iterator();
		MyApplication.Feedback.setTitle("a");
		if (MyApplication.overlayPopUpsOpen.size()>0){
			while ( popupIter.hasNext() )
			{
				PopUpWithShadow cur = popupIter.next();
				MyApplication.Feedback.setTitle("b");
				//z =  Integer.parseInt(cur.getElement().getStyle().getProperty("z-index"));
				if (cur.getElement().getStyle().getProperty("z-index")==null){
					//z =  Integer.parseInt(cur.getElement().getStyle().getProperty("zIndex"));
				} else {
					z =  Integer.parseInt(cur.getElement().getStyle().getProperty("z-index"));
				}
				
				MyApplication.Feedback.setTitle("cz="+z);
				
				if (z>MyApplication.z_depth_max) {
					MyApplication.z_depth_max=z;
				}
				tempz = tempz +"\n z depth = "+z;
				
			}
	//	MyApplication.Feedback.setTitle("a max depth set to "+MyApplication.z_depth_max);

	//	} 
		//MyApplication.Feedback.setText("=-=");
	//	if ((Integer.parseInt(MyApplication.fadeback.getElement().getStyle().getProperty("z-index")))>MyApplication.z_depth_max)
	//	{
	//		MyApplication.Feedback.setText("b");
		//	MyApplication.z_depth_max=Integer.parseInt(MyApplication.fadeback.getElement().getStyle().getProperty("z-index"));
//
	//		MyApplication.Feedback.setText("b max depth set to "+MyApplication.z_depth_max);
		
			
		} else {
			//we can reset the max
			MyApplication.z_depth_max=1000;
		//	MyApplication.Feedback.setText("c max depth set to "+MyApplication.z_depth_max);
			
		}
		
		
		//if the backfader is in front for some reason, we use thats zdepth instead
		
		this.center();
		((hasOpenDefault)this.Contents).OpenDefault();		
		
		//detect if its outside the top edge of the screen, and if so, align to the top.
		
		int this_x = this.getAbsoluteLeft();
		int this_height = this.getOffsetHeight();
		if (this_height>Window.getClientHeight()){
			this.setPopupPosition(this_x, 0);
		};
		
		
		
		
		
		//set this ones zdepth to max+2 (plus1 might be reserved for the fader)
		DOM.setStyleAttribute(this.getElement(), "z-index", ""+(MyApplication.z_depth_max+1));
		DOM.setStyleAttribute(this.getElement(), "zIndex", ""+(MyApplication.z_depth_max+1));
		MyApplication.z_depth_max=MyApplication.z_depth_max+1;
		
		
		  MyApplication.overlayPopUpsOpen.add(this);
		  
	}


	public boolean DRAGABLE() {
		return false;
	}
	public boolean MAGNIFYABLE() {
		return false;
	}


	public void onMouseDown(MouseDownEvent event) {
		
		int x = event.getX();
		int y = event.getY();
				
		dragging = true;
		DOM.setCapture(caption.getElement());
		dragStartX = x;
		dragStartY = y;
		
		//set to top
		//set this ones zdepth to max+1

        if (fixed_zindex == false){        
        DOM.setStyleAttribute(this.getElement(), "z-index", ""+(MyApplication.z_depth_max+1));
		DOM.setStyleAttribute(this.getElement(), "zIndex", ""+(MyApplication.z_depth_max+1));
		MyApplication.Feedback.setTitle("set too"+DOM.getStyleAttribute(this.getElement(),  "z-index"));
		
		MyApplication.z_depth_max=MyApplication.z_depth_max+1;
        }
		//DOM.setStyleAttribute(this.getElement(), "Zindex", ""+(MyApplication.z_depth_max+1));
		
	}


	public void onMouseMove(MouseMoveEvent event) {
		
		int x=event.getX();
		int y=event.getY();
		
		
		
		if (dragging) {
			int absX = x + getAbsoluteLeft();
			int absY = y + getAbsoluteTop();
			
			if ((absY - dragStartY)<0){
				setPopupPosition(absX - dragStartX,0);
			} else 
			{
			setPopupPosition(absX - dragStartX, absY - dragStartY);
			}
		}
	}


	public void onMouseUp(MouseUpEvent event) {
		dragging = false;
		DOM.releaseCapture(caption.getElement());
	}
}
