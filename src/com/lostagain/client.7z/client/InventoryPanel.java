package com.darkflame.client;

import java.util.ArrayList;

import com.google.gwt.core.client.GWT;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;
import java.util.Iterator;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.Window;
import com.allen_sauer.gwt.dnd.client.DragEndEvent;
import com.allen_sauer.gwt.dnd.client.DragStartEvent;
import com.allen_sauer.gwt.dnd.client.PickupDragController;
import com.allen_sauer.gwt.dnd.client.VetoDragException;
import com.allen_sauer.gwt.dnd.client.drop.GridConstrainedDropController;

import com.allen_sauer.gwt.dnd.client.DragHandler;

import com.allen_sauer.gwt.log.client.Log;

public class InventoryPanel extends VerticalPanel implements hasCloseDefault,
		hasOpenDefault,isPopUpType {

	// item locations
	static final String inventory_url = GWT.getHostPageBaseURL()+"InventoryItems/";

	// item array
	final static ArrayList<ItemDropController> itemList = new ArrayList<ItemDropController>();
	// placement list
	final static boolean itemSpace[] = new boolean[100];

	String Title = new String("Inventory");
	// HorizontalPanel TopBar = new HorizontalPanel();
	// Label closeX = new Label("X");
	Label titleLabel = new Label(Title);
	AbsolutePanel MainInventoryBox = new AbsolutePanel();

	// last position picked up from
	int old_LinerPos = 0;
	
	int old_left =0;
	int old_top = 0;
	
	// last position dropped to
	int LinerPos = 0;

	// screen size
	int ScreenSizeX = Window.getClientWidth();
	int ScreenSizeY = Window.getClientHeight();
	// app size
	int InventorySizeX = (100 * (Window.getClientWidth() / 150));
	int InventorySizeY = (100 * (Window.getClientHeight() / 175));

	int roundTo = 100;
	int RInventorySizeX = (int) ((InventorySizeX + (0.5 * roundTo)) / roundTo)
			* roundTo;
	int RInventorySizeY = 20
			+ (int) ((InventorySizeY + (0.5 * roundTo)) / roundTo) * roundTo;

	// drag controller
	PickupDragController dragController = new PickupDragController(
			MainInventoryBox, true);
	// Create a drop target on which we can drop labels
	AbsolutePanel targetPanel = new AbsolutePanel();
	// DropController dropController = new
	// AbsolutePositionDropController(targetPanel);

	GridConstrainedDropController dropController = new GridConstrainedDropController(
			targetPanel, 100, 100);

	static Boolean isDragging = false;
	static Boolean cancelClick = false; //while dragging this makes sure no clicks are counted
	
	Boolean reorder = true;
	
	public InventoryPanel() {
		// make topbar
		// topBar NewTopBar = new topBar("Inventory",this);
		
		// add title
		// add(NewTopBar);
		// default size
		setSize(RInventorySizeX + "px", RInventorySizeY + "px");
		// set default style
		setStyleName("inventory");

		// add main box
		add(MainInventoryBox);
		MainInventoryBox.setSize(RInventorySizeX + "px", (RInventorySizeY - 20)
				+ "px");

		// drag set up
		// Positioner is always constrained to the boundary panel
		// Use 'true' to also constrain the draggable or drag proxy to the
		// boundary panel
		// create a DropController for each drop target on which draggable
		// widgets
		// can be dropped

		// Don't forget to register each DropController with a DragController
		dragController.registerDropController(dropController);
		dragController.setBehaviorDragStartSensitivity(3);
		MainInventoryBox.add(targetPanel, 1, 1);
		targetPanel.setSize("100%", "100%");
		dragController.setBehaviorConstrainedToBoundaryPanel(true);
		dragController.setBehaviorMultipleSelection(false);
		
		dragController.addDragHandler(new DragHandler() {
			public void onDragEnd(DragEndEvent event) {
				
				
				// (ItemDropController)(event.getSource());
				Widget Source = (Widget) (event.getSource());
				System.out.println(" \n drag end" + Source);

				// Now we retrieve the style in the Dom where it says LEFT:
				// ###px; and TOP ###px
				int Left = Source.getElement().getOffsetLeft();
				int Top = Source.getElement().getOffsetTop();
				int LeftLimit = dragController.getBoundaryPanel()
						.getOffsetWidth();
				
				LinerPos = (((Top / 100) * LeftLimit) + Left) / 100;

				itemSpace[old_LinerPos] = false;
				itemSpace[LinerPos] = true;

				// we set the old one to false
				
				
				MyApplication.DebugWindow.addText("-drag end-");
			//	Window.alert("set "+LinerPos+" to true. Set "+old_LinerPos+" to false");
				
				/**
				// get current pos? :?
				// ItemDropController Source =
				

				// work out the liner slot position and set it to true if its empty.
				
				LinerPos = (((Top / 100) * LeftLimit) + Left) / 100;
				
				// seems to alternative between being detected and not.
				//Is it effecting the landing region when it shouldnt?
						
				
				if (itemSpace[LinerPos]==false){
					

					Window.alert("-no item under it at "+LinerPos+"-");
					
				itemSpace[LinerPos] = true;

				// we set the old one to false
				itemSpace[old_LinerPos] = false;
				
				System.out.println(" from " + old_LinerPos + "  to " + LinerPos
						+ " ");
				} else {

					Window.alert("-item under it so we have to move it elsewhere:"+LinerPos+"-");					
					//we put it in the next free slot
					//find slot
					
					/**
					//Debuging stuff
					
					//Print complete itemspace
					int i=0;
					while (i<itemSpace.length){
						i++;
						MyApplication.DebugWindow.addText("-"+itemSpace[i]+"-");
					}
					
					
					// work out next gap in itemlist.

					
					int pos = 0;
					
					while (itemSpace[pos] == true) {
						pos = pos + 1;
					}
					Window.alert(pos+" is "+itemSpace[pos]);
						
					
					int NextPosX = ((itemList.size()) * 100) % RInventorySizeX;
					int NextPosY = 100 * ((((itemList.size()) * 100) - NextPosX) / RInventorySizeX);

					int LeftLimit2 = dragController.getBoundaryPanel()
							.getOffsetWidth();

					// work out the liner slot position and set it to true.
					LinerPos = (((NextPosY / 100) * LeftLimit2) + NextPosX) / 100;
					
					itemSpace[LinerPos] = true;
					itemSpace[old_LinerPos] = false;
					//int NextPosX = ((pos) * 100) % RInventorySizeX;
					//int NextPosY = (((pos*100)-NextPosX)/RInventorySizeX);
					
					
					//int NextX = 
					//get old position
					//int OldLeft = (old_LinerPos*100) % RInventorySizeX;
					//int OldTop = 100 * (((old_LinerPos * 100) - OldLeft) / RInventorySizeX);
					
					Source.getElement().getStyle().setPropertyPx("left",NextPosX);
					Source.getElement().getStyle().setPropertyPx("top", NextPosY);
					
					Window.setTitle("icon put back to "+NextPosX+";"+NextPosY+"("+LinerPos+")");
					
					
				}
				
				**/
				//end of drag
				isDragging = false;
				//Window.setTitle("not dragging");
				
			}

			public void onDragStart(DragStartEvent event) {
				
				//Window.alert("drag start...");

				
				// TODO Auto-generated method stub
				isDragging = true;
				cancelClick = true;
				
				
				//temp indication of drag
				 // Window.alert("dragging_start");
				
				// store old co-ordinate liner flag.
				Widget Source = (Widget) (event.getSource());
				// Now we retrieve the style in the Dom where it says LEFT:
				// ###px; and TOP ###px
			//	int Left = Source.getElement().getOffsetLeft();
			//	int Top = Source.getElement().getOffsetTop();
				int LeftLimit = dragController.getBoundaryPanel()
						.getOffsetWidth();

				old_left =  Source.getElement().getOffsetLeft();
				old_top = Source.getElement().getOffsetTop();
				
				// work out the old liner slot position
				old_LinerPos = (((old_top / 100) * LeftLimit) + old_left) / 100;
				

			}

			public void onPreviewDragEnd(DragEndEvent event)
					throws VetoDragException {
				// TODO Auto-generated method stub
				
				
				//display order check
				/*
				String OrderCheck = "";
				int i =0;
				
				while (i<itemSpace.length){
					String status = "0";
					if (itemSpace[i]){
						status = "1";
					}
					OrderCheck = OrderCheck +"-"+status;
					i++;
				}
				*/
			//	Window.alert("order check:"+OrderCheck);
				
				//work out if it will be at the wrong position.
			
				
			}

			public void onPreviewDragStart(DragStartEvent event)
					throws VetoDragException {
				// TODO Auto-generated method stub
				// Window.alert("dragging_veto");
			}

		});

	}

	public void OpenDefault() {
		// has to also trigger when opened for the first time!
		
		
		// if the screen size has got smaller we flag that things must be
		// reordered.
		if (Math.abs((ScreenSizeX) - (Window.getClientWidth())) > 30) {
			reorder = true;
			//MyApplication.DebugWindow.addText("reorder needed "
			//		+ Math.abs((ScreenSizeX) - (Window.getClientWidth())));
		}

		ScreenSizeX = Window.getClientWidth();
		ScreenSizeY = Window.getClientHeight();
		// app size
		InventorySizeX = (100 * (Window.getClientWidth() / 150));
		
		//InventorySizeY = (100 * (Window.getClientHeight() / 150));
		//size based on number of items
		//InventorySizeX = (100 * (Window.getClientWidth() / 150));
		//number of items high
		int noih = 100+(Math.round(itemList.size() / (InventorySizeX/100)))*100;
		InventorySizeY = noih;
		//MyApplication.DebugWindow.addText("\n inventory size = "+noih);
		//InventorySizeY = (100 * (Window.getClientHeight() / 150));
		
		
		
		roundTo = 100;
		RInventorySizeX = (int) ((InventorySizeX + (0.5 * roundTo)) / roundTo)
				* roundTo;
		RInventorySizeY = 20
				+ (int) ((InventorySizeY + (0.5 * roundTo)) / roundTo)
				* roundTo;

	//	int posX = ScreenSizeX / 2 - RInventorySizeX / 2;
	//	int posY = ScreenSizeY / 2 - RInventorySizeY / 2;

		// default size
		setSize(RInventorySizeX + "px", RInventorySizeY + "px");
		MainInventoryBox.setSize(RInventorySizeX + "px", (RInventorySizeY - 20)
				+ "px");
		targetPanel.setSize("100%", "100%");
		//RootPanel.get().add(this, posX, posY);

		if (reorder == true) {
			int loop = 0;
			int PosX = 0;
			int PosY = 0;
			for (Iterator<ItemDropController> it = itemList.iterator(); it
					.hasNext();) {
				ItemDropController currentItem = it.next(); 
				
				
						
				// get position for loop

				PosX = (loop * 100) % RInventorySizeX;
				
				
				//PosY = (loop * 100) - PosX;
				
				PosY = ((int)Math.floor((loop * 100) / RInventorySizeX))*100;
				MyApplication.DebugWindow.addText("\n reordering "+PosY+" should not be more then"+RInventorySizeY);
				
				
				targetPanel.setWidgetPosition(currentItem.getDropTarget(),
						PosX, PosY);
				

				itemSpace[loop] = true;

				//MyApplication.DebugWindow.addText(loop + "=set too true ");
				
				loop = loop + 1;
				
				reorder = false;
				

			}

		}
		
		//display order check
		String OrderCheck = "";
		int i =0;
		
		while (i<itemSpace.length){
			String status = "0";
			if (itemSpace[i]){
				status = "1";
			}
			OrderCheck = OrderCheck +"-"+status;
			i++;
		}
		
		//Window.alert("order check:"+OrderCheck);

	}

	public void CloseDefault() {

		MyApplication.InventoryOpen = false;
		MyApplication.InventoryButton.setAnimateClose();

	}

	public int NextFreeSlotX() {

		// work out next gap in itemlist.
		int pos = 0;
		while (itemSpace[pos] == true) {
			pos = pos + 1;
		}
		if (pos>old_LinerPos){
			pos = old_LinerPos;
		}

		//Window.alert("next slot is "+pos);
		
		System.out.println("next free inventory slot..." + pos);

		int NextPosX = ((pos) * 100) % RInventorySizeX;
		return NextPosX;
	}

	public int NextFreeSlotY() {
		
		int pos = 0;
		while (itemSpace[pos] == true) {
			pos = pos + 1;
		}
		if (pos>old_LinerPos){
			pos = old_LinerPos;
		}
		
		//Window.alert("next slot is "+pos);
		
		
		int NextPosX = (((pos)) * 100) % RInventorySizeX;
		int NextPosY = 100 * ((((pos) * 100) - NextPosX) / RInventorySizeX);
		return NextPosY;
	}

	public void RemoveThisItem(ItemDropController Item) {
		Item.getDropTarget().removeFromParent();

		targetPanel.remove(Item.getDropTarget());
		dragController.unregisterDropController(Item);
		itemList.remove(Item);
	}

	public void ClearInventory(){
		int Top = 0;
		int Left = 0;
		Log.info("- removing all "+itemList.size()+" items");
		Iterator<ItemDropController> it = itemList.iterator();
		
		while (it.hasNext()) {

			ItemDropController currentItem = it.next(); // No downcasting
														// required.
			Log.info("-removing "+currentItem.itemName);
			
			
			// remove its position
			System.out.println("blah3");
			// Top = currentItem.getDropTarget().getElement().getOffsetTop();
			System.out.println("blah4");
			Left = currentItem.getDropTarget().getElement().getOffsetLeft();
			int LeftLimit = dragController.getBoundaryPanel().getOffsetWidth();

			
			// work out the liner slot position and set it to false.
			old_LinerPos = (((Top / 100) * LeftLimit) + Left) / 100;
			itemSpace[old_LinerPos] = false;

			// we delete it.
			currentItem.getDropTarget().removeFromParent();

			targetPanel.remove(currentItem.getDropTarget());
			dragController.unregisterDropController(currentItem);
			
		}
		itemList.clear();
	}
	
	public void RemoveItem(String ReItemName) {
		int Top = 0;
		int Left = 0;
		// find the item from the name
		for (Iterator<ItemDropController> it = itemList.iterator(); it
				.hasNext();) {

			ItemDropController currentItem = it.next(); // No downcasting
														// required.
			System.out.println("blah3-" + ReItemName + "-");
			System.out.println("blah4-" + currentItem.itemName + "-");
			if (currentItem.itemName.compareTo(ReItemName) == 0)
			{
				// remove its position
				System.out.println("blah3");
			// Top = currentItem.getDropTarget().getElement().getOffsetTop();
			System.out.println("blah4");
			Left = currentItem.getDropTarget().getElement().getOffsetLeft();
			int LeftLimit = dragController.getBoundaryPanel().getOffsetWidth();

			// work out the liner slot position and set it to false.
			old_LinerPos = (((Top / 100) * LeftLimit) + Left) / 100;
			itemSpace[old_LinerPos] = false;

			// we delete it.
			currentItem.getDropTarget().removeFromParent();

			targetPanel.remove(currentItem.getDropTarget());
			dragController.unregisterDropController(currentItem);
			itemList.remove(currentItem);
			}
		}

	}

public void triggerItem	(final String ItemName) {
	
	//loop to get item
	for (Iterator<ItemDropController> it = itemList.iterator(); it
	.hasNext();) {

ItemDropController currentItem = it.next();
if (currentItem.itemName.compareTo(ItemName) == 0){
	//pop it up!
	Log.info("found item to open..|"+currentItem.itemName+"|");
	((InventoryIcon)currentItem.getDropTarget()).triggerPopup();
}
	}
	
	
	
}

public Widget getItem(final String ItemName) {
	
	//loop to get item
	for (Iterator<ItemDropController> it = itemList.iterator(); it
	.hasNext();) {

ItemDropController currentItem = it.next();
if (currentItem.itemName.compareTo(ItemName) == 0){
	//return it
	return ((InventoryIcon)currentItem.getDropTarget()).PopUp;
}
	}
	
	return null;
}

	
	public boolean playerHasItem(final String ItemName) {
		
		boolean hasitem = false;
		
		//we test if the player has an item
		for (Iterator<ItemDropController> it = itemList.iterator(); it
		.hasNext();) {

	ItemDropController currentItem = it.next();
	if (currentItem.itemName.compareTo(ItemName) == 0){
		hasitem = true;
	}
		}
		
		return hasitem;
	}
	public void AddItem(final String ItemName, boolean TriggerPopUp) {
		final boolean TriggerPopUpAfterLoading = TriggerPopUp;
		
		// get item ini location
		String itemlocation = inventory_url + ItemName + "/" + ItemName
				+ ".ini";

		// get ini
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.GET,
				itemlocation);
		System.out.print("\n /n <<< " + itemlocation + "-");
		try {
			requestBuilder.sendRequest("", new RequestCallback() {
				public void onError(Request request, Throwable exception) {
					System.out.println("http failed");
				}

				public void onResponseReceived(Request request,
						Response response) {
					System.out.println("res=" + response.getText());

					// get type
					String type = response.getText().substring(
							response.getText().indexOf("Type = ") + 7,
							response.getText().indexOf("\n",
									response.getText().indexOf("Type = ") + 7))
							.trim();

					String discription = "";
					// get discription if present
					if (response.getText().indexOf("Description = '") > -1) {
						discription = response
								.getText()
								.substring(
										response.getText().indexOf(
												"Description = '") + 15,
										response
												.getText()
												.indexOf(
														"'",
														response
																.getText()
																.indexOf(
																		"Description = '") + 16))
								.trim();
						discription = MyApplication
								.SwapCustomWords(discription);
					}

					String URL = "";
					// get youtube if present
					if (response.getText().indexOf("URL = ") > -1) {
						URL = response.getText().substring(
								response.getText().indexOf("URL = ") + 6,
								response.getText()
										.indexOf(
												"\n",
												response.getText().indexOf(
														"URL = ") + 7))
								.trim();
					} else {
						URL = "";
					}
					String title = "";
					// get title if present
					if (response.getText().indexOf("Title = '") > -1) {
						title = response.getText().substring(
								response.getText().indexOf("Title = '") + 9,
								response.getText()
										.indexOf(
												"'",
												response.getText().indexOf(
														"Title = '") + 10))
								.trim();
					} else {
						title = ItemName;
					}
					// get size if present
					String Size = "";
					String size_x = "10";
					String size_y = "10";
					if (response.getText().indexOf("Size = ") > -1) {
						Size = response.getText().substring(
								response.getText().indexOf("Size = ") + 7,
								response.getText()
										.indexOf(
												"\n",
												response.getText().indexOf(
														"Size = ") + 8))
								.trim();
						
						size_x = Size.split(",")[0];
						size_y = Size.split(",")[1];
						MyApplication.DebugWindow.addText("loading movie"+size_x);
						
					} else {
						Size = "";						
					}
					// get if magnifiable
					boolean is_magnifiable = false;
					if (response.getText().indexOf("Magnifiable = ") > -1) {
						String ismag = response.getText().substring(
								response.getText().indexOf("Magnifiable = ") + 14,
								response.getText()
										.indexOf(
												"\n",
												response.getText().indexOf(
														"Magnifiable = ") + 14))
								.trim();
						
						if (ismag.compareTo("true")==0){
							is_magnifiable=true;
						}
						
						
						MyApplication.DebugWindow.addText("is mag?"+is_magnifiable);
						
					} 
					
					String Embed = "";
					if (response.getText().indexOf("Embed = ") > -1) {
						Embed = response.getText().substring(
								response.getText().indexOf("Embed = ") + 8,
								response.getText()
										.indexOf(
												"\n",
												response.getText().indexOf(
														"Embed = ") + 8))
								.trim();					
												
						
						
					} 
					 System.out.println("type="+type);
					// if type is picture;
				//	InventoryIcon newpop = new InventoryIcon(
				//			(new Label("null")), ItemName, title);

				//	ItemDropController newitem = new ItemDropController(newpop);

					 InventoryIcon newpop;
					 ItemDropController newitem;
					 
					if (type.compareTo("Picture") == 0) {

						int rsize_x = Integer.parseInt(size_x);
						int rsize_y = Integer.parseInt(size_y);
						
						imagePopUp BigPicture = new imagePopUp(
								"InventoryItems/" + ItemName + "/" + ItemName
										+ ".jpg", discription,rsize_x,rsize_y);

						newpop = new InventoryIcon(BigPicture, ItemName, title);

						newitem = new ItemDropController(newpop);

					} else if (type.compareTo("Movie") == 0) {

						moviePopUp BigPicture = new moviePopUp(
								"InventoryItems/" + ItemName + "/" + ItemName
										+ ".mov",size_x,size_y);

						newpop = new InventoryIcon(BigPicture, ItemName, title);

						newitem = new ItemDropController(newpop);

					} else if (type.compareTo("YouTube") == 0) {

						youtubePopUp BigPicture = new youtubePopUp(URL,425,345);

						newpop = new InventoryIcon(BigPicture, ItemName, title);
						//videos at 19000
						newpop.setFixedZdepth(1900);
						
						newitem = new ItemDropController(newpop);

					} else if (type.compareTo("Embed") == 0) {

						embedPopUp embededthingy = new embedPopUp(URL,size_x,size_y,Embed);
						MyApplication.DebugWindow.addText("\n embed code="+Embed);
						
						newpop = new InventoryIcon(embededthingy, ItemName, title);
						//videos at 19000
						newpop.setFixedZdepth(1900);
						
						newitem = new ItemDropController(newpop);

					} else if (type.compareTo("PNGPicture") == 0) {

						imagePNGPopUp BigPicture = new imagePNGPopUp(
								"InventoryItems/" + ItemName + "/" + ItemName
										+ ".png", discription);

						newpop = new InventoryIcon(BigPicture, ItemName, title);

						newitem = new ItemDropController(newpop);

					} else if (type.compareTo("Flash") == 0) {

						flashPopUp FlashItem = new flashPopUp("InventoryItems/"
								+ ItemName + "/" + ItemName + ".swf",size_x,size_y);

						newpop = new InventoryIcon(FlashItem, ItemName, title);	
						
						
						newitem = new ItemDropController(newpop);
										
						if (is_magnifiable){
							FlashItem.Magnifable = true;
							MyApplication.DebugWindow.addText("flashitem mag set to.."+FlashItem.Magnifable);
						}
						
						
					} else if (type.compareTo("ToggleItemGroup") == 0) {

						toggleimagegroupPopUp TIGitem = new toggleimagegroupPopUp(
								ItemName, discription,size_x,size_y);

						newpop = new InventoryIcon(TIGitem, ItemName, title);

						newitem = new ItemDropController(newpop);
						
						
						if (is_magnifiable){
							TIGitem.Magnifable = true;
							MyApplication.DebugWindow.addText("flashitem mag set to.."+TIGitem.Magnifable);
						}
						
					} else if (type.compareTo("Overlay") == 0) {

						overlayPopUp Overlay = new overlayPopUp();

						newpop = new InventoryIcon(Overlay, ItemName, title);

						newitem = new ItemDropController(newpop);
					} else if (type.compareTo("MAGNIFYINGGLASS") == 0) {

						ToolPopUp mag = new ToolPopUp(discription,
								title);
						mag.tooltype="MAGNIFYINGGLASS";
						mag.POPUPONCLICK = false;
						newpop = new InventoryIcon(mag, ItemName, title);
						//tools at 18000
						newpop.setFixedZdepth(1800);
						
						newitem = new ItemDropController(newpop);
						
					} else if (type.compareTo("TextScroll") == 0) {

						textScroller textScroll = new textScroller("InventoryItems/"
								+ ItemName + "/" + ItemName + ".html");
						System.out.print("\n ----make text scroller"+discription);
						
						newpop = new InventoryIcon(textScroll, ItemName, title);

						//newpic.setTitle(title);

						newitem = new ItemDropController(newpop);
					}else if (type.compareTo("Concept") == 0) {

						ConceptPopUp Overlay = new ConceptPopUp(discription,
								title);

						newpop = new InventoryIcon(Overlay, ItemName, title);

						//newpic.setTitle(title);

						newitem = new ItemDropController(newpop);
					} else {
						// default concept widget
						newpop = new InventoryIcon((new ConceptPopUp(ItemName, title)),
								ItemName, title);
						newpop.Name = ItemName;
						newitem = new ItemDropController(newpop);
					}
					// move the label
					targetPanel.add(newitem.getDropTarget());

					// find the next position
					int NextPosX = ((itemList.size()) * 100) % RInventorySizeX;
					int NextPosY = 100 * ((((itemList.size()) * 100) - NextPosX) / RInventorySizeX);

					targetPanel.setWidgetPosition(newitem.getDropTarget(),
							NextPosX, NextPosY);

					// make the label draggable
					dragController.makeDraggable(newitem.getDropTarget());
					dragController.registerDropController(newitem);

					// add the item
					itemList.add(newitem);

					// Now we retrieve the style in the Dom where it says LEFT:
					// ###px; and TOP ###px
					int Left = NextPosX;
					int Top = NextPosY;
					int LeftLimit = dragController.getBoundaryPanel()
							.getOffsetWidth();

					// work out the liner slot position and set it to true.
					LinerPos = (((Top / 100) * LeftLimit) + Left) / 100;
					itemSpace[LinerPos] = true;

					MyApplication.DebugWindow.addText(LinerPos + "=set too true ");
					
					//and, if needbe, popit up
					if (TriggerPopUpAfterLoading){
						Log.info("triggering popup");
						
						newpop.triggerPopup();
					}
					
				}
			});
		} catch (RequestException ex) {
			System.out.println("can not get item, does the directory exist?");
		}
	}
	
	public void AddItem(final String ItemName) {
		
		this.AddItem(ItemName, false);

	}

	

	public boolean DRAGABLE() {
		// TODO Auto-generated method stub
		return true;
	}

	public boolean POPUPONCLICK() {
		// TODO Auto-generated method stub
		return false;
	}

	public String POPUPTYPE() {
		// TODO Auto-generated method stub
		return null;
	}

	public void RecheckSize() {
		// TODO Auto-generated method stub
		
	}

	public boolean MAGNIFYABLE() {
		// TODO Auto-generated method stub
		return false;
	}

}
