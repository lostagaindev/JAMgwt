package com.darkflame.client;

import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.ui.AbsolutePanel;

public class fader extends AbsolutePanel{

	public fader (){
		this.setStyleName("fader");

        DOM.setStyleAttribute(this.getElement(), "zIndex", "1000");
     //   System.out.println("blah");
      //  System.out.println(this.getElement().getStyle().getProperty("zIndex"));
        
	    DOM.setStyleAttribute(this.getElement(), "width", "100%");
        DOM.setStyleAttribute(this.getElement(), "height", "100%");
        
	}
	
}
