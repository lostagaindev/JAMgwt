package com.darkflame.client;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.ImageBundle;

/** Images for the game engine, simply extend a group of images you want to use **/

/** Currently set up for the cuypers code **/
public interface JargImages extends MemDayImages {
						
}
		
		


