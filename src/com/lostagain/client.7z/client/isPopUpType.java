package com.darkflame.client;


/**
 * A widget that implements this interface has its own special close function
 * */

public interface isPopUpType {

	public boolean POPUPONCLICK();
	public boolean DRAGABLE();

	 
	 public String POPUPTYPE();
	 
	  public void RecheckSize();
	  
	  
	 
}
