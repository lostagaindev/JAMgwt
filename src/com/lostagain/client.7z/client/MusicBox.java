package com.darkflame.client;

import java.util.ArrayList;

import com.allen_sauer.gwt.voices.client.Sound;
import com.allen_sauer.gwt.voices.client.SoundController;
import com.allen_sauer.gwt.voices.client.handler.PlaybackCompleteEvent;
import com.allen_sauer.gwt.voices.client.handler.SoundHandler;
import com.allen_sauer.gwt.voices.client.handler.SoundLoadStateChangeEvent;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.HorizontalPanel;

public class MusicBox extends HorizontalPanel {
//sound controller;
	
	static final SoundController musicController = new SoundController();
    // Sound music = musicController.createSound(Sound.MIME_TYPE_AUDIO_MPEG,MyApplication.audioLocation_url+"");
	static Sound music;
	//loop event
	 static SoundHandler looper;
	 
	//TempLabels
	static final Label LeftPic = new Label("< ");
	static final Label RightPic = new Label(" >");
	
	//Music Tack Title
	//static final Label CurrentMusicTrackLabel = new Label(" -NONE- ");
	final SpiffyListBox CurrentMusicTrackLabel = new SpiffyListBox();
	
	static final ListBox test = new ListBox();
	
	//Array of music tracks
	final static ArrayList<String> musicTracks = new ArrayList<String>();
	
	//current selected
	static int currentTrack=0;
	
	public MusicBox(){
		
		//set event
		looper =  loopevent();
		// add widgets
		
		
		
		this.add(LeftPic);
		this.setCellVerticalAlignment(LeftPic, HasVerticalAlignment.ALIGN_BOTTOM );
		LeftPic.getElement().getStyle().setProperty("color", "FFFFFF");
		
		this.add(CurrentMusicTrackLabel);
		//SpiffyListBox testTest = new SpiffyListBox();
		//testTest.addItem("blah","blah");
		//this.add(testTest);
		
		CurrentMusicTrackLabel.setSize("100%","100%");
		CurrentMusicTrackLabel.ScrollContainer.setHeight("290px");
		
		CurrentMusicTrackLabel.setVisibleItemCount(1);
		//CurrentMusicTrackLabel.DropDownContainer.setAnimationEnabled(true);
	
		CurrentMusicTrackLabel.CurrentSelectedLab.setStyleName("MusicBoxDropDownLabel");		
		CurrentMusicTrackLabel.DropDownContainer.removeStyleName("SpiffyTextBox");
		CurrentMusicTrackLabel.ListContainer.setStyleName("MusicBoxDropDownPanel");
		CurrentMusicTrackLabel.hoverStyleName = "MusicBoxDropDownHover";
		
	//	CurrentMusicTrackLabel.getElement().getStyle().setProperty("zIndex", "99990");
		//Window.alert("spiffy text box added");
		//CurrentMusicTrackLabel.addItem("test");
		//CurrentMusicTrackLabel.addItem("test2");
	//	CurrentMusicTrackLabel.addItem("test3");
		//Window.alert("test items added");
		
		this.setCellHorizontalAlignment(CurrentMusicTrackLabel, HasHorizontalAlignment.ALIGN_CENTER);
		this.setCellVerticalAlignment(CurrentMusicTrackLabel, HasVerticalAlignment.ALIGN_BOTTOM );
		/* the following fails in IE:
		CurrentMusicTrackLabel.setWidth("100%");
		
		CurrentMusicTrackLabel.setHeight("100%");
		*/
		this.add(RightPic);
		this.setCellVerticalAlignment(RightPic, HasVerticalAlignment.ALIGN_BOTTOM );
		this.setCellHorizontalAlignment(RightPic, HasHorizontalAlignment.ALIGN_RIGHT);
		RightPic.getElement().getStyle().setProperty("color", "FFFFFF");
		
		//set width
		this.setSize("100%","100%");
		
		musicTracks.clear();
		//CurrentMusicTrackLabel.clear();
		//set first track to blank

		MyApplication.DebugWindow.addText("/n starting music box-");
		//musicTracks.add(" -NONE- ");
		//CurrentMusicTrackLabel.addItem(" -NONE- ");
		this.addTrack(" -NONE- ");
		
		CurrentMusicTrackLabel.addChangeHandler(new ChangeHandler(){
			public void onChange(ChangeEvent event) {
				
				
				currentTrack=CurrentMusicTrackLabel.getSelectedIndex();
				CurrentMusicTrackLabel.setFocus(false);
				MyApplication.DebugWindow.addText("\n changing track to -"+currentTrack);
				System.out.print("\n changing track to -"+currentTrack);
				MyApplication.AnswerBox.setFocus(true);
				//play			
				playtrack(currentTrack);
			}

			
		});
		
		//make buttons work
		LeftPic.addClickHandler(new ClickHandler(){

			public void onClick(ClickEvent event) {
				prevTrack();
				
				}
			
		});
		RightPic.addClickHandler(new ClickHandler(){

			public void onClick(ClickEvent event) {
				nextTrack();
				System.out.print("bnl");
				}

			
		});
		
	}
	
	public void nextTrack(){
		//if theres a next track;
		if ((currentTrack+1)<(musicTracks.size())){
			
			currentTrack=currentTrack+1;
			
			CurrentMusicTrackLabel.setItemSelected(currentTrack,true);
			
			//play			
			playtrack(currentTrack);
		}		
	}
	
	public void prevTrack(){
		//if theres a next track;
		if (currentTrack>0){			
			currentTrack=currentTrack-1;
			
			CurrentMusicTrackLabel.setItemSelected(currentTrack,true);
			//play	
			playtrack(currentTrack);
		}			
		
		
	}
	
    public void addTrack(String Track){	
    	MyApplication.DebugWindow.addText("--"+Track);
    	
	musicTracks.add(Track);		
	
	CurrentMusicTrackLabel.addItem(musicTracks.get(musicTracks.size()-1).split("\\.")[0]);	
	
	
	//if its not set to none
	
	if (currentTrack>0){
		currentTrack = musicTracks.size()-1;
	CurrentMusicTrackLabel.setItemSelected(CurrentMusicTrackLabel.getItemCount()-1,true);
	
	MyApplication.DebugWindow.addText(":"+musicTracks.get(currentTrack));
	
	currentTrack=CurrentMusicTrackLabel.getSelectedIndex();
	CurrentMusicTrackLabel.setFocus(false);
	
	//play			
	playtrack(currentTrack);
	}
	
	}
    
    public void playtrack(int ThisTrack){

		System.out.print("\n play music-"+ThisTrack);
		
    	if (music != null) {    		
    		music.stop();
    		music.removeEventHandler(looper);
    		System.out.print("\n stop music-");
    	}
    	
    	if (ThisTrack == 0)
    	{
    		
    		
    	//	music.removeEventHandler(looper);	
    		
    		//music.stop();
    		//System.out.print("\n stop music-");
    	//	MyApplication.DebugWindow.addText("stop track-");
    		
    	} else  {
    	//	music.stop();
    		MyApplication.DebugWindow.addText("play track-"+ThisTrack);
    	//	music.removeEventHandler(looper);
    		music = musicController.createSound(Sound.MIME_TYPE_AUDIO_MPEG,MyApplication.audioLocation_url+musicTracks.get(ThisTrack));
    		music.addEventHandler(looper);
        	music.play();
        	
    	}
    	
    			
        		
        
    }

	private SoundHandler loopevent() {
		return new SoundHandler(){

			public void onPlaybackComplete(PlaybackCompleteEvent event) {
				// TODO Auto-generated method stub
				System.out.print("\n looping music-");
				music.play();
			}

			public void onSoundLoadStateChange(
					SoundLoadStateChangeEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		};
	}
	
}
