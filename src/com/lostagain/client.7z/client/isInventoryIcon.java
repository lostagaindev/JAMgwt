package com.darkflame.client;


/**
 * A widget that implements this interface has its own special close function
 * */

public interface isInventoryIcon {


    public void setPopedUp(Boolean settothis);
	 
	 
}
