package com.darkflame.client;


import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;

public class SpiffyScoreBoard extends HorizontalPanel{
	
	int CurrentScore = 0;
	int CurrentlyDisplayedScore = 0;
	Label ScoreLabel = new Label();
	
	final Timer ScoreHomer;
	Boolean CurrentlyChanging = false;
	
	public SpiffyScoreBoard(String BackgroundURL /** URL to Background */){
		
		this.setSize("100%", "100%");
		//add the background
		
		ScoreLabel.setStylePrimaryName("ScoreLabel");
		//this.setStylePrimaryName("ScoreBox");
		
		//this.setPixelSize(SizeX, SizeY);
				
		//and the score
		this.add(ScoreLabel);
		this.setCellHorizontalAlignment(ScoreLabel, HasHorizontalAlignment.ALIGN_CENTER);
		this.setSpacing(1);
		
		//Score Homer
		ScoreHomer = new Timer(){

			@Override
			public void run() {
				int Difference = CurrentlyDisplayedScore-CurrentScore;
				if (Difference<0){
					Difference=Math.min(Difference/35, -1);
				} else {
					Difference=Math.max(Difference/35, 1);
				}
				
				if (CurrentlyDisplayedScore!=CurrentScore){
					//difference
						
						CurrentlyDisplayedScore=CurrentlyDisplayedScore-Difference;
					
					//if (CurrentlyDisplayedScore>CurrentScore){
					//	CurrentlyDisplayedScore=CurrentlyDisplayedScore-1;
					//} else {
					//	CurrentlyDisplayedScore=CurrentlyDisplayedScore+1;
					//}
						ScoreLabel.setText(""+CurrentlyDisplayedScore+"");
						
				} else {
					CurrentlyDisplayedScore=CurrentScore;
					ScoreLabel.setText(""+CurrentlyDisplayedScore+"");
					
					CurrentlyChanging = false;
					this.cancel();
					
				}
				//System.out.print("\n--"+Difference);
			}
			
		};

		//update the Score Label
		UpdateScore();
		
	}
	
	public void SetScore(int newscore)
	{
		CurrentScore=newscore;
		UpdateScore();
	}
	public void UpdateScore(){
		//ScoreLabel.setText(":"+CurrentScore+":");
		
		//Timer homes-in on correct score.
		
		//Run timer if not already running
		if (CurrentlyChanging == false){
			CurrentlyChanging = true;
		ScoreHomer.scheduleRepeating(50);
		}
		
	}
	public void AddScore(int AddThis){
		CurrentScore=CurrentScore+AddThis;
		UpdateScore();
	}
	
	
	
}
