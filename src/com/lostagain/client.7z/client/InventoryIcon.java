package com.darkflame.client;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Widget;

import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.Window;


public class InventoryIcon extends Image implements isInventoryIcon {
	
	     //item Name
	     String Name = "";
	     	     
	      Boolean popedup = false;
	     
	      String Title = "";
		//Discription
	    Label Discription = new Label("");
		//main image
		Image Picture = new Image();
		//screen size
		int ScreenSizeX = Window.getClientWidth();
		int ScreenSizeY = Window.getClientHeight();
		int InventorySizeX = (100*(Window.getClientWidth()/150));
		int InventorySizeY = (100*(Window.getClientHeight()/150));
		
		int roundTo = 100;
		int RInventorySizeX = (int)((InventorySizeX + (0.5 * roundTo)) / roundTo) * roundTo;
		int RInventorySizeY = 20+(int)((InventorySizeY + (0.5 * roundTo)) / roundTo) * roundTo;
		
		 //associated Widget to popup
		Widget PopUp = new Widget();
		  int fixedxdepth = -1;
		  InventoryIcon iconroute;
		  final PopUpWithShadow ItemWithShadow;
		  
	 public InventoryIcon(final Widget ItemPopUp,final String Iconlocation, final String IconTitle){
		

			
		 PopUp = ItemPopUp;
		 Name = Iconlocation;
		 Title = IconTitle;
		 iconroute = this;
		 

		ItemWithShadow = new PopUpWithShadow(iconroute,"30%","25%",Title,PopUp);
		 
		 // Discription.setText(ImageDiscription);
		 this.setStylePrimaryName("pngfix");
		// Name = Imagelocation;
		 this.setTitle(IconTitle);
		 
		 this.setUrl("InventoryItems/"+Iconlocation+"/thumb_"+Iconlocation+".png");	
		 System.out.print("InventoryItems/"+Iconlocation+"/thumb_"+Iconlocation+".png");
		 
		 this.setSize("100px", "100px");
		 
		 
		 //this.add(Discription);
           // Add the items enlarger click listener if it has one. 
		 
		 this.addClickHandler(new ClickHandler(){

			public void onClick(ClickEvent event) {
				 //make sure this item is designed to popup on click
 	    		  if (((isPopUpType)PopUp).POPUPONCLICK()==true){
 	    			 
 	    		  //and this isnt the end of a drag/drop operation
 	    		  if (!(InventoryPanel.cancelClick)){		    		  	    		  
 	    		  triggerPopup();
 	    		  }
 	    		  
 	    		  InventoryPanel.cancelClick = true;
 	    		  } 
				
			}
			 
		 });
		 this.addMouseDownHandler(new MouseDownHandler (){
			 public void onMouseDown(MouseDownEvent event) {
				
				 //this cancels the click if there is a drag inbetween
				 InventoryPanel.cancelClick = false;
				  
				 
		    	  }

		      });
		 
		 
	 }
	 /**
	 public void onBrowserEvent(Event event){
	     
         switch(DOM.eventGetType(event)){
             case Event.ONMOUSEDOWN:
                 Window.setTitle("button = "+DOM.eventGetButton(event)); 
                 if (DOM.eventGetButton(event)==1){
                	
                 }
             case Event.ONMOUSEUP:
            	 if (DOM.eventGetButton(event)==1){

   	    		 
            	 }
         }
	 }**/
	public void setPopedUp(Boolean settothis) {
		popedup = settothis;
		
	}
	public void setFixedZdepth(int setDepth) {
		fixedxdepth = setDepth;
		
	}

	final public void triggerPopup() {
		
		Log.info("popping up..|"+this.Name+"|");
		
		if (popedup == false) {
			  
			  
		  
		  //disable icon
		  popedup = true;
		 
	//	  int posX = (int)Math.round((ScreenSizeX/2 - ((ScreenSizeX * 0.8)/2)));
		  
		//  int posY = (int)Math.round((ScreenSizeY/2 - ((ScreenSizeY * 0.78)/2)));
		  
		 // MyApplication.fadeback.setSize("100%", "100%");
		//  RootPanel.get().add(MyApplication.fadeback,0, 0);
		
		  	    	
		//final PopUpWithShadow ItemWithShadow = new PopUpWithShadow(iconroute,"30%","25%",Title,PopUp);
		
		if (fixedxdepth>-1){
		ItemWithShadow.fixedZdepth(fixedxdepth);
		}
		ItemWithShadow.OpenDefault();
		
		  }else {
 			  //if its already popped up, we close it.
  			 ItemWithShadow.CloseDefault();
  			 
  		  }
	}
	

	   }