package com.darkflame.client;

import java.util.Date;
import java.util.Iterator;

import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.http.client.URL;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DecoratorPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Hyperlink;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class ControllPanel extends VerticalPanel implements hasCloseDefault, hasOpenDefault,isPopUpType  {

	final ChangePasswordBox ChangePasswordBox = new ChangePasswordBox();
	final ResetGameBox ResetGameBox = new ResetGameBox();
	 final Hyperlink changepassword = new Hyperlink(LoadGamesText.ControllPanel_ChangePassword,""); //$NON-NLS-1$ 
	 final Hyperlink resetgame = new Hyperlink("Reset Game",""); //$NON-NLS-1$ //$NON-NLS-2$
	 
	 HorizontalPanel SoundEffectsOnOff = new HorizontalPanel();
	  Label sound_options = new Label(LoadGamesText.ControllPanel_SoundEffects); 
	  
	  RadioButton soundon = new RadioButton("sound_options", LoadGamesText.ControllPanel_on); //$NON-NLS-1$ 
	  RadioButton soundoff = new RadioButton("sound_options", LoadGamesText.ControllPanel_off); //$NON-NLS-1$ 
	 HorizontalPanel AnimationEffectsOnOff = new HorizontalPanel();
	 
	  Label animation_options = new Label(LoadGamesText.ControllPanel_AnimationEffects);	   
	  RadioButton animationon = new RadioButton("animation_options", LoadGamesText.ControllPanel_on); //$NON-NLS-1$ 
	  RadioButton animationoff = new RadioButton("animation_options", LoadGamesText.ControllPanel_off); //$NON-NLS-1$ 
	  
	  HorizontalPanel AutosaveOnOff = new HorizontalPanel();
		
	  Label autosave_options = new Label("Autosave:");	   
	  RadioButton autosaveon = new RadioButton("autosave_options", LoadGamesText.ControllPanel_on); //$NON-NLS-1$ 
	  RadioButton autosaveoff = new RadioButton("autosave_options", LoadGamesText.ControllPanel_off); //$NON-NLS-1$ 
	 
	  
	  //layout controlls
	  Label LayoutSizeOveride = new Label(LoadGamesText.ControllPanel_InterfaceSize);	 
	  ListBox LayoutModes = new ListBox() ;
	  
	  
	// panel layout
	topBar NewTopBar = new topBar(LoadGamesText.ControllPanel_ControllPanel,this); 
	final HTML SaveData = new HTML(" "); //$NON-NLS-1$
	HorizontalPanel SaveLoadButtons = new HorizontalPanel();
	Button SaveGameData = new Button("Save To Link"); //$NON-NLS-1$
	
	Button SaveGameDataToSever = new Button(LoadGamesText.ControllPanel_ClickHereToSaveYourProgress); 
	Button LogOut = new Button(LoadGamesText.ControllPanel_ClickHereToLogOut);	 
	
	Button LoadGameData = new Button(LoadGamesText.ControllPanel_LoadFromText); 
	String location = getLocation();
	
	
	
	private static native String getLocation() /*-{ 
	   return $wnd.location.href; 

	}-*/;
	public ControllPanel()  {
		
		this.setSize("300px", "60px"); //$NON-NLS-1$ //$NON-NLS-2$
		
		this.setStylePrimaryName("notepadback"); //$NON-NLS-1$
		
		this.add(SaveData);
		
		this.setCellHorizontalAlignment(SaveData, HasHorizontalAlignment.ALIGN_CENTER);
				
		this.setSpacing(8);
		
		
		
		
		this.add(SaveLoadButtons);
		
		SaveLoadButtons.add(SaveGameDataToSever);
		this.add(LogOut);
		
		SoundEffectsOnOff.add(sound_options);
		SoundEffectsOnOff.add(soundon);
		soundon.setValue(true);
		SoundEffectsOnOff.add(soundoff);
		
		soundon.addClickHandler(updateUserOptions());
		soundoff.addClickHandler(updateUserOptions());
			
		
		this.add(SoundEffectsOnOff);
		
		AnimationEffectsOnOff.add(animation_options);
		AnimationEffectsOnOff.add(animationon);
		AnimationEffectsOnOff.add(animationoff);
		
		animationon.addClickHandler(updateUserOptions());
		animationon.setValue(true);
		animationoff.addClickHandler(updateUserOptions());
		
		this.add(AnimationEffectsOnOff);
		
		AutosaveOnOff.add(autosave_options);
		AutosaveOnOff.add(autosaveon);
		AutosaveOnOff.add(autosaveoff);
		
		this.add(AutosaveOnOff);
		autosaveon.addClickHandler(updateUserOptions());
		autosaveoff.setValue(true);
		autosaveon.addClickHandler(updateUserOptions());
		
		//LayoutMods
		LayoutModes.addItem(LoadGamesText.ControllPanel_Default); 
		LayoutModes.addItem(LoadGamesText.ControllPanel_Small); 
		LayoutModes.addItem(LoadGamesText.ControllPanel_Medium); 
		LayoutModes.addItem(LoadGamesText.ControllPanel_Big); 
		HorizontalPanel sizeoptions = new HorizontalPanel();
		sizeoptions.add(LayoutSizeOveride);
		sizeoptions.add(LayoutModes);
		LayoutModes.addChangeHandler(new ChangeHandler(){
			public void onChange(ChangeEvent event) {
				MyApplication.InterfaceSize = LayoutModes.getItemText(LayoutModes.getSelectedIndex());
				MyApplication.DebugWindow.addText(MyApplication.InterfaceSize);
				MyApplication.setInterfaceIconSize();
				
				//manualy overide javascript layout stylesheets
				if  (MyApplication.InterfaceSize.compareTo(LoadGamesText.ControllPanel_Small)==0) { 
					changecss("smallscreen"); //$NON-NLS-1$
				}
				if  (MyApplication.InterfaceSize.compareTo(LoadGamesText.ControllPanel_Medium)==0) { 
					changecss("midscreen"); //$NON-NLS-1$
				}
				if  (MyApplication.InterfaceSize.compareTo(LoadGamesText.ControllPanel_Big)==0) { 
					changecss("default"); //$NON-NLS-1$
				}
				MyApplication.resizeStoryBox();
				
			}
			
		});
		this.add(sizeoptions);
		
		HorizontalPanel Bottomsplitter = new HorizontalPanel();
		Bottomsplitter.setWidth("100%");
		Bottomsplitter.add(changepassword);
		Bottomsplitter.add(resetgame);
		Bottomsplitter.setCellHorizontalAlignment(changepassword, HasHorizontalAlignment.ALIGN_LEFT);		
		Bottomsplitter.setCellHorizontalAlignment(resetgame, HasHorizontalAlignment.ALIGN_RIGHT);
		
		this.add(Bottomsplitter);
		resetgame.addClickHandler(new ClickHandler(){
			public void onClick(ClickEvent event) {
			
				ResetGameBox.center();
			}
			 
		 });
		changepassword.addClickHandler(new ClickHandler(){
			public void onClick(ClickEvent event) {
				
				ChangePasswordBox.center();
			}
			 
		 });
		
		this.setCellHorizontalAlignment(LogOut, HasHorizontalAlignment.ALIGN_CENTER);
		
		SaveLoadButtons.setSpacing(5);

		this.setCellHorizontalAlignment(SaveLoadButtons,
				HasHorizontalAlignment.ALIGN_CENTER);
		
		
		
		
		LogOut.addClickHandler(new ClickHandler(){
			public void onClick(ClickEvent event) {
				
				//if guest we just refresh
				if (MyApplication.Username.equalsIgnoreCase("guest")){
					reload();
				}
				
				
				logoutUser(true);
				
				
				
				
			}
			
		});

		SaveGameDataToSever.addClickHandler(new ClickHandler(){
			public void onClick(ClickEvent event) {
				
				saveGame();
				
				
				
			}
			
		});
		LoadGameData.addClickHandler(new ClickHandler(){
			public void onClick(ClickEvent event) {				
				//LoadData(SaveData.getText());
			}
			
		});

		
		
		
	}
	public static native void changecss(String description) /*-{
	  
	     var i, a;
   for(i=0; (a = $doc.getElementsByTagName("link")[i]); i++){
	   if(a.getAttribute("title") == description){a.disabled = false;}
           else if((a.getAttribute("title") == "midscreen") || (a.getAttribute("title") == "smallscreen")){a.disabled = true;}	
	   	
   }
	}-*/;
	
	
	
	private ClickHandler updateUserOptions() {
		return new ClickHandler(){

			public void onClick(ClickEvent event) {
				
				//update options				
				MyApplication.SoundEffectOn = soundon.getValue();
				MyApplication.AnimationEffectsOn = animationon.getValue();
				MyApplication.autosaveon = autosaveon.getValue();
				
				//set animation on/off
				MyApplication.StoryTabs.setAnimationEnabled(MyApplication.AnimationEffectsOn);
				MyApplication.StoryTabs.getDeckPanel().setAnimationEnabled(MyApplication.AnimationEffectsOn);
				MyApplication.ControllPanelShadows.setAnimationEnabled(MyApplication.AnimationEffectsOn);	
				MyApplication.PlayersInventoryFrame.setAnimationEnabled(MyApplication.AnimationEffectsOn);	
				MyApplication.PlayersNotepadFrame.setAnimationEnabled(MyApplication.AnimationEffectsOn);	
				
			}
			
		};
	}
	 
	public void CloseDefault() {
		//-- we empty the textbox
		SaveData.setText(""); //$NON-NLS-1$
		
		
		//--
		MyApplication.ControllPanelOpen = false;
		MyApplication.ControllPanelButton.setAnimateClose();

		RootPanel.get().remove(this.getParent());

	}

	public void LoadData(String ProcessThis){
		
		
		String location = getLocation();
		//MyApplication.processInstructions(ProcessThis.trim());
		if (getLocation().indexOf("#")>-1){ //$NON-NLS-1$
		location = getLocation().substring(getLocation().indexOf("#")+1); //$NON-NLS-1$
		} 
		Window.open(location+"#"+ProcessThis.trim(),"_self", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
	}
	
	public String CreateSaveString(){
		Window.setTitle("saving game...");
		
		
		//generate save string
		String saveString = ""; //$NON-NLS-1$
		
		
		//Window.setTitle("saving items...");
		
		//first the items.
		  for (Iterator<ItemDropController> item_it = InventoryPanel.itemList.iterator(); item_it.hasNext(); ) {
			  
		   ItemDropController currentItem = item_it.next(); 
			  
		   saveString = saveString + "\n- AddItem = " + currentItem.itemName; //$NON-NLS-1$
		   
		   System.out.print(saveString);
		
		  }
		
		 // Window.setTitle("saving profiles...");
			
		//then the profile pages	  
		 
		  for (Iterator<String> it = Notebook.ProfilePagesLoaded.iterator(); it.hasNext(); ) {
			  
			  String currentItem = it.next(); 
			  
		   saveString = saveString + "\n- AddProfile = " + currentItem; //$NON-NLS-1$
		   
		   System.out.print(saveString);
		
		  }
		  

		//  Window.setTitle("saving chapters...");
			
		//then the chapters and pages
		  
         for (Iterator<Widget> it = MyApplication.ChapterList.VTabPanel.iterator(); it.hasNext(); ) {
        	 
        	 System.out.print( "\n number of chaps="+MyApplication.ChapterList.VTabPanel.getWidgetCount()); //$NON-NLS-1$
        	 
        	 Widget currentItem = it.next();
        	 Label currentLabel= ((Label)((DecoratorPanel)(currentItem)).getWidget()); 
			  
		   saveString = saveString + "\n- NewChapter = \"" + currentLabel.getText()+"\""; //$NON-NLS-1$ //$NON-NLS-2$
		  
		  // Window.setTitle("saving chapter..."+currentLabel.getText());

		   System.out.print(saveString);
		
		   int widgetnum = MyApplication.ChapterList.VTabPanel.getWidgetIndex(currentItem);
		   System.out.print("--"+widgetnum); //$NON-NLS-1$
		   // now the pages in that chapter
		   LocationTabSet TempTabSet =  MyApplication.AllLocationTabSets.get(MyApplication.ChapterList.PanelsToTriggerList[widgetnum]);
		   System.out.print("--"+ MyApplication.AllLocationTabSets.get(0).OpenPagesInSet.size()); //$NON-NLS-1$
		   
		   for (Iterator<String> lt_it = TempTabSet.OpenPagesInSet.iterator(); lt_it.hasNext(); ) {
				  
			   String lt_currentItem = lt_it.next(); 
				  
			   saveString = saveString + "\n- StoryBox = " + lt_currentItem+".html"; //$NON-NLS-1$ //$NON-NLS-2$
			   
			   System.out.print("="+saveString); //$NON-NLS-1$
			
			  }
		   
		  }
			
         

		//  Window.setTitle("saving music...");
			
       //then the music unlocked skipping the first one
		 
		  for (Iterator<String> it = MusicBox.musicTracks.iterator(); it.hasNext(); ) {
			  
			  String currentItem = it.next(); 
			  
			  if (currentItem.compareTo(" -NONE- ")!=0){
		   saveString = saveString + "\n- AddMusicTrack = " + currentItem; //$NON-NLS-1$
			  }
		   System.out.print(saveString);
		
		  }
		  

		//  Window.setTitle("saving secrets...");
			
		  //then the secrets unlocked 
			 
		  for (Iterator<Widget> it = MyApplication.SecretPanel.iterator(); it.hasNext(); ) {
			  
			  Hyperlink currentItem = (Hyperlink) it.next(); 
			  
		   saveString = saveString + "\n- AddSecret = " + currentItem.getText() +","+currentItem.getTitle(); //$NON-NLS-1$ //$NON-NLS-2$
		   
		   System.out.print(saveString);
		
		  }
		  

		//  Window.setTitle("saving setting; clues...");
			
		  //set clues
		  saveString = saveString + "\n- SetClueBox = " + MyApplication.playersClues.ClueArrayAsString(); //$NON-NLS-1$
		    MyApplication.DebugWindow.setText(MyApplication.playersClues.ClueArrayAsString());
		    

			//  Window.setTitle("saving setting; score...");
				
		  //set score 
	         saveString = saveString + "\n- SetScore = " + MyApplication.PlayersScore.CurrentScore; //$NON-NLS-1$
	       // Set Score list (to stop scores reaccoring)
	        saveString = saveString + "\n- PointsAwardedFor = " + MyApplication.ScoresAwarded; //$NON-NLS-1$
	 	    
	         
         // set chapter

			//  Window.setTitle("saving setting ;chapter...");
				
         saveString = saveString + "\n- SetLocation = " + MyApplication.location; //$NON-NLS-1$
         
         // set background
         Window.setTitle("saving setting ;background...");
         saveString = saveString + "\n- SetBackgroundImage = " + RootPanel.getBodyElement().getAttribute(
					"background");
        // Window.setTitle("saving setting ;current music...");
         // set current music playing
            saveString = saveString + "\n- PlayMusicTrack = " + MusicBox.currentTrack;
         
         
           // Window.setTitle("saving setting ;icons...");
         //set icons
         //hair length
         
         saveString = saveString + "\n- SetClockLadyIcon = " + MyApplication.StatueHead.originalfilename+"."+MyApplication.StatueHead.filenameext+","+(MyApplication.StatueHead.frametotal+1);
         
         //soldier
         
         saveString = saveString + "\n- SetSoldierIcon = " + MyApplication.solider.originalfilename+"."+MyApplication.solider.filenameext+","+(MyApplication.solider.frametotal+1);
         
         //bag
         //if the bag is a png;
         if (MyApplication.InventoryButton.originalfilename.length()>3){
         saveString = saveString + "\n- SetInventoryIcon = " + MyApplication.InventoryButton.originalfilename+"."+MyApplication.InventoryButton.filenameext+","+(MyApplication.InventoryButton.frametotal+1);
         } else if (MyApplication.BigInventoryImages.equals(MyApplication.BigMarInventoryImages)) {
        	 //its an internal specification - SetInventoryIcon =  
         saveString = saveString + "\n- SetInventoryIcon = magrietbag0.png,6";             	 
        	 
         }
         
         saveString = saveString + "\n";
         
         MyApplication.DebugWindow.clearText();
         MyApplication.DebugWindow.addText(saveString);
         //encypt
         
         
         
        // Window.alert("save string from 500;"+saveString.substring(500));
         
         //saveString = URL.encodeComponent(saveString);
		  
		  
		return saveString;		
	}
	
	
	public void ShowDefault() {

		this.setSize("100%", "100%"); //$NON-NLS-1$ //$NON-NLS-2$

		int ScreenSizeX = Window.getClientWidth();
		int ScreenSizeY = Window.getClientHeight();
		
		RootPanel.get().remove(MyApplication.fadeback);
		RootPanel.get().add(this.getParent(), (int)(ScreenSizeX*0.25),  (int)(ScreenSizeY*0.40));
	}
	 private native void reload() /*-{ 
	 	
	    //$wnd.location.reload(); 
	    $wnd.location = $wnd.location.href;
	    
	   }-*/;
	public void OpenDefault() {
		
		//if guest disable stuff;
		if (MyApplication.Username.equals("guest")){
			
			
			changepassword.setVisible(false);
			resetgame.setVisible(false);
			
			SaveLoadButtons.setVisible(false);
			
		}
		
		
	}
	public boolean DRAGABLE() {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean POPUPONCLICK() {
		// TODO Auto-generated method stub
		return false;
	}
	public String POPUPTYPE() {
		// TODO Auto-generated method stub
		return null;
	}
	public void RecheckSize() {
		// TODO Auto-generated method stub
		
	}
	public boolean MAGNIFYABLE() {
		// TODO Auto-generated method stub
		return false;
	}
	
	public void saveGame() {
		//MyApplication.processInstructions(ProcessThis.trim());
		if (getLocation().indexOf("#")>-1){ //$NON-NLS-1$
		location = getLocation().substring(0,getLocation().indexOf("#")); //$NON-NLS-1$
		} 
		
		 // MyApplication.Feedback.setText(URL.encodeComponent(CreateSaveString()));
		//encrypt string		
		MyApplication.DebugWindow.addText(MyApplication.messagehistory.getHTML());
		
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.POST,"Login_System/SaveGame.php"); //$NON-NLS-1$
				
				try {
				      requestBuilder.sendRequest("SaveData=" + URL.encodeComponent(CreateSaveString())+"&MessageHistory=" + URL.encodeComponent(MyApplication.messagehistory.getHTML()), new RequestCallback() { //$NON-NLS-1$ //$NON-NLS-2$
				        public void onError(Request request, Throwable exception) {
				        	System.out.println("encode url failed"); //$NON-NLS-1$
				        }

				        public void onResponseReceived(Request request, Response response) {
		                  
				        	//String responsetext = response.getText();
				        	//String saveString = "LoadGameData="+responsetext; //$NON-NLS-1$
				           //update widgets HTML field
				        	SaveData.setHTML(LoadGamesText.ControllPanel_DataSaved); 
				        	
				        }
				      });
				    } catch (RequestException ex) {
				    	String responsetext = "can not connect to game controll file"; //$NON-NLS-1$
				    	SaveData.setHTML(responsetext+"   "+ex.getMessage()); //$NON-NLS-1$
				    }
		//------
	}
	public void logoutUser(final Boolean reload) {
		//MyApplication.processInstructions(ProcessThis.trim());
		if (getLocation().indexOf("#")>-1){ //$NON-NLS-1$
		location = getLocation().substring(0,getLocation().indexOf("#")); //$NON-NLS-1$
		} 
		
		//  MyApplication.Feedback.setText(URL.encodeComponent(CreateSaveString()));
		//encrypt string	
		
		MyApplication.Feedback.setText(LoadGamesText.ControllPanel_loggingout); 
		
		RequestBuilder requestBuilder = new RequestBuilder(RequestBuilder.POST,"Login_System/LogoutUser.php"); //$NON-NLS-1$
				
				try {

					MyApplication.Feedback.setText(LoadGamesText.ControllPanel_loggingout2); 
					
				      requestBuilder.sendRequest("", new RequestCallback() { //$NON-NLS-1$
				        public void onError(Request request, Throwable exception) {
				        	System.out.println("encode url failed"); //$NON-NLS-1$
				        	MyApplication.Feedback.setText("error"+exception.getMessage()); //$NON-NLS-1$
				        }

				        public void onResponseReceived(Request request, Response response) {
		                  
				        	if (response.getText().compareTo("LoggedOutSuccess")==0){ //$NON-NLS-1$
				        	SaveData.setHTML(LoadGamesText.ControllPanel_LoggedOut);		
				        	
				        	//remove cookies to make double sure

							Iterator<String> cookieit = Cookies.getCookieNames().iterator();
							String cookin = Cookies.getCookieNames().toArray(new String[0])[0];
							Window.setTitle("removing cookies"+cookin);
							Cookies.setCookie(cookin, "", new Date(new Date().getTime()-1000*60*60*24), null, "/", false);
							Cookies.removeCookie(cookin);
							while (cookieit.hasNext()){
								
								String cookie = cookieit.next();
								Window.setTitle("removing cookie:"+cookie);
								
								Cookies.removeCookie(cookie);
								
							}
							// ----------------------------------
							Window.setTitle("removed cookies");
							
							if (reload){
				        	reload();
							}
							
				        	} else 
				        	{
				        		MyApplication.Feedback.setText("--"+response.getText()); //$NON-NLS-1$
				        	}
				        	
				        	
				        }
				      });
				    } catch (RequestException ex) {
				    	MyApplication.Feedback.setText("no response"+ex.getMessage()); //$NON-NLS-1$
				    }
		//------
	}
}
