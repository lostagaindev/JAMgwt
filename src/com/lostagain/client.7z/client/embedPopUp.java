package com.darkflame.client;

import com.darkflame.client.hasCloseDefault;
import com.darkflame.client.hasOpenDefault;
import com.darkflame.client.isPopUpType;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.SimplePanel;


public class embedPopUp extends SimplePanel  implements hasCloseDefault,isItem,
 hasOpenDefault, isPopUpType {
 boolean Magnifable = false;
	
 String sourceurl="";
 String sourcesizeX="";
 String sourcesizeY="";
 
	public embedPopUp(String URL, String sizeX, String sizeY,String EmbedCode){
		
		sourceurl = URL;
		sourcesizeX = sizeX;
		sourcesizeY= sizeY;
		
		
		HTML frame = new HTML (EmbedCode);
		//frame.setSize("100%", "100%");
		this.add(frame);
		
		this.setStylePrimaryName("notepadback");
		this.setSize( sourcesizeX+"px",sourcesizeY+"px");
		
		//MyApplication.DebugWindow.setText("size="+sizeX);
		
	}

	public void CloseDefault() {
		// TODO Auto-generated method stub
		
	}

	public void OpenDefault() {
		// TODO Auto-generated method stub
		// has to have grey back, and be set to fixed zdepth
		 RootPanel.get().add(MyApplication.fadeback,0, 0);
       //ControlPanel.ShowDefault();
     DOM.setStyleAttribute(MyApplication.fadeback.getElement(), "zIndex", ""+(MyApplication.z_depth_max+1));
     DOM.setStyleAttribute(MyApplication.fadeback.getElement(), "z-index", ""+(MyApplication.z_depth_max+1));
     MyApplication.z_depth_max = MyApplication.z_depth_max+1;
    
		
	
		
		
	}

	public String POPUPTYPE() {
		// TODO Auto-generated method stub
		return "EMBED";
	}
	public boolean POPUPONCLICK() {
		return true;
	}
	public void RecheckSize() {
		// TODO Auto-generated method stub
		
	}

	public boolean DRAGABLE() {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean MAGNIFYABLE() {
		// TODO Auto-generated method stub
		return Magnifable ;
	}

	public String SourceURL() {
		// TODO Auto-generated method stub
		return sourceurl;
	}

	public String sourcesizeX() {
		// TODO Auto-generated method stub
		return sourcesizeX;
	}

	public String sourcesizeY() {
		// TODO Auto-generated method stub
		return sourcesizeY;
	}
}
