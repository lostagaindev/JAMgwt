package com.darkflame.client;


/**
 * A widget that implements this interface has its own special close function
 * */

public interface isItem {


	 public String SourceURL();
	 public boolean MAGNIFYABLE();
	  
	 public String sourcesizeX();
	 public String sourcesizeY();
	 
}
