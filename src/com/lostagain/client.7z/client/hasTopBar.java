package com.darkflame.client;


/**
 * A widget that implements this interface has its own special close function
 * */

public interface hasTopBar {
	 
	 void HideTopBar();	 
	 void ShowTopBar();
	 
}
