package com.darkflame.client;

import java.util.ArrayList;
import java.util.Iterator;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Hyperlink;
import com.google.gwt.user.client.ui.Widget;

public class secretsPanel extends AbsolutePanel implements hasCloseDefault,hasOpenDefault,isPopUpType {

	final static ArrayList<Hyperlink> secretitems = new ArrayList<Hyperlink>();
	int numofitems = 0;
	int angle_between_each = 0;
	double baseangle = 0;
	
	int centerx = 100;
	int centery = 100;
	int radius = 50;
	
	Timer update;
	
	public secretsPanel(){
		
		this.setSize("571px", "617px");
		this.setStylePrimaryName("secretsback");
		
		update = new Timer(){

			@Override
			public void run() {
				baseangle=baseangle+1;
				if (baseangle>360){
					baseangle=0;
				}
				updatePositions(baseangle);
				
			}
			
		};
		
		//update.scheduleRepeating(1000);
		
	}
	
	
	public void addItem(String Name,final String Link){
		
		//first we make sure it dosnt already exist in the secret set
	//	Iterator<Hyperlink> it = secretitems.iterator(); 
		boolean addable = true;
		/*
		while (it.hasNext()){			
		 if (it.next().getText().compareTo(Name)==0){
			 addable = false;
			 break;
			 
		 }
		}		*/
		//
		
		if (addable == true){
		numofitems=numofitems+1;
		Hyperlink newsecret = new Hyperlink(Name, "");		
		newsecret.setTitle(Link);
		newsecret.addClickHandler(gotoURL(Link));
		newsecret.setStylePrimaryName("button1");
	   
		
		secretitems.add(newsecret);
		this.add(newsecret);
		
		angle_between_each=360/numofitems;
		}
	}


	public ClickHandler gotoURL(final String Link) {
		return new ClickHandler(){
			public void onClick(ClickEvent event) {
				 Window.open(Link, "_blank","");
			}
			
		};
	}
	public void updatePositions(double from_this_angle){
		
		//center point
		centerx = (this.getOffsetWidth()/2)-15;
		centery = (this.getOffsetHeight()/2);	
		radius = (this.getOffsetWidth()/2)-35;
		
		Iterator<Hyperlink> it = secretitems.iterator(); 
		
		while (it.hasNext()){
			
		Widget item = it.next();
		
		//angle displacement from base
		int displace = (secretitems.indexOf(item))*angle_between_each;
		
		//work out x/y
		int newxpos = (int)Math.round(centerx + (Math.sin(  Math.toRadians(from_this_angle+displace) )*radius));
		int newypos = (int)Math.round(centery + (Math.cos(  Math.toRadians(from_this_angle+displace) )*radius));
		
		
		//get item
		 this.setWidgetPosition(item, newxpos,newypos); 
		}
		
		
		
	}


	public void CloseDefault() {
		// we stop spinning
		update.cancel();

		MyApplication.SecretsPopupPanelButton.setAnimateClose();
		MyApplication.SecretsPanelOpen = false;
		
	}


	public void OpenDefault() {
		// We start to spin...
		update.scheduleRepeating(45);
	}


	public boolean DRAGABLE() {
		// TODO Auto-generated method stub
		return true;
	}


	public boolean POPUPONCLICK() {
		// TODO Auto-generated method stub
		return false;
	}


	public String POPUPTYPE() {
		// TODO Auto-generated method stub
		return null;
	}


	public void RecheckSize() {
		// TODO Auto-generated method stub
		
	}
	public boolean MAGNIFYABLE() {
		// TODO Auto-generated method stub
		return false;
	}
}
