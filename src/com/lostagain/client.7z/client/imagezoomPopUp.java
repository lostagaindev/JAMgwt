package com.darkflame.client;

import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.LoadListener;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class imagezoomPopUp extends VerticalPanel implements hasCloseDefault,
		hasTopBar, hasOpenDefault, isPopUpType {
	
	VerticalPanel container = this;
	// Discription
	HTML Discription = new HTML("");
	String ImageDiscription = "";
	// main image
	SpiffyImage bigPicture = new SpiffyImage();
	// screen size
	int ScreenSizeX = Window.getClientWidth();
	int ScreenSizeY = Window.getClientHeight();
	// pic size
	int picX = 0;
	int picY = 0;
	int posX = 0;
	int posY = 0;

	//requested size
	int rsizeX = 0;
	int rsizeY = 0;
	
	// topBar NewTopBar = new topBar("",this);

	int Original_picY = 0;
	int Original_picX = 0;

	String Imagelocation;
	String BigImagelocation="";

	Timer imagetester;
		
	
	public imagezoomPopUp(String ImagelocationSet, String NewImageDiscription, int rsizex, int rsizey) {
		
		rsizeX = rsizex;
		rsizeY = rsizey;
		
		ImageDiscription = NewImageDiscription;

		System.out.print("\n /n <<< added listener-" + bigPicture.getHeight()
				+ "-");
		Imagelocation = ImagelocationSet;
		
		

		// set standard image size
		this.setWidth((rsizeX) + "px");
		this.setHeight((rsizeY+30) + "px");
		
		//set overflow to hide
		this.setStyleName("overflowhide");
		
		//potential bigger image location set
		String biggerlocation_before = Imagelocation.substring(0,(Imagelocation.lastIndexOf("/")+1));
		String biggerlocation_after = Imagelocation.substring(1+(Imagelocation.lastIndexOf("/")));
		final String biggerlocation = biggerlocation_before + "highres_"+biggerlocation_after;
		
		System.out.println("testing location"+biggerlocation);
		
		RequestBuilder biggerimagetester = new RequestBuilder("HEAD", biggerlocation) {
			
		};

			try {
				biggerimagetester.sendRequest("", new RequestCallback() {
			        public void onError(Request request, Throwable exception) {
			        	System.out.println("no bigger image" + exception.getMessage());
			        }

			        public void onResponseReceived(Request request, Response response) {
			        	
			        	
			        	System.out.println("bigger image go..." + response.getStatusText());
			        	
			        	if ((response.getStatusText().compareTo("Not Found")==0)){
			        		System.out.println("bigger image not found");
			        		BigImagelocation ="";
			        		//loadImage();
			        	} else {
			        		//we set the new location.
			        		
			        		BigImagelocation = "','"+biggerlocation;
			        		//Image.prefetch(Imagelocation);
			        		
			        		//loadImage();
			        	}
			        	
			        	//crude fix to force reload in zoom java...need to replace with unique number each time.
			        	MyApplication.zoomfixboolean = !(MyApplication.zoomfixboolean);
			        	if (MyApplication.zoomfixboolean){
			        	rsizeX=rsizeX+1;
			        	rsizeY=rsizeY+1;
			        	}
			        	//HTML zoomcode = new HTML("<div style=\"float:left\" onmouseover=\"zoom_on(event,"+rsizeX+","+rsizeY+",'"+"http://www.google.co.uk/intl/en_uk/images/logo.gif"+"');\" onmousemove=\"zoom_move(event);\" onmouseout=\"zoom_off();\"><img src=\""+"http://www.google.co.uk/intl/en_uk/images/logo.gif"+"\" alt=\"tjpzoom picture title\" style=\"padding:0;margin:0;border:0\" /></div><div style=\"clear:both;\"></div>");
			        	HTML zoomcode = new HTML("<div style=\"float:left\" onmouseover=\"zoom_on(event,"+rsizeX+","+rsizeY+",'"+Imagelocation+BigImagelocation+"');\" onmousemove=\"zoom_move(event);\" onmouseout=\"zoom_off();\"><img src=\""+Imagelocation+"\" alt=\"tjpzoom picture title\" style=\"padding:0;margin:0;border:0\" /></div><div style=\"clear:both;\"></div>");
						
			        	container.insert(zoomcode,0);
						//container.remove(zoomcode);
						//container.insert(zoomcode2,0);
					
						if (ImageDiscription != "") {
							container.setHeight((rsizeY+20) + "px");
							Discription.setHTML(ImageDiscription);
							} else {
							container.setHeight((rsizeY) + "px");
							}
			        	
			        }
			      });
			    } catch (RequestException ex) {
			    	System.out.println("no bigger image");
			    }
			
			
			
		
		
		
		
		
		
		
		
	


		if (ImageDiscription != "") {
			Discription.setHTML(" Loading....");
			this.add(Discription);
			Discription.setHeight("100%");
			Discription.getElement().getParentElement().setClassName(
					"picturePopUp");
		}
		
		//bigPicture.getElement().getParentElement().setClassName("popup_border");

		this.setCellHorizontalAlignment(Discription,
				HasHorizontalAlignment.ALIGN_CENTER);

	}

	public void loadImage() {
		
		bigPicture.setUrl(Imagelocation);
		
		container.add(bigPicture);
		bigPicture.setStyleName("overflowhide");
		bigPicture.addLoadListener(new LoadListener() {
			
			public void onError(Widget sender) {
				// TODO Auto-generated method stub
				imagetester.cancel();
			}

			public void onLoad(Widget sender) {

				MyApplication.DebugWindow.addText("\n 3width is"+bigPicture.getWidth());

				MyApplication.DebugWindow.addText("\n size to is"+rsizeX);
				
				imagetester.cancel();
				// replace image with HTML now
				HTML zoomcode = new HTML("<div style=\"float:left\" onmouseover=\"zoom_on(event,"+rsizeX+","+rsizeY+",'"+Imagelocation+BigImagelocation+"');\" onmousemove=\"zoom_move(event);\" onmouseout=\"zoom_off();\"><img src=\""+Imagelocation+"\" alt=\"tjpzoom picture title\" style=\"padding:0;margin:0;border:0\" /></div><div style=\"clear:both;\"></div>");
				
				
				container.insert(zoomcode,0);
				bigPicture.removeFromParent();
				
				container.setWidth((rsizeX) + "px");
				if (ImageDiscription != "") {
				container.setHeight((rsizeY+20) + "px");
				Discription.setHTML(ImageDiscription);
				} else {
				container.setHeight((rsizeY) + "px");
				}
				
				//reccenter

			     //((PopUpWithShadow)container.getParent().getParent()).setPopupPosition((ScreenSizeX-rsizeX)/2, (ScreenSizeY-rsizeY)/2);
			     
			     
			}
		
		
		});
		
		// use this timer for IE/check its loaded already.
		imagetester = new Timer() {
			@Override
			public void run() {
				// We check the size here, and fix if not correct. (for IE, as
				// IE dosnt work with LoadListener due to the cache)
				MyApplication.DebugWindow.addText("\n width is-"+bigPicture.getWidth());
				if (bigPicture.getWidth() > 15) {
					MyApplication.DebugWindow.addText("\n shrunk");
					imagetester.cancel();
					// replace image with HTML now
					HTML zoomcode = new HTML("<div style=\"float:left\" onmouseover=\"zoom_on(event,"+rsizeX+","+rsizeY+",'"+Imagelocation+BigImagelocation+"');\" onmousemove=\"zoom_move(event);\" onmouseout=\"zoom_off();\"><img src=\""+Imagelocation+"\" alt=\"tjpzoom picture title\" style=\"padding:0;margin:0;border:0\" /></div><div style=\"clear:both;\"></div>");
					container.insert(zoomcode,0);
					bigPicture.removeFromParent();
					container.setWidth((rsizeX) + "px");
					if (ImageDiscription != "") {
					container.setHeight((rsizeY+20) + "px");
					Discription.setHTML(ImageDiscription);
					} else {
					container.setHeight((rsizeY) + "px");
					}
					
					

					
					
					//reccenter

				     ((PopUpWithShadow)container.getParent().getParent()).setPopupPosition((ScreenSizeX-rsizeX)/2, (ScreenSizeY-rsizeY)/2);
				     
				}

			}

		};

		imagetester.scheduleRepeating(1000);
		

		
		
		
		
	}

	protected void reSizePopUp() {
		/*
		// screen size
		ScreenSizeX = Window.getClientWidth();
		ScreenSizeY = Window.getClientHeight();

		// image loaded
		picY = Original_picY;
		picX = Original_picX;
		System.out.print("\n /n <<<<<<<<<<<<<<<<<<<<<<<image loaded []" + picX
				+ "-" + picY);

		

		// Resize the picture if its over 80% of the screen size

		if (picX > (ScreenSizeX * 0.8)) {

			bigPicture.setHeight(picY * ((ScreenSizeX * 0.8) / picX) + "px");

			System.out.println("ratio=" + picX + ">" + (ScreenSizeX * 0.8));
			picX = (int) Math.round(ScreenSizeX * 0.8);
			bigPicture.setWidth(picX + "px");

		} else if (Original_picX > 5) {

			bigPicture.setWidth(Original_picX + "px");
			bigPicture.setHeight(Original_picY + "px");
		}
		
		
		
		// then match the frame to fit

		Discription.setHeight("100%");
		int NewFrameWidth = (bigPicture.getOffsetWidth() + 0);
		bigPicture.getParent().setWidth(NewFrameWidth + "px");
		this.setCellHeight(bigPicture, bigPicture.getHeight() + "px");
		int NewFrameHeight = getOffsetHeight();

		// and the shadow container
		// bigPicture.getParent().getParent().setWidth(20+NewFrameWidth+"px");

		// re center

		// test it isnt bigger then the screen.
		if (NewFrameHeight > ScreenSizeY) {
			posY = ((ScreenSizeY / 2) - (NewFrameHeight / 2))
					+ ((NewFrameHeight - ScreenSizeY) / 2);

		} else {
			posY = (ScreenSizeY / 2) - (NewFrameHeight / 2);
		}

		// --
		((hasCloseDefault) (bigPicture.getParent())).CloseDefault();
		((hasOpenDefault) (bigPicture.getParent())).OpenDefault();

		//this.OpenDefault();
		
		//fix zdepth again
		((PopUpWithShadow)container.getParent().getParent()).fixedZdepth(1800);
		
		
		// RootPanel.get().remove(bigPicture.getParent().getParent());
		// RootPanel.get().add(bigPicture.getParent().getParent(),
		// (ScreenSizeX/2)-(NewFrameWidth/2),posY );

		// adjust parents topbar size
		// ((PopUpWithShadow)(this.getParent())).TopBar.setWidth((this.getOffsetWidth()-80)+"px");

		// adjust fader size
		// MyApplication.fadeback.setSize("100%",900+"px");
		System.out.println("Screen Height="
				+ RootPanel.getBodyElement().getOffsetHeight());
		

		//set_zoomer(NewFrameWidth,NewFrameHeight);
		 * 
		 */
	}

	public void RecheckSize() {
/*
		if (ImageDiscription != "") {
			this
					.setCellHeight(bigPicture, (bigPicture.getHeight() + 10)
							+ "px");
		}

		reSizePopUp();
*/
	}

	public void HideTopBar() {
		// this.NewTopBar.setVisible(false);

	}

	public void ShowTopBar() {
		// this.NewTopBar.setVisible(true);

	}

	public void CloseDefault() {

	}

	public String POPUPTYPE() {
		// TODO Auto-generated method stub
		return "MAGNIFYINGGLASS";
	}
	public boolean POPUPONCLICK() {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean DRAGABLE() {
		// TODO Auto-generated method stub
		return false;
	}
	public void OpenDefault() {
		// has to have grey back, and be set to fixed zdepth
		 RootPanel.get().add(MyApplication.fadeback,0, 0);
       //ControlPanel.ShowDefault();
     DOM.setStyleAttribute(MyApplication.fadeback.getElement(), "zIndex", ""+(MyApplication.z_depth_max+1));
     DOM.setStyleAttribute(MyApplication.fadeback.getElement(), "z-index", ""+(MyApplication.z_depth_max+1));
     MyApplication.z_depth_max = MyApplication.z_depth_max+1;
    /*
     if (bigPicture.getWidth() > 15) {

			MyApplication.DebugWindow.addText("\n 2width is"+bigPicture.getWidth());
			//imagetester.cancel();
			// replace image with HTML now
			HTML zoomcode = new HTML("<div style=\"float:left\" onmouseover=\"zoom_on(event,"+rsizeX+","+rsizeY+",'"+Imagelocation+"');\" onmousemove=\"zoom_move(event);\" onmouseout=\"zoom_off();\"><img src=\""+Imagelocation+"\" alt=\"tjpzoom picture title\" style=\"padding:0;margin:0;border:0\" /></div><div style=\"clear:both;\"></div>");
			container.insert(zoomcode,0);
			bigPicture.removeFromParent();
			container.setWidth((rsizeX) + "px");
			if (ImageDiscription != "") {
			container.setHeight((rsizeY+20) + "px");
			} else {
			container.setHeight((rsizeY) + "px");
			}
			
			//reccenter

		    // ((PopUpWithShadow)container.getParent().getParent()).setPopupPosition((ScreenSizeX-rsizeX)/2, (ScreenSizeY-rsizeY)/2);
		     
		}
     */
	}

	public boolean MAGNIFYABLE() {
		// TODO Auto-generated method stub
		return false;
	}

}
