package com.darkflame.client;

import gwt.canvas.client.Canvas;

public class SpiffyArrow extends Canvas {
	
	int ArrowSizeX = 100;
	int ArrowSizeY = 100;
	
	int Angle = 315;
	
	public SpiffyArrow(int SizeX, int SizeY){
		
		//make a basic arrow pointing to the top left by default
		
		//set size
		ArrowSizeX= SizeX;
		ArrowSizeY= SizeY;	
		
		
		this.setSize(ArrowSizeX+"px", ArrowSizeY+"px");
		
		//draw line from center to topleft

		this.setBackgroundColor(Canvas.TRANSPARENT);
		this.beginPath();
		this.setStrokeStyle("#900");
		this.moveTo(ArrowSizeX, ArrowSizeY);
		this.setLineWidth(3);
		this.lineTo(0,0);
		this.lineTo(12,0);
		this.moveTo(0,0);
		this.lineTo(0,12);
		
		this.stroke();
		
	}
   public void SetArrowTopLeft(){
	this.beginPath();
	this.setStrokeStyle("#900");
	this.moveTo(ArrowSizeX, ArrowSizeY);
	this.setLineWidth(3);
	this.lineTo(0,0);
	this.lineTo(12,0);
	this.moveTo(0,0);
	this.lineTo(0,12);
	
	this.stroke();
	}
   public void SetArrowTopRight(){
	   this.clear();
		this.beginPath();
		this.setStrokeStyle("#900");
		this.moveTo(0, ArrowSizeY);
		this.setLineWidth(3);
		this.lineTo(ArrowSizeX,0);
		this.lineTo(ArrowSizeX-12,0);
		this.moveTo(ArrowSizeX,0);
		this.lineTo(ArrowSizeX,12);
		
		this.stroke();
		}
   
	public void SetArrowAngle(int Degrees){
		
	}
	public void drawArrowHead(boolean state){
		
	}
	public void setThickness(int pixels){
		
	}
	

}
