package com.darkflame.client;

public class Calculator {

	public void calculator(){
		
	}
	
	public boolean isCalculation(String input){
		boolean state=true;
		
		
		//state= input.matches("[\\+\\-\\*\\/0-9]*");
		
		
		//has at least one opp
		state= input.matches(".*[0-9]+[\\+\\-\\*\\/]+[0-9]+.*");
		
		
		return state;
		
	}
	
	public boolean isBasicCalculation(String input){
		boolean state=true;
		//remove spaces
		input = input.replaceAll(" ", "");
		
		//split by operator
		String parts[] = input.split("\\+|-|/|\\*");
		
		//should be two parts
		if (parts.length!=2){
			state=false;
		}
		
		
		return state;
	}
	public float AdvanceCalculation(String input){
		float value=0;
		input = input.replaceAll(" ", "");
		
		while(!isBasicCalculation(input)){
			
			//process the answer one step at a time, based on bodmas.
			
			//test for / 
			if (input.contains("/")){
				
				int posofopp = input.indexOf("/");
		        int posofnextopp = smallestNonZero(input.indexOf("+",posofopp+1),input.indexOf("-",posofopp+1),input.indexOf("/",posofopp+1),input.indexOf("*",posofopp+1));
				
				if (posofnextopp>input.length()){
					posofnextopp=input.length();
				}
				int posoflastopp = biggestNonZero(input.lastIndexOf("+",posofopp-1),input.lastIndexOf("-",posofopp-1),input.lastIndexOf("/",posofopp-1),input.lastIndexOf("*",posofopp-1));
				
				if (posoflastopp<0){
					posoflastopp=0;
				}else {
					posoflastopp=posoflastopp+1;
				}
				System.out.print("\n first pos ="+posofopp);
				System.out.print("\n smallest ="+input.lastIndexOf("*",0));
				
				System.out.print("\n first pos ="+posoflastopp +" last pop "+posofnextopp);
				
				System.out.print("\n first bit="+input.substring(posoflastopp, posofnextopp));
				System.out.print("\n new bit="+BasicCalculation(input.substring(posoflastopp, posofnextopp)));
				
				//escape the sequence
				String replacethis = input.substring(posoflastopp, posofnextopp).replaceAll("\\/", "\\\\\\\\/");
				System.out.print("\n first bit="+replacethis);
				
				//input=input.replaceAll(replacethis, ""+BasicCalculation(input.substring(posoflastopp, posofnextopp)));
				input=input.substring(0, posoflastopp)+BasicCalculation(input.substring(posoflastopp, posofnextopp))+input.substring(posofnextopp, input.length());
				
				System.out.print("\n"+input);
				continue;
			} else if (input.contains("*")){
				int posofopp = input.indexOf("*");
		        int posofnextopp = smallestNonZero(input.indexOf("+",posofopp+1),input.indexOf("-",posofopp+1),input.indexOf("/",posofopp+1),input.indexOf("*",posofopp+1));
				
				if (posofnextopp>input.length()){
					posofnextopp=input.length();
				}
				int posoflastopp = biggestNonZero(input.lastIndexOf("+",posofopp-1),input.lastIndexOf("-",posofopp-1),input.lastIndexOf("/",posofopp-1),input.lastIndexOf("*",posofopp-1));
				
				if (posoflastopp<0){
					posoflastopp=0;
				} else {
					posoflastopp=posoflastopp+1;
				}
				System.out.print("\n first * pos ="+posofopp);
				System.out.print("\n smallest ="+input.lastIndexOf("*",posofopp-1));
				
				System.out.print("\n first pos ="+posoflastopp +" last pop "+posofnextopp);
				
				System.out.print("\n first bit="+input.substring(posoflastopp, posofnextopp));
				System.out.print("\n new bit="+BasicCalculation(input.substring(posoflastopp, posofnextopp)));
				
				//escape the sequence
				String replacethis = input.substring(posoflastopp, posofnextopp).replaceAll("\\*", "\\\\\\\\*");
				
				System.out.print("\n replace this bit="+replacethis);
				
			//	input=input.replaceAll(replacethis, ""+BasicCalculation(input.substring(posoflastopp, posofnextopp)));
				input=input.substring(0, posoflastopp)+BasicCalculation(input.substring(posoflastopp, posofnextopp))+input.substring(posofnextopp, input.length());
				
				System.out.print("\n"+input);
				
				continue;
			} else if (input.contains("+")){
				int posofopp = input.indexOf("+");
		        int posofnextopp = smallestNonZero(input.indexOf("+",posofopp+1),input.indexOf("-",posofopp+1),input.indexOf("/",posofopp+1),input.indexOf("*",posofopp+1));
				
				if (posofnextopp>input.length()){
					posofnextopp=input.length();
				}
				int posoflastopp = biggestNonZero(input.lastIndexOf("+",posofopp-1),input.lastIndexOf("-",posofopp-1),input.lastIndexOf("/",posofopp-1),input.lastIndexOf("*",posofopp-1));
				
				if (posoflastopp<0){
					posoflastopp=0;
				}else {
					posoflastopp=posoflastopp+1;
				}
				System.out.print("\n first pos ="+posofopp);
				System.out.print("\n smallest ="+input.lastIndexOf("*",0));
				
				System.out.print("\n first pos ="+posoflastopp +" last pop "+posofnextopp);
				
				System.out.print("\n first bit="+input.substring(posoflastopp, posofnextopp));
				System.out.print("\n new bit="+BasicCalculation(input.substring(posoflastopp, posofnextopp)));
				
				//escape the sequence
				String replacethis = input.substring(posoflastopp, posofnextopp).replaceAll("\\+", "\\\\\\\\+");
				System.out.print("\n first bit="+replacethis);
				
			//	input=input.replaceAll(replacethis, ""+BasicCalculation(input.substring(posoflastopp, posofnextopp)));
				input=input.substring(0, posoflastopp)+BasicCalculation(input.substring(posoflastopp, posofnextopp))+input.substring(posofnextopp, input.length());
				
				System.out.print("\n"+input);
				continue;
			} else if (input.contains("-")){
				int posofopp = input.indexOf("-");
		        int posofnextopp = smallestNonZero(input.indexOf("+",posofopp+1),input.indexOf("-",posofopp+1),input.indexOf("/",posofopp+1),input.indexOf("*",posofopp+1));
				
				if (posofnextopp>input.length()){
					posofnextopp=input.length();
				}
				int posoflastopp = biggestNonZero(input.lastIndexOf("+",posofopp-1),input.lastIndexOf("-",posofopp-1),input.lastIndexOf("/",posofopp-1),input.lastIndexOf("*",posofopp-1));
				
				if (posoflastopp<0){
					posoflastopp=0;
				}else {
					posoflastopp=posoflastopp+1;
				}
				System.out.print("\n first pos ="+posofopp);
				System.out.print("\n smallest ="+input.lastIndexOf("*",0));
				
				System.out.print("\n first pos ="+posoflastopp +" last pop "+posofnextopp);
				
				System.out.print("\n first bit="+input.substring(posoflastopp, posofnextopp));
				System.out.print("\n new bit="+BasicCalculation(input.substring(posoflastopp, posofnextopp)));
				
				//escape the sequence
				String replacethis = input.substring(posoflastopp, posofnextopp).replaceAll("\\-", "\\\\\\\\-");
				System.out.print("\n first bit="+replacethis);
				
				//input=input.replaceAll(replacethis, ""+BasicCalculation(input.substring(posoflastopp, posofnextopp)));
				input=input.substring(0, posoflastopp)+BasicCalculation(input.substring(posoflastopp, posofnextopp))+input.substring(posofnextopp, input.length());
				
				System.out.print("\n"+input);
				continue;
			}
			
		}
		
		value = BasicCalculation(input);
		System.out.print("\n"+value);
		
		return value;
	}
	
	public float BasicCalculation(String input){
		input = input.replaceAll(" ", "");
		
		//split by operator
		String parts[] = input.split("\\+|-|/|\\*");
		
		String opp = input.substring(parts[0].length(), parts[0].length()+1);
		
		//each part should be a number
		
		float num1 = Float.parseFloat(parts[0]);
		float num2 = Float.parseFloat(parts[1]);
		
		return calculate_chunk(num1,opp,num2);
	}
	public float calculate_chunk (float num1,String opp, float num2){
		float result =0;
		
		if (opp.compareTo("+")==0){
			result = num1 + num2; 
		} else if (opp.compareTo("-")==0){
			result = num1  - num2; 
		} else if (opp.compareTo("*")==0){
			result = num1 * num2; 
		} else if (opp.compareTo("/")==0){
			result = (float)(num1 / num2); 
			
		} 
		
		
		
		return result; 
	}
	public int smallestNonZero(int A, int B, int C, int D){
		
		int R = 0;
		
		//set all values to stupidly high if under 0
		if (A<0){
			A=100000;
		}
		if (B<0){
			B=100000;
		}
		if (C<0){
			C=100000;
		}
		if (D<0){
			D=100000;
		}
		
		R = Math.min((Math.min(D, C)),(Math.min(A, B)));
		
		
		return R;
	}
public int biggestNonZero(int A, int B, int C, int D){
		
		int R = 0;
		
		//set all values to stupidly low if under 0
		if (A<0){
			A=-100000;
		}
		if (B<0){
			B=-100000;
		}
		if (C<0){
			C=-100000;
		}
		if (D<0){
			D=-100000;
		}
		
		R = Math.max((Math.max(D, C)),(Math.max(A, B)));
		
		
		return R;
	}
}
