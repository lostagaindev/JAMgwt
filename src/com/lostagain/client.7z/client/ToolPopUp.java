package com.darkflame.client;

import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

	  public class ToolPopUp  extends PopupPanel  implements hasCloseDefault, isPopUpType, isItem
	  {
		// Type flag
		   static final String POPUPTYPE = "LABEL";
		  
		   //verticlan panel
		   VerticalPanel panel = new VerticalPanel();
		   
			//Discription
		    Label Discription = new Label("");
			//main image
			Image Picture = new Image();
			//screen size
			int ScreenSizeX = Window.getClientWidth();
			int ScreenSizeY = Window.getClientHeight();
			// pic size
			 int picX =0;
			 int picY =0;
			 
			 String tooltype = "Concept";

			boolean POPUPONCLICK = true;
		  
		  public ToolPopUp(String ImageDiscription, String Title)
		  {
			  Discription.setText(ImageDiscription);
			//  topBar NewTopBar = new topBar(Title, this);	 	
			  //set style
			  this.setStyleName("DefaultTopBar");
			  
			  //add title
			 // panel.add(NewTopBar);
			 
			  panel.add(Discription);
			  Discription.setWidth("250px");
			  
			  panel.setCellHorizontalAlignment(Discription, HasHorizontalAlignment.ALIGN_CENTER);
			  panel.setStylePrimaryName("picturePopUp");		
			  this.add(panel);
			  
			  
		  }
		  
		  public void CloseDefault(){		
			 
			 
			  
			  
		  }
		  public void RecheckSize(){
			  RootPanel.get().remove(MyApplication.fadeback);
			  
			 // this.setWidth("400px");
			  //this.center();
			  //this.center();
			  
		  }
		  public String POPUPTYPE() {
				// TODO Auto-generated method stub
				return tooltype;
				
			}
		  
			public boolean POPUPONCLICK() {
				// TODO Auto-generated method stub
				return POPUPONCLICK ;
			}

			public boolean DRAGABLE() {
				// TODO Auto-generated method stub
				return false;
			}
			public boolean MAGNIFYABLE() {
				// TODO Auto-generated method stub
				return false;
			}

			public String SourceURL() {
				// TODO Auto-generated method stub
				return null;
			}

			public String sourcesizeX() {
				// TODO Auto-generated method stub
				return null;
			}

			public String sourcesizeY() {
				// TODO Auto-generated method stub
				return null;
			}
	  }
