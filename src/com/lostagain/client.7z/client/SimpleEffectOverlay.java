package com.darkflame.client;

import java.util.ArrayList;


import com.google.gwt.dom.client.Style;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Label;
import com.allen_sauer.gwt.log.client.Log;

public class SimpleEffectOverlay extends AbsolutePanel {

	double opacity = 0;
	SimpleEffectOverlay overlay = this;
	boolean inuse = false;
	final Timer faderin;
	final Timer faderout;
	final Timer hacked_in;
	final Timer hacked_out;
	
	int wx=0;
	int wy=0;
	int number_of_letters = 0;
	int fade_out_step = 10;
	
	final static ArrayList<Label> leterarray = new ArrayList<Label>();
	
	//for after processing
	String ProcessThisAfter = "";
	
	public SimpleEffectOverlay() {

		this.setSize("100%", "100%");
		this.setStylePrimaryName("overlay");

		// default to black style
		Style style = overlay.getElement().getStyle();
		style.setProperty("filter", "alpha(opacity=" + opacity + ")");
		style.setProperty("opacity", "" + (opacity / 100));
		style.setProperty("zIndex", "3000");

		faderout = new Timer() {
			@Override
			public void run() {
				System.out.print((opacity / 100) + "\n");
				inuse = true;
				Style style = overlay.getElement().getStyle();
				style.setProperty("filter", "alpha(opacity=" + opacity + ")");
				style.setProperty("opacity", "" + (opacity / 100));

				// ThisImage.getElement().setAttribute("style", " filter:
				// alpha(opacity="+opacity+"); opacity: "+(opacity/100)+";");
				opacity = opacity + fade_out_step;
				if (opacity > 100) {
					//overlay.removeFromParent();
					inuse = false;
					this.cancel();
					fade_out_step=10;
					

				}

			}

		};
		faderin = new Timer() {
			@Override
			public void run() {
				System.out.print((opacity / 100) + "\n");
				inuse = true;
				Style style = overlay.getElement().getStyle();
				style.setProperty("filter", "alpha(opacity=" + opacity + ")");
				style.setProperty("opacity", "" + (opacity / 100));

				// ThisImage.getElement().setAttribute("style", " filter:
				// alpha(opacity="+opacity+"); opacity: "+(opacity/100)+";");
				opacity = opacity - fade_out_step;
				if (opacity < 0) {
					//overlay.removeFromParent();
					inuse = false;
					this.cancel();
					fade_out_step=10;

				}

			}

		};

		hacked_in = new Timer() {
			@Override
			public void run() {
				//draw random letter somewhere
				wx = (int)Math.round(Math.random()*overlay.getOffsetWidth()  )-110;
				//int y = (int)Math.round(Math.random()*overlay.getOffsetHeight()  );
				
				wy=wy+2;
				
				MyApplication.DebugWindow.setText(" x= "+wx+" y= "+wy+"=");
				
				Label letters1 = new Label(randomword());
				Label letters2 = new Label(randomword());
				
				leterarray.add(letters1);
				leterarray.add(letters2);
				
				overlay.add(letters1, wx, wy);
				overlay.add(letters2, wx, wy+8);
				//
				number_of_letters=number_of_letters+1;
				if (wy>overlay.getOffsetHeight()){
					
					//if theres after processing we run it
					if (ProcessThisAfter.length()>2){
						MyApplication.processInstructions(ProcessThisAfter,"hackedin");
						//then clear it
						ProcessThisAfter="";
					}
					
					
					inuse = false;
					this.cancel();
				}
			}

		};
		hacked_out = new Timer() {
			@Override
			public void run() {
				//draw random letter somewhere
				MyApplication.DebugWindow.addText(" deleteing= "+number_of_letters);
				
				leterarray.get(number_of_letters).removeFromParent();
				leterarray.get(number_of_letters).setVisible(false);
				
				if (leterarray.get(number_of_letters).isAttached()==false){
				number_of_letters=number_of_letters+1;
				}
				
				if (number_of_letters>=leterarray.size()){
					inuse = false;
					leterarray.clear();
					overlay.clear();
					overlay.removeFromParent();
					
					this.cancel();
				}
			}

		};
	}
	
	public void SetOpacity(double NewOpacity){
		if ((NewOpacity<101) &&(NewOpacity>-1)){
		opacity= NewOpacity;
		Style style = overlay.getElement().getStyle();
		style.setProperty("filter", "alpha(opacity=" + opacity + ")");
		style.setProperty("opacity", "" + (opacity / 100));

		}
		
		
	}

	public void Clear(){
		
		final Timer WaitTillFree = new Timer() {
			@Override
			public void run() {
				if (inuse == false) {
					inuse = false;
					overlay.removeFromParent();
					this.cancel();
				} else {
					// wait more
				}

			}

		};
		WaitTillFree.scheduleRepeating(500);
	}
	public void ClearNOW(){
		
				inuse = false;
					overlay.removeFromParent();
			
	}
	
	/** Fades it in and out again quickly **/
	public void Flash(final int Over){
		
		int Half = (int)Math.ceil(Over/2);
		if (Half<10){
			Half=10;
		}
		fade_out_step=25;
		
		overlay.getElement().getStyle().setProperty("backgroundColor", "lightBlue");
		Log.info("- Flash colour set one -"+(Half));
		FadeOut(Half);
		fade_out_step=25;
		Log.info("now we fade in again");
		FadeIn(Half);
		//overlay.getElement().getStyle().setProperty("backgroundColor", "black");
		
	}
	
	public void FadeIn(final int Over) {

		

		
		// wait for effectoverlay to not be in use;

		final Timer WaitTillFree = new Timer() {
			@Override
			public void run() {
				if (inuse == false) {
					inuse = true;
					opacity = 100;
					faderin.scheduleRepeating(Over / 10);
					this.cancel();
				} else {
					// wait more
				}

			}

		};
		if (inuse == true){
			WaitTillFree.scheduleRepeating(500);
			} else {
				inuse = true;
				opacity = 100;
				faderin.scheduleRepeating(Over / 10);
				
			}
	}

	public void FadeOut(final int Over) {

		
		
		opacity = 0;

		
		final Timer WaitTillFree2 = new Timer() {
			@Override
			public void run() {
				if (inuse == false) {
					inuse = true;
					opacity = 0;
					faderout.scheduleRepeating(Over / 10);
					this.cancel();
				} else {
					// wait more
				}

			}

		};
		if (inuse == true){
			WaitTillFree2.scheduleRepeating(500);
			} else {
				inuse = true;
				opacity = 0;
				faderout.scheduleRepeating(Over / 10);
			}
	}
	public void Hacked_in(){
							

		final Timer WaitTillFree3 = new Timer() {
			@Override
			public void run() {
				if (inuse == false) {
					inuse = true;
					wy=0;
					wx=0;
					opacity=100;
					number_of_letters=0;
					Style style = overlay.getElement().getStyle();
					style.setProperty("filter", "alpha(opacity=" + opacity + ")");
					style.setProperty("opacity", "" + (opacity / 100));		
					overlay.setStylePrimaryName("hackerstyle");
					hacked_in.scheduleRepeating(15);
					
					this.cancel();
				} else {
					// wait more
				}

			}

		};
		if (inuse == true){
			WaitTillFree3.scheduleRepeating(500);
			} else {
				inuse = true;
				wy=0;
				wx=0;
				opacity=100;
				number_of_letters=0;
				Style style = overlay.getElement().getStyle();
				style.setProperty("filter", "alpha(opacity=" + opacity + ")");
				style.setProperty("opacity", "" + (opacity / 100));		
				overlay.setStylePrimaryName("hackerstyle");
				hacked_in.scheduleRepeating(15);
				
			}
	}	
	
	public void Hacked_out(){

		final Timer WaitTillFree4 = new Timer() {
			@Override
			public void run() {
				if (inuse == false) {
					inuse = true;
					wy=0;
					wx=0;
					opacity=100;
					number_of_letters=0;
					Style style = overlay.getElement().getStyle();
					style.setProperty("filter", "alpha(opacity=" + opacity + ")");
					style.setProperty("opacity", "" + (opacity / 100));		
					overlay.setStylePrimaryName("hackerstyle");
					hacked_out.scheduleRepeating(15);
					
					this.cancel();
				} else {
					// wait more
				}

			}

		};
		if (inuse == true){
			WaitTillFree4.scheduleRepeating(500);
			} else {
				inuse = true;
				wy=0;
				wx=0;
				opacity=100;
				number_of_letters=0;
				Style style = overlay.getElement().getStyle();
				style.setProperty("filter", "alpha(opacity=" + opacity + ")");
				style.setProperty("opacity", "" + (opacity / 100));		
				overlay.setStylePrimaryName("hackerstyle");
				hacked_out.scheduleRepeating(15);
				
			}
	
				
		
	}
	
	
//Special function for JARG	
	public void ProcessThisAfter(String NewProcessThisAfter){
		ProcessThisAfter=NewProcessThisAfter;
	}
	
	public String randomword(){
		String word = "1010101";
		
		  int rw = (int)(Math.random()*18);
		  switch (rw) {
          case 1:  word = "4423"; break;
          case 2:  word = "101010"; break;
          case 3:  word = "4815162342"; break;
          case 4:  word = "The Matrix Has You"; break;
          case 5:  word = "Would You like To Play a Game?"; break;
          case 6:  word = "]SYSTEM CRASH: \n ]Restart Y/N?: \n YES"; break;
          case 7:  word = "42"; break;
          case 8:  word = "Good morning Dave."; break;
          case 9:  word = "12:50, press Return."; break;
          case 10: word = "THERE IS AS YET INSUFFICIENT DATA FOR A MEANINGFUL ANSWER"; break;
          case 11: word = "\"Yes, now there is a God.\"";break;          
          case 12: word = "\"Insufficient data at this point. But whatever it was, he did it at a) each step along life's highway and b) not in a shy way..\"";break;
          case 13: word = "On the other side of the screen, it all looks so easy";break;
          case 14: word = "End of line";break;
          case 15: word = "By Your Command";break;
          case 16: word = "++?????++ Out of Cheese Error. Redo From Start.";break;
          case 17: word = "Thank you for helping us help you help us all.";break;
          case 18: word = "Error. Grasshopper disassembled... Re-assemble!.";break;
          default: word = "\"Where do you want to go today?\"";break;
          
      }
		
		return word;
	}
}
