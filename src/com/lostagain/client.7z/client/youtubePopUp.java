package com.darkflame.client;

import com.darkflame.client.hasCloseDefault;
import com.darkflame.client.hasOpenDefault;
import com.darkflame.client.isPopUpType;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.SimplePanel;


public class youtubePopUp extends SimplePanel  implements hasCloseDefault,
 hasOpenDefault, isPopUpType {
String HTMLString = "<object width=\"SIZE_X\" height=\"SIZE_Y\"><param name=\"movie\" value=\"YOUTUBEURL&hl=en&fs=1&color1=0x234900&color2=0x4e9e00\"></param><param name=\"allowFullScreen\" value=\"false\"></param><param name=\"allowscriptaccess\" value=\"always\"></param><embed src=\"YOUTUBEURL&hl=en&fs=1&color1=0x234900&color2=0x4e9e00\" type=\"application/x-shockwave-flash\" allowscriptaccess=\"always\" allowfullscreen=\"true\" width=\"SIZE_X\" height=\"SIZE_Y\"></embed></object>";

	public youtubePopUp(String URL,int size_x,int size_y){
		
		//fix for you tube embed url	
		URL=URL.replaceAll("watch\\?v\\=", "v/");
		
		//replace url	
		HTMLString=HTMLString.replaceAll("YOUTUBEURL", URL);
		HTMLString=HTMLString.replaceAll("SIZE_X", size_x+"");
		HTMLString=HTMLString.replaceAll("SIZE_Y", 12+size_y+"");
		
		MyApplication.DebugWindow.addText(HTMLString);
		
		HTML frame = new HTML (HTMLString);
		frame.setSize("100%", "100%");
		this.add(frame);
		
		
		
		this.setSize( 2+size_x+"px",12+size_y+"px");
		
		
		
	}

	public void CloseDefault() {
		// TODO Auto-generated method stub
		
	}

	public void OpenDefault() {
		// has to have grey back, and be set to fixed zdepth
		 RootPanel.get().add(MyApplication.fadeback,0, 0);
        //ControlPanel.ShowDefault();
      DOM.setStyleAttribute(MyApplication.fadeback.getElement(), "zIndex", ""+(MyApplication.z_depth_max+1));
      DOM.setStyleAttribute(MyApplication.fadeback.getElement(), "z-index", ""+(MyApplication.z_depth_max+1));
      MyApplication.z_depth_max = MyApplication.z_depth_max+1;
     
		
	}

	public String POPUPTYPE() {
		// TODO Auto-generated method stub
		return "MOVIE";
	}
	public boolean POPUPONCLICK() {
		return true;
	}
	public void RecheckSize() {
		// TODO Auto-generated method stub
		
	}

	public boolean DRAGABLE() {
		// TODO Auto-generated method stub
		return true;
	}
	public boolean MAGNIFYABLE() {
		// TODO Auto-generated method stub
		return false;
	}
}
