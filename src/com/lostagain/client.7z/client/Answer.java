package com.darkflame.client;

/** Stores answers and associative code to run if they are found **/
public class Answer {
	
	String Answer;
	String Chapter;
	String ScriptCodeBlock; //in future code blocks should be a static array to stop duplication 
	
	//int AssociatedBlockNumber //used to store the number of the code block to return
	//String[] CodeBlockArray; //used to store all the unique code blocks;
	//String LastCodeBlock; //if the code block being added matchs the last one, then we add it to the array
	
	public Answer(String Answer,String Chapter,String ScriptCodeBlock){
		
		this.Answer = Answer;
		this.Chapter = Chapter;
		this.ScriptCodeBlock = ScriptCodeBlock;
	}
 
	
	
}
